#include "meshgeometry.h"
_debug_symbol_MeshGeometry::_debug_symbol_MeshGeometry(_debug_symbol_LitTexEffect* _debug_symbol_effect) :
_debug_symbol_mEffect(_debug_symbol_effect)
{
}
_debug_symbol_MeshGeometry::~_debug_symbol_MeshGeometry(void)
{
}
void _debug_symbol_MeshGeometry::_debug_symbol_SetVertices(_debug_symbol_ID3D11Device* device, const Vertex::_debug_symbol_NormalTexVertex* _debug_symbol_verts, UINT count)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mVB);
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(Vertex::_debug_symbol_NormalTexVertex) * count;
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_vbd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = _debug_symbol_verts;
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_mVB));
}
void _debug_symbol_MeshGeometry::_debug_symbol_SetIndices(_debug_symbol_ID3D11Device* device, const UINT* indices, UINT count)
{
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(UINT) * count;
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iInitData;
_debug_symbol_iInitData._debug_symbol_pSysMem = indices;
_debug_symbol_mIndexCount = count;
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iInitData, &_debug_symbol_mIB));
}
void _debug_symbol_MeshGeometry::_debug_symbol_SetSubsetTable(std::vector<_debug_symbol_Subset>& _debug_symbol_subsetTable)
{
_debug_symbol_mSubsetTable = _debug_symbol_subsetTable;
}
void _debug_symbol_MeshGeometry::Draw(_debug_symbol_ID3D11DeviceContext* context, UINT _debug_symbol_subsetID)
{
UINT offset = 0;
UINT stride = sizeof(Vertex::_debug_symbol_NormalTexVertex);
context->_debug_symbol_IASetVertexBuffers(0, 1, &_debug_symbol_mVB, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_mIB, _debug_symbol_DXGI_FORMAT_R32_UINT, 0);
context->_debug_symbol_DrawIndexed(_debug_symbol_mSubsetTable[_debug_symbol_subsetID]._debug_symbol_faceCount * 3, _debug_symbol_mSubsetTable[_debug_symbol_subsetID]._debug_symbol_faceStartIndex * 3, 0);
}
void _debug_symbol_MeshGeometry::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_ITWorld, _debug_symbol_CXMMATRIX vp)
{
_debug_symbol_mEffect->_debug_symbol_SetPerObjectParams(_debug_symbol_world, _debug_symbol_ITWorld, _debug_symbol_world * vp, _debug_symbol_mSubsetTable[0]._debug_symbol_srv);
for(int i = 0; i <  _debug_symbol_mSubsetTable.size(); ++i)
{
_debug_symbol_mEffect->_debug_symbol_SetDiffuseMap(_debug_symbol_mSubsetTable[i]._debug_symbol_srv);
_debug_symbol_mEffect->Draw(context, _debug_symbol_mVB, _debug_symbol_mIB, _debug_symbol_mSubsetTable[i]._debug_symbol_faceStartIndex * 3, _debug_symbol_mSubsetTable[i]._debug_symbol_faceCount * 3);
}
}

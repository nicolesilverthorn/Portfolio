#pragma once
#include "graphicalgeometry.h"
#include "effect.h"
class _debug_symbol_Terrain :
public _debug_symbol_GraphicalGeometry
{
public:
struct _debug_symbol_InitInfo
{
std::wstring _debug_symbol_heightMapFilename;
std::wstring _debug_symbol_layerMapFilename0;
std::wstring _debug_symbol_layerMapFilename1;
std::wstring _debug_symbol_layerMapFilename2;
std::wstring _debug_symbol_layerMapFilename3;
std::wstring _debug_symbol_blendMapFilename;
float _debug_symbol_heightScale;
UINT width;
UINT height;
float _debug_symbol_cellWidth;
float _debug_symbol_cellHeight;
float _debug_symbol_texTilesWide;
float _debug_symbol_texTilesHigh;
};
private:
_debug_symbol_InitInfo _debug_symbol_mTerrainData;
std::vector<float> _debug_symbol_mHeightMap;
_debug_symbol_ID3D11ShaderResourceView** _debug_symbol_mDiffuseMaps;
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_mBlendMap;
_debug_symbol_TerrainEffect* _debug_symbol_mEffect;
public:
_debug_symbol_Terrain(void){}
virtual ~_debug_symbol_Terrain(void);
void Init(_debug_symbol_ID3D11Device* device, const _debug_symbol_InitInfo& info);
void _debug_symbol_LoadHeightMap();
void _debug_symbol_InitVB(_debug_symbol_ID3D11Device* device);
void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device);
void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX vp);
_debug_symbol_TerrainEffect* _debug_symbol_GetEffect() const
{
return _debug_symbol_mEffect;
}
float GetHeight(float x, float _debug_symbol_z);
private:
void _debug_symbol_LoadTextures(_debug_symbol_ID3D11Device* device);
};

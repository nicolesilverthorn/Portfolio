#pragma once
#include "d3dUtil.h"
class _debug_symbol_GraphicalGeometry
{
protected:
_debug_symbol_ID3D11Buffer* _debug_symbol_mVB;
_debug_symbol_ID3D11Buffer* _debug_symbol_mIB;
UINT _debug_symbol_mIndexCount;
public:
_debug_symbol_GraphicalGeometry(void) : _debug_symbol_mVB(0), _debug_symbol_mIB(0), _debug_symbol_mIndexCount(0)
{
}
virtual ~_debug_symbol_GraphicalGeometry(void)
{
if (_debug_symbol_mVB)
{
_debug_symbol_mVB->Release();
}
if (_debug_symbol_mIB)
{
_debug_symbol_mIB->Release();
}
}
_debug_symbol_ID3D11Buffer* _debug_symbol_GetVB()
{
return _debug_symbol_mVB;
}
_debug_symbol_ID3D11Buffer* _debug_symbol_GetIB()
{
return _debug_symbol_mIB;
}
UINT GetIndexCount() const
{
return _debug_symbol_mIndexCount;
}
protected:
virtual void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device) = 0;
};

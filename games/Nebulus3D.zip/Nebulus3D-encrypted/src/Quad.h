#pragma once
#include "graphicalgeometry.h"
class _debug_symbol_Quad : public _debug_symbol_GraphicalGeometry
{
public:
_debug_symbol_Quad(void) : _debug_symbol_GraphicalGeometry()
{}
_debug_symbol_Quad(_debug_symbol_ID3D11Device* device, float width, float height);
virtual ~_debug_symbol_Quad(void)
{
}
void _debug_symbol_InitBuffers(_debug_symbol_ID3D11Device* device, float width, float height);
private:
void _debug_symbol_InitVB(_debug_symbol_ID3D11Device* device, float width, float height);
void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device);
};

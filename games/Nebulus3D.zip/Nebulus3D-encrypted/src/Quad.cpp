#include "quad.h"
#include "vertex.h"
_debug_symbol_Quad::_debug_symbol_Quad(_debug_symbol_ID3D11Device* device, float width, float height)
{
_debug_symbol_InitBuffers(device, width, height);
}
void _debug_symbol_Quad::_debug_symbol_InitBuffers(_debug_symbol_ID3D11Device* device, float width, float height)
{
_debug_symbol_InitVB(device, width, height);
_debug_symbol_InitIB(device);
}
void _debug_symbol_Quad::_debug_symbol_InitVB(_debug_symbol_ID3D11Device* device, float width, float height)
{
float _debug_symbol_halfWidth = width / 2.0f;
float _debug_symbol_halfHeight = height / 2.0f;
Vertex::_debug_symbol_NormalTexVertex _debug_symbol_vertices[] =
{
{ _debug_symbol_XMFLOAT3(-_debug_symbol_halfWidth, -_debug_symbol_halfHeight, 0.0f), _debug_symbol_XMFLOAT3(0.0f, 0.0f, 1.0f), _debug_symbol_XMFLOAT2(1.0f, 1.0f) },
{ _debug_symbol_XMFLOAT3(-_debug_symbol_halfWidth, _debug_symbol_halfHeight, 0.0f), _debug_symbol_XMFLOAT3(0.0f, 0.0f, 1.0f), _debug_symbol_XMFLOAT2(1.0f, 0.0f) },
{ _debug_symbol_XMFLOAT3(_debug_symbol_halfWidth, -_debug_symbol_halfHeight, 0.0f), _debug_symbol_XMFLOAT3(0.0f, 0.0f, 1.0f), _debug_symbol_XMFLOAT2(0.0f, 1.0f) },
{ _debug_symbol_XMFLOAT3(_debug_symbol_halfWidth, _debug_symbol_halfHeight, 0.0f), _debug_symbol_XMFLOAT3(0.0f, 0.0f, 1.0f), _debug_symbol_XMFLOAT2(0.0f, 0.0f) }
};
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(Vertex::_debug_symbol_NormalTexVertex) * 4;
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_vbd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = _debug_symbol_vertices;
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_mVB));
}
void _debug_symbol_Quad::_debug_symbol_InitIB(_debug_symbol_ID3D11Device* device)
{
UINT indices[] =
{
0, 2, 1,
2, 3, 1,
};
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(UINT)* 6;
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iinitData;
_debug_symbol_iinitData._debug_symbol_pSysMem = indices;
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iinitData, &_debug_symbol_mIB));
}

#include "thirdpersoncam.h"
#include "graphicalobject.h"
_debug_symbol_ThirdPersonCam::_debug_symbol_ThirdPersonCam(void) : _debug_symbol_BaseCamera(),
_debug_symbol_mOffsetLook(0.0f),
_debug_symbol_mOffsetUp(0.0f),
_debug_symbol_mTarget(0),
_debug_symbol_mTargetYOffset(0.0f)
{
}
_debug_symbol_ThirdPersonCam::_debug_symbol_ThirdPersonCam(_debug_symbol_GraphicalObject* target, float _debug_symbol_offsetLook, float _debug_symbol_offsetUp, float _debug_symbol_targetYOffset) : _debug_symbol_BaseCamera(),
_debug_symbol_mOffsetLook(_debug_symbol_offsetLook),
_debug_symbol_mOffsetUp(_debug_symbol_offsetUp),
_debug_symbol_mTarget(target),
_debug_symbol_mTargetYOffset(_debug_symbol_targetYOffset)
{
}
_debug_symbol_ThirdPersonCam::~_debug_symbol_ThirdPersonCam(void)
{
}
void _debug_symbol_ThirdPersonCam::Update()
{
if(_debug_symbol_mTarget != NULL)
{
_debug_symbol_XMVECTOR _debug_symbol_targetPos =  _debug_symbol_mTarget->GetPos();
_debug_symbol_XMVECTOR _debug_symbol_targetOffset = _debug_symbol_XMVectorSet(0.0f, _debug_symbol_mTargetYOffset, 0.0f, 0.0f);
_debug_symbol_targetPos = _debug_symbol_targetPos + _debug_symbol_targetOffset;
_debug_symbol_XMVECTOR pos = _debug_symbol_targetPos - (_debug_symbol_mTarget->_debug_symbol_GetLook() * _debug_symbol_mOffsetLook) + (_debug_symbol_mTarget->_debug_symbol_GetUp() * _debug_symbol_mOffsetUp);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_targetPos - pos;
_debug_symbol_look = _debug_symbol_XMVector3Normalize(_debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f));
}
_debug_symbol_BaseCamera::Update();
}

#include "d3dApp.h"
#include "d3dx11Effect.h"
#include "MathHelper.h"
#include "LightHelper.h"
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "vertex.h"
#include "quad.h"
#include "thirdpersoncam.h"
#include "cube.h"
#include "graphicalobject.h"
#include "effect.h"
#include "terrain.h"
#include "_player.h"
#include "character.h"
#include "skybox.h"
#include "GameTimer.h"
#include "xnacollision.h"
#include "fontrasterizer.h"
struct _debug_symbol_BoundingSphere
{
_debug_symbol_BoundingSphere() : _debug_symbol_Centre(0.0f, 0.0f, 0.0f), _debug_symbol_Radius(0.0f) {}
_debug_symbol_XMFLOAT3 _debug_symbol_Centre;
float _debug_symbol_Radius;
};
struct _debug_symbol_TestParticle
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_XMFLOAT3 _debug_symbol_vel;
};
class _debug_symbol_InClassProj : public _debug_symbol_D3DApp
{
public:
_debug_symbol_InClassProj(HINSTANCE hInstance);
~_debug_symbol_InClassProj();
bool Init();
void OnResize();
void _debug_symbol_UpdateScene(float dt);
void _debug_symbol_DrawScene();
void _debug_symbol_DrawSplashScene();
void _debug_symbol_InitBoundingSpheres();
void _debug_symbol_InitBoundingBoxes();
void _debug_symbol_OnMouseDown(WPARAM _debug_symbol_btnState, int x, int y);
void _debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y);
void OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y);
private:
void _debug_symbol_BuildTestPyramid();
void _debug_symbol_BuildVertexLayout();
void _debug_symbol_BuildSceneLights();
void _debug_symbol_BuildBlendStates();
void _debug_symbol_BuildDSStates();
void _debug_symbol_GameLoop();
void _debug_symbol_SplashScreen();
void _debug_symbol_UpdateGroundCollision();
void _debug_symbol_UpdateKeyboardInput(float dt);
void _debug_symbol_UpdateBoundingSpheres();
void _debug_symbol_SphereBoxCollision();
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_GetOrientedBox(_debug_symbol_FXMVECTOR _debug_symbol_extents, const _debug_symbol_GraphicalObject* obj);
private:
_debug_symbol_LitTexEffect* _debug_symbol_mLitTexEffect;
_debug_symbol_ThirdPersonCam* _debug_symbol_mCam;
_debug_symbol_BaseCamera* _debug_symbol_m2DCam;
_debug_symbol_FontRasterizer* _debug_symbol_mFont;
_debug_symbol_FontRasterizer* _debug_symbol_mSplashFont;
_debug_symbol_XMFLOAT4 _debug_symbol_mAmbientColour;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mView;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mProj;
_debug_symbol_XMFLOAT4X4 _debug_symbol_m2DProj;
_debug_symbol_PointLightOptimized _debug_symbol_mPointLight;
_debug_symbol_SpotLightOptimized _debug_symbol_mSpotLight;
_debug_symbol_Player* _debug_symbol_mTestPlayer;
Character* _debug_symbol_mTower;
Character* _debug_symbol_mEnemy1;
Character* _debug_symbol_mEnemy2;
Character* _debug_symbol_mEnemy3;
_debug_symbol_SkyBox* _debug_symbol_mSky;
_debug_symbol_Terrain* _debug_symbol_mTestTerrain;
_debug_symbol_GraphicalObject* _debug_symbol_mSplashScreen;
bool _debug_symbol_mMouseReleased;
bool _debug_symbol_mIsGameOver = false;
bool _debug_symbol_mIsGameWon = false;
POINT _debug_symbol_mLastMousePos;
_debug_symbol_BoundingSphere _debug_symbol_mBSPlayer;
_debug_symbol_BoundingSphere _debug_symbol_mBSTower;
_debug_symbol_BoundingSphere _debug_symbol_mBSEnemy1;
_debug_symbol_BoundingSphere _debug_symbol_mBSEnemy2;
_debug_symbol_BoundingSphere _debug_symbol_mBSEnemy3;
_debug_symbol_ID3D11BlendState* _debug_symbol_mAdditiveBS;
_debug_symbol_ID3D11BlendState* _debug_symbol_mTransparentBS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mNoDepthDS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mFontDS;
public:
float angle;
float _debug_symbol_mTimer = 0.0f;
bool _debug_symbol_started = false;
bool _debug_symbol_isSplashing = false;
float _debug_symbol_overTimer = 0.0f;
};
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE _debug_symbol_prevInstance, PSTR _debug_symbol_cmdLine, int showCmd)
{
#if defined(DEBUG) | defined(_DEBUG)
_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
_debug_symbol_InClassProj _debug_symbol_theApp(hInstance);
if (!_debug_symbol_theApp.Init())
return 0;
return _debug_symbol_theApp.Run();
}
_debug_symbol_InClassProj::_debug_symbol_InClassProj(HINSTANCE hInstance) :
_debug_symbol_D3DApp(hInstance), _debug_symbol_mLitTexEffect(0), _debug_symbol_mMouseReleased(true), _debug_symbol_mCam(0), _debug_symbol_mSky(0), _debug_symbol_mTestPlayer(0), _debug_symbol_mTower(0), _debug_symbol_mEnemy1(0), _debug_symbol_mIsGameOver(false), _debug_symbol_mIsGameWon(false), _debug_symbol_mTestTerrain(0)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_XMVectorSet(1.0f, 1.0f, 5.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
_debug_symbol_mMainWndCaption =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Nebulus 3D"));
_debug_symbol_mLastMousePos.x = 0;
_debug_symbol_mLastMousePos.y = 0;
angle = 0.0f;
_debug_symbol_XMMATRIX _debug_symbol_I = _debug_symbol_XMMatrixIdentity();
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mView, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mProj, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_I);
srand((UINT)time(NULL));
}
_debug_symbol_InClassProj::~_debug_symbol_InClassProj()
{
Vertex::_debug_symbol_CleanLayouts();
if (_debug_symbol_mTestTerrain)
delete _debug_symbol_mTestTerrain;
if (_debug_symbol_mLitTexEffect)
delete _debug_symbol_mLitTexEffect;
if (_debug_symbol_mTestPlayer)
delete _debug_symbol_mTestPlayer;
if (_debug_symbol_mEnemy1)
delete _debug_symbol_mEnemy1;
if (_debug_symbol_mCam)
delete _debug_symbol_mCam;
if (_debug_symbol_m2DCam)
delete _debug_symbol_m2DCam;
if (_debug_symbol_mSky)
delete _debug_symbol_mSky;
if (_debug_symbol_mTower)
delete _debug_symbol_mTower;
if (_debug_symbol_mAdditiveBS)
_debug_symbol_ReleaseCOM(_debug_symbol_mAdditiveBS);
if (_debug_symbol_mTransparentBS)
_debug_symbol_ReleaseCOM(_debug_symbol_mTransparentBS);
if (_debug_symbol_mNoDepthDS)
_debug_symbol_ReleaseCOM(_debug_symbol_mNoDepthDS);
}
void _debug_symbol_InClassProj::_debug_symbol_BuildSceneLights()
{
_debug_symbol_mAmbientColour = _debug_symbol_XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
}
void _debug_symbol_InClassProj::_debug_symbol_GameLoop()
{
}
void _debug_symbol_InClassProj::_debug_symbol_SplashScreen()
{
}
bool _debug_symbol_InClassProj::Init()
{
if (!_debug_symbol_D3DApp::Init())
return false;
_debug_symbol_mLitTexEffect = new _debug_symbol_LitTexEffect();
_debug_symbol_mLitTexEffect->_debug_symbol_LoadEffect( decrypt::_debug_symbol_dec_debug(_T( "_debug_FX/lighting.fx")), _debug_symbol_md3dDevice);
_debug_symbol_mSky = new _debug_symbol_SkyBox(_debug_symbol_md3dDevice, 200.0f,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/starsSkybox.dds")));
Vertex::_debug_symbol_InitLitTexLayout(_debug_symbol_md3dDevice, _debug_symbol_mLitTexEffect->_debug_symbol_GetTech());
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_XMVectorSet(64.0f, 0.0f, 63.9f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_towerPos = _debug_symbol_XMVectorSet(64.0f, 0.0f, 64.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_enemy1Pos = _debug_symbol_XMVectorSet(-5.397f, 11.028f, -11.187f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMVectorSet(0.0f, 0.0f, 1.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
_debug_symbol_mTestPlayer = new _debug_symbol_Player(_debug_symbol_playerPos, _debug_symbol_look, _debug_symbol_up, _debug_symbol_md3dDevice, _debug_symbol_mLitTexEffect,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Models/sphere.obj")), false, true, 5.0f, 10.0f, 3.0f);
_debug_symbol_mTower = new Character(_debug_symbol_towerPos, _debug_symbol_look, _debug_symbol_up, _debug_symbol_md3dDevice, _debug_symbol_mLitTexEffect,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Models/finalTower.obj")), false, true, 0.0f, 0.0f, 0.0f);
_debug_symbol_mEnemy1 = new Character(_debug_symbol_enemy1Pos, _debug_symbol_look, _debug_symbol_up, _debug_symbol_md3dDevice, _debug_symbol_mLitTexEffect,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Models/sphere1.obj")), false, true, 5.0f, 10.0f, 3.0f);
_debug_symbol_mCam = new _debug_symbol_ThirdPersonCam(_debug_symbol_mTestPlayer, 13.0f, 0.0f, 1.67f);
_debug_symbol_mCam->Update();
_debug_symbol_m2DCam = new _debug_symbol_BaseCamera(_debug_symbol_XMVectorSet(0.0f, 0.0f, -0.5f, 0.0f), _debug_symbol_XMVectorSet(0.0f, 0.0f, 1.0f, 0.0f), _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f));
_debug_symbol_m2DCam->Update();
_debug_symbol_BuildSceneLights();
_debug_symbol_Terrain::_debug_symbol_InitInfo _debug_symbol_terrainInfo;
_debug_symbol_terrainInfo._debug_symbol_cellHeight = 1.0f;
_debug_symbol_terrainInfo._debug_symbol_cellWidth = 1.0f;
_debug_symbol_terrainInfo.height = 128;
_debug_symbol_terrainInfo.width = 128;
_debug_symbol_terrainInfo._debug_symbol_heightMapFilename =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/testHeightMap.raw"));
_debug_symbol_terrainInfo._debug_symbol_layerMapFilename0 =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/water2.dds"));
_debug_symbol_terrainInfo._debug_symbol_layerMapFilename1 =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/grass.dds"));
_debug_symbol_terrainInfo._debug_symbol_layerMapFilename2 =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/water2.dds"));
_debug_symbol_terrainInfo._debug_symbol_layerMapFilename3 =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/grass.dds"));
_debug_symbol_terrainInfo._debug_symbol_blendMapFilename =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/testBlend.png"));
_debug_symbol_terrainInfo._debug_symbol_heightScale = 100.0f;
_debug_symbol_terrainInfo._debug_symbol_texTilesWide = 20.0f;
_debug_symbol_terrainInfo._debug_symbol_texTilesHigh = 20.0f;
_debug_symbol_mTestTerrain = new _debug_symbol_Terrain();
_debug_symbol_mTestTerrain->Init(_debug_symbol_md3dDevice, _debug_symbol_terrainInfo);
Vertex::_debug_symbol_InitTerrainVertLayout(_debug_symbol_md3dDevice, _debug_symbol_mTestTerrain->_debug_symbol_GetEffect()->_debug_symbol_GetTech());
_debug_symbol_InitBoundingSpheres();
_debug_symbol_BuildBlendStates();
_debug_symbol_BuildDSStates();
_debug_symbol_ID3D11ShaderResourceView* font;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/fontW.png")), 0, 0, &font, 0);
_debug_symbol_mFont = new _debug_symbol_FontRasterizer(_debug_symbol_m2DCam, _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj), _debug_symbol_mLitTexEffect, 10, 10, font, _debug_symbol_md3dDevice);
_debug_symbol_mSplashFont = new _debug_symbol_FontRasterizer(_debug_symbol_m2DCam, _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj), _debug_symbol_mLitTexEffect, 20, 20, font, _debug_symbol_md3dDevice);
_debug_symbol_mTestPlayer->_debug_symbol_LeaveGround();
return true;
}
void _debug_symbol_InClassProj::_debug_symbol_BuildBlendStates()
{
_debug_symbol_D3D11_BLEND_DESC _debug_symbol_bsDesc = { 0 };
_debug_symbol_bsDesc._debug_symbol_AlphaToCoverageEnable = false;
_debug_symbol_bsDesc._debug_symbol_IndependentBlendEnable = false;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0].BlendOp = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlendAlpha = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlendAlpha = _debug_symbol_D3D11_BLEND_ZERO;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendOpAlpha = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_RenderTargetWriteMask = _debug_symbol_D3D11_COLOR_WRITE_ENABLE_ALL;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mAdditiveBS));
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_SRC_ALPHA;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_INV_SRC_ALPHA;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mTransparentBS));
}
void _debug_symbol_InClassProj::_debug_symbol_BuildDSStates()
{
_debug_symbol_D3D11_DEPTH_STENCIL_DESC _debug_symbol_dsDesc;
_debug_symbol_dsDesc._debug_symbol_DepthEnable = true;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mNoDepthDS));
_debug_symbol_dsDesc._debug_symbol_DepthEnable = false;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mFontDS));
}
void _debug_symbol_InClassProj::_debug_symbol_InitBoundingSpheres()
{
float radius = 1.1f;
_debug_symbol_mBSPlayer._debug_symbol_Radius = radius;
_debug_symbol_mBSPlayer._debug_symbol_Centre = _debug_symbol_XMFLOAT3(_debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[2]);
_debug_symbol_mBSTower._debug_symbol_Radius = radius * 10;
_debug_symbol_mBSTower._debug_symbol_Centre = _debug_symbol_XMFLOAT3(_debug_symbol_mTower->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_mTower->GetPos()._debug_symbol_m128_f32[2]);
_debug_symbol_mBSEnemy1._debug_symbol_Radius = radius;
_debug_symbol_mBSEnemy1._debug_symbol_Centre = _debug_symbol_XMFLOAT3(_debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[2]);
}
void _debug_symbol_InClassProj::OnResize()
{
_debug_symbol_D3DApp::OnResize();
_debug_symbol_XMMATRIX _debug_symbol_P = _debug_symbol_XMMatrixPerspectiveFovLH(0.25f*_debug_symbol_MathHelper::_debug_symbol_Pi, _debug_symbol_AspectRatio(), 1.0f, 1000.0f);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mProj, _debug_symbol_P);
_debug_symbol_P = _debug_symbol_XMMatrixOrthographicOffCenterLH(0.0f, _debug_symbol_mClientWidth, 0.0f, _debug_symbol_mClientHeight, 0.0001f, 1000.0f);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_P);
}
void _debug_symbol_InClassProj::_debug_symbol_SphereBoxCollision()
{
_debug_symbol_XNA::_debug_symbol_Sphere bs;
bs.Center = _debug_symbol_mBSPlayer._debug_symbol_Centre;
bs._debug_symbol_Radius = _debug_symbol_mBSPlayer._debug_symbol_Radius;
_debug_symbol_XNA::_debug_symbol_Sphere _debug_symbol_bs1;
_debug_symbol_bs1.Center = _debug_symbol_mBSEnemy1._debug_symbol_Centre;
_debug_symbol_bs1._debug_symbol_Radius = _debug_symbol_mBSEnemy1._debug_symbol_Radius;
_debug_symbol_XNA::_debug_symbol_OrientedBox* p1 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p1Pos = _debug_symbol_XMVectorSet(-6.238f, 2.76f, 10.755f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p1Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p1Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p1Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p1Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
p1->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p1Rot._debug_symbol_m128_f32[0], _debug_symbol_p1Rot._debug_symbol_m128_f32[1], _debug_symbol_p1Rot._debug_symbol_m128_f32[2]);
p1->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
p1->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir1;
float _debug_symbol_overlap1 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, p1, _debug_symbol_dir1);
if (_debug_symbol_overlap1 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir1) * _debug_symbol_overlap1;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* p2 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p2Pos = _debug_symbol_XMVectorSet(-9.958f, 5.184f, 7.329f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p2Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p2Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p2Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p2Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
p2->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p2Rot._debug_symbol_m128_f32[0], _debug_symbol_p2Rot._debug_symbol_m128_f32[1], _debug_symbol_p2Rot._debug_symbol_m128_f32[2]);
p2->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
p2->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir2;
float _debug_symbol_overlap2 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, p2, _debug_symbol_dir2);
if (_debug_symbol_overlap2 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir2) * _debug_symbol_overlap2;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* p3 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p3Pos = _debug_symbol_XMVectorSet(-12.18f, 6.687f, 2.102f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p3Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p3Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p3Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p3Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
p3->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p3Rot._debug_symbol_m128_f32[0], _debug_symbol_p3Rot._debug_symbol_m128_f32[1], _debug_symbol_p3Rot._debug_symbol_m128_f32[2]);
p3->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
p3->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir3;
float _debug_symbol_overlap3 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, p3, _debug_symbol_dir3);
if (_debug_symbol_overlap3 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir3) * _debug_symbol_overlap3;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p4 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p4Pos = _debug_symbol_XMVectorSet(-12.001f, 8.039f, -2.912f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p4Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p4Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p4Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p4Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p4->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p4Rot._debug_symbol_m128_f32[0], _debug_symbol_p4Rot._debug_symbol_m128_f32[1], _debug_symbol_p4Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p4->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p4->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir4;
float _debug_symbol_overlap4 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p4, _debug_symbol_dir4);
if (_debug_symbol_overlap4 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir4) * _debug_symbol_overlap4;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p5 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p5Pos = _debug_symbol_XMVectorSet(-9.658f, 9.55f, -7.65f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p5Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p5Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p5Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p5Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p5->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p5Rot._debug_symbol_m128_f32[0], _debug_symbol_p5Rot._debug_symbol_m128_f32[1], _debug_symbol_p5Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p5->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p5->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir5;
float _debug_symbol_overlap5 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p5, _debug_symbol_dir5);
if (_debug_symbol_overlap5 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir5) * _debug_symbol_overlap5;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p6 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p6Pos = _debug_symbol_XMVectorSet(-5.397f, 10.528f, -11.187f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p6Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p6Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p6Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p6Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p6->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p6Rot._debug_symbol_m128_f32[0], _debug_symbol_p6Rot._debug_symbol_m128_f32[1], _debug_symbol_p6Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p6->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p6->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir6;
float _debug_symbol_overlap6 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p6, _debug_symbol_dir6);
if (_debug_symbol_overlap6 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir6) * _debug_symbol_overlap6;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XMVECTOR _debug_symbol_p66Pos = _debug_symbol_XMVectorSet(-5.397f, 11.028f, -11.187f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p66Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p66Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p66Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p66Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mEnemy1->GetPos()));
_debug_symbol_XMFLOAT3 _debug_symbol_dir66;
float _debug_symbol_overlap66 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&_debug_symbol_bs1, _debug_symbol_p6, _debug_symbol_dir66);
if (_debug_symbol_overlap66 > 0.0f)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_mEnemy1->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir66) * _debug_symbol_overlap66;
pos = pos + move;
_debug_symbol_mEnemy1->SetPos(pos);
_debug_symbol_mEnemy1->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p7 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p7Pos = _debug_symbol_XMVectorSet(-0.159f, 12.336f, -12.374f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p7Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p7Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p7Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p7Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p7->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p7Rot._debug_symbol_m128_f32[0], _debug_symbol_p7Rot._debug_symbol_m128_f32[1], _debug_symbol_p7Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p7->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p7->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir7;
float _debug_symbol_overlap7 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p7, _debug_symbol_dir7);
if (_debug_symbol_overlap7 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir7) * _debug_symbol_overlap7;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p8 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p8Pos = _debug_symbol_XMVectorSet(4.716f, 13.779f, -11.399f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p8Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p8Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p8Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p8Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p8->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p8Rot._debug_symbol_m128_f32[0], _debug_symbol_p8Rot._debug_symbol_m128_f32[1], _debug_symbol_p8Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p8->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p8->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir8;
float _debug_symbol_overlap8 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p8, _debug_symbol_dir8);
if (_debug_symbol_overlap8 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir8) * _debug_symbol_overlap8;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p9 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p9Pos = _debug_symbol_XMVectorSet(9.271f, 14.719f, -8.259f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p9Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p9Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p9Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p9Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p9->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p9Rot._debug_symbol_m128_f32[0], _debug_symbol_p9Rot._debug_symbol_m128_f32[1], _debug_symbol_p9Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p9->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p9->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir9;
float _debug_symbol_overlap9 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p9, _debug_symbol_dir9);
if (_debug_symbol_overlap9 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir9) * _debug_symbol_overlap9;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p10 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p10Pos = _debug_symbol_XMVectorSet(12.044f, 16.235f, -2.835f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p10Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p10Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p10Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p10Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p10->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p10Rot._debug_symbol_m128_f32[0], _debug_symbol_p10Rot._debug_symbol_m128_f32[1], _debug_symbol_p10Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p10->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p10->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir10;
float _debug_symbol_overlap10 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p10, _debug_symbol_dir10);
if (_debug_symbol_overlap10 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir10) * _debug_symbol_overlap10;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p11 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p11Pos = _debug_symbol_XMVectorSet(12.092f, 17.878f, 2.811f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p11Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p11Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p11Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p11Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p11->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p11Rot._debug_symbol_m128_f32[0], _debug_symbol_p11Rot._debug_symbol_m128_f32[1], _debug_symbol_p11Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p11->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p11->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir11;
float _debug_symbol_overlap11 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p11, _debug_symbol_dir11);
if (_debug_symbol_overlap11 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir11) * _debug_symbol_overlap11;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p12 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p12Pos = _debug_symbol_XMVectorSet(9.177f, 19.008f, 8.357f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p12Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p12Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p12Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p12Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p12->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p12Rot._debug_symbol_m128_f32[0], _debug_symbol_p12Rot._debug_symbol_m128_f32[1], _debug_symbol_p12Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p12->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p12->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir12;
float _debug_symbol_overlap12 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p12, _debug_symbol_dir12);
if (_debug_symbol_overlap12 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir12) * _debug_symbol_overlap12;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p13 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p13Pos = _debug_symbol_XMVectorSet(3.727f, 20.179f, 11.816f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p13Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p13Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p13Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p13Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p13->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p13Rot._debug_symbol_m128_f32[0], _debug_symbol_p13Rot._debug_symbol_m128_f32[1], _debug_symbol_p13Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p13->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p13->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir13;
float _debug_symbol_overlap13 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p13, _debug_symbol_dir13);
if (_debug_symbol_overlap13 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir13) * _debug_symbol_overlap13;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p14 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p14Pos = _debug_symbol_XMVectorSet(-2.899f, 21.435f, 12.103f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p14Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p14Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p14Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p14Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p14->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p14Rot._debug_symbol_m128_f32[0], _debug_symbol_p14Rot._debug_symbol_m128_f32[1], _debug_symbol_p14Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p14->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p14->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir14;
float _debug_symbol_overlap14 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p14, _debug_symbol_dir14);
if (_debug_symbol_overlap14 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir14) * _debug_symbol_overlap14;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p15 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p15Pos = _debug_symbol_XMVectorSet(-8.274f, 23.149f, 9.3f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p15Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p15Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p15Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p15Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p15->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p15Rot._debug_symbol_m128_f32[0], _debug_symbol_p15Rot._debug_symbol_m128_f32[1], _debug_symbol_p15Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p15->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p15->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir15;
float _debug_symbol_overlap15 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p15, _debug_symbol_dir15);
if (_debug_symbol_overlap15 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir15) * _debug_symbol_overlap15;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p16 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p16Pos = _debug_symbol_XMVectorSet(-11.532f, 25.008f, 4.737f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p16Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p16Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p16Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p16Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p16->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p16Rot._debug_symbol_m128_f32[0], _debug_symbol_p16Rot._debug_symbol_m128_f32[1], _debug_symbol_p16Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p16->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p16->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir16;
float _debug_symbol_overlap16 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p16, _debug_symbol_dir16);
if (_debug_symbol_overlap16 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir16) * _debug_symbol_overlap16;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p17 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p17Pos = _debug_symbol_XMVectorSet(-12.391f, 27.048f, -1.085f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p17Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p17Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p17Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p17Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p17->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p17Rot._debug_symbol_m128_f32[0], _debug_symbol_p17Rot._debug_symbol_m128_f32[1], _debug_symbol_p17Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p17->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p17->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir17;
float _debug_symbol_overlap17 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p17, _debug_symbol_dir17);
if (_debug_symbol_overlap17 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir17) * _debug_symbol_overlap17;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p18 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p18Pos = _debug_symbol_XMVectorSet(-10.212f, 28.829f, -7.054f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p18Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p18Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p18Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p18Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p18->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p18Rot._debug_symbol_m128_f32[0], _debug_symbol_p18Rot._debug_symbol_m128_f32[1], _debug_symbol_p18Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p18->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p18->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir18;
float _debug_symbol_overlap18 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p18, _debug_symbol_dir18);
if (_debug_symbol_overlap18 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir18) * _debug_symbol_overlap18;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p19 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p19Pos = _debug_symbol_XMVectorSet(-5.173f, 30.057f, -11.352f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p19Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p19Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p19Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p19Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p19->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p19Rot._debug_symbol_m128_f32[0], _debug_symbol_p19Rot._debug_symbol_m128_f32[1], _debug_symbol_p19Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p19->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p19->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir19;
float _debug_symbol_overlap19 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p19, _debug_symbol_dir19);
if (_debug_symbol_overlap19 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir19) * _debug_symbol_overlap19;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p20 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p20Pos = _debug_symbol_XMVectorSet(1.194f, 32.002f, -12.362f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p20Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p20Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p20Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p20Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p20->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p20Rot._debug_symbol_m128_f32[0], _debug_symbol_p20Rot._debug_symbol_m128_f32[1], _debug_symbol_p20Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p20->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p20->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir20;
float _debug_symbol_overlap20 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p20, _debug_symbol_dir20);
if (_debug_symbol_overlap20 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir20) * _debug_symbol_overlap20;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p21 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p21Pos = _debug_symbol_XMVectorSet(6.928f, 33.232f, -10.292f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p21Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p21Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p21Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p21Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p21->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p21Rot._debug_symbol_m128_f32[0], _debug_symbol_p21Rot._debug_symbol_m128_f32[1], _debug_symbol_p21Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p21->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p21->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir21;
float _debug_symbol_overlap21 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p21, _debug_symbol_dir21);
if (_debug_symbol_overlap21 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir21) * _debug_symbol_overlap21;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p22 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p22Pos = _debug_symbol_XMVectorSet(10.984f, 34.597f, -5.702f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p22Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p22Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p22Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p22Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p22->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p22Rot._debug_symbol_m128_f32[0], _debug_symbol_p22Rot._debug_symbol_m128_f32[1], _debug_symbol_p22Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p22->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p22->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir22;
float _debug_symbol_overlap22 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p22, _debug_symbol_dir22);
if (_debug_symbol_overlap22 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir22) * _debug_symbol_overlap22;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p23 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p23Pos = _debug_symbol_XMVectorSet(12.434f, 35.788f, -0.13f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p23Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p23Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p23Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p23Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p23->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p23Rot._debug_symbol_m128_f32[0], _debug_symbol_p23Rot._debug_symbol_m128_f32[1], _debug_symbol_p23Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p23->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p23->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir23;
float _debug_symbol_overlap23 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p23, _debug_symbol_dir23);
if (_debug_symbol_overlap23 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir23) * _debug_symbol_overlap23;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p24 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p24Pos = _debug_symbol_XMVectorSet(10.97f, 36.975f, 5.868f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p24Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p24Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p24Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p24Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p24->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p24Rot._debug_symbol_m128_f32[0], _debug_symbol_p24Rot._debug_symbol_m128_f32[1], _debug_symbol_p24Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p24->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p24->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir24;
float _debug_symbol_overlap24 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p24, _debug_symbol_dir24);
if (_debug_symbol_overlap24 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir24) * _debug_symbol_overlap24;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p25 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p25Pos = _debug_symbol_XMVectorSet(7.08f, 38.441f, 10.25f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p25Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p25Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p25Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p25Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p25->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p25Rot._debug_symbol_m128_f32[0], _debug_symbol_p25Rot._debug_symbol_m128_f32[1], _debug_symbol_p25Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p25->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p25->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir25;
float _debug_symbol_overlap25 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p25, _debug_symbol_dir25);
if (_debug_symbol_overlap25 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir25) * _debug_symbol_overlap25;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p26 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p26Pos = _debug_symbol_XMVectorSet(1.145f, 40.211f, 12.356f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p26Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p26Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p26Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p26Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p26->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p26Rot._debug_symbol_m128_f32[0], _debug_symbol_p26Rot._debug_symbol_m128_f32[1], _debug_symbol_p26Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p26->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p26->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir26;
float _debug_symbol_overlap26 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p26, _debug_symbol_dir26);
if (_debug_symbol_overlap26 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir26) * _debug_symbol_overlap26;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_p27 = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMVECTOR _debug_symbol_p27Pos = _debug_symbol_XMVectorSet(-4.436f, 42.315f, 11.61f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_p27Rot = _debug_symbol_XMVector3TransformNormal(_debug_symbol_p27Pos, _debug_symbol_XMMatrixRotationY(angle));
_debug_symbol_p27Rot = _debug_symbol_XMVector3TransformCoord(_debug_symbol_p27Rot, _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_mTower->GetPos()));
_debug_symbol_p27->Center = _debug_symbol_XMFLOAT3(_debug_symbol_p27Rot._debug_symbol_m128_f32[0], _debug_symbol_p27Rot._debug_symbol_m128_f32[1], _debug_symbol_p27Rot._debug_symbol_m128_f32[2]);
_debug_symbol_p27->Extents = _debug_symbol_XMFLOAT3(0.3f, 0.1f, 0.3f);
_debug_symbol_p27->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
_debug_symbol_XMFLOAT3 _debug_symbol_dir27;
float _debug_symbol_overlap27 = _debug_symbol_XNA::_debug_symbol_OverlapSphereOrientedBox(&bs, _debug_symbol_p27, _debug_symbol_dir27);
if (_debug_symbol_overlap27 > 0.0f)
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR move = _debug_symbol_XMLoadFloat3(&_debug_symbol_dir27) * _debug_symbol_overlap27;
_debug_symbol_playerPos = _debug_symbol_playerPos + move;
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_playerPos);
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
_debug_symbol_mIsGameWon = true;
}
}
void _debug_symbol_InClassProj::_debug_symbol_UpdateScene(float dt)
{
_debug_symbol_mTimer++;
_debug_symbol_XMVECTOR _debug_symbol_towerPos;
_debug_symbol_towerPos._debug_symbol_m128_f32[0] = _debug_symbol_mBSTower._debug_symbol_Centre.x;
_debug_symbol_towerPos._debug_symbol_m128_f32[1] = _debug_symbol_mBSTower._debug_symbol_Centre.y;
_debug_symbol_towerPos._debug_symbol_m128_f32[2] = _debug_symbol_mBSTower._debug_symbol_Centre._debug_symbol_z;
_debug_symbol_XMVECTOR _debug_symbol_toTower = _debug_symbol_towerPos - _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_toTower = _debug_symbol_XMVector3Normalize(_debug_symbol_toTower);
_debug_symbol_mTestPlayer->_debug_symbol_SetFacing(_debug_symbol_toTower, _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f));
_debug_symbol_UpdateKeyboardInput(dt);
_debug_symbol_mTestPlayer->_debug_symbol_AddForce(_debug_symbol_XMVectorSet(0.0f, -50.0f * dt, 0.0f, 0.0f));
_debug_symbol_mTestPlayer->Update(dt);
_debug_symbol_mTower->Update(dt);
_debug_symbol_mEnemy1->Update(dt);
_debug_symbol_UpdateGroundCollision();
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_XMVECTOR _debug_symbol_toPlayer = _debug_symbol_playerPos - _debug_symbol_mCam->GetPos();
_debug_symbol_toPlayer = _debug_symbol_XMVector3Normalize(_debug_symbol_toPlayer);
_debug_symbol_mCam->_debug_symbol_SetFacing(_debug_symbol_toPlayer, _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f));
_debug_symbol_mCam->Update();
_debug_symbol_m2DCam->Update();
_debug_symbol_XMStoreFloat3(&_debug_symbol_mSpotLight.pos, _debug_symbol_mCam->GetPos());
_debug_symbol_XMStoreFloat3(&_debug_symbol_mSpotLight._debug_symbol_direction, _debug_symbol_mCam->_debug_symbol_GetLook());
_debug_symbol_UpdateBoundingSpheres();
_debug_symbol_SphereBoxCollision();
if (_debug_symbol_mIsGameOver)
{
_debug_symbol_overTimer++;
}
}
void _debug_symbol_InClassProj::_debug_symbol_DrawScene()
{
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearRenderTargetView(_debug_symbol_mRenderTargetView, reinterpret_cast<const float*>(&_debug_symbol_Colors::Black));
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearDepthStencilView(_debug_symbol_mDepthStencilView, _debug_symbol_D3D11_CLEAR_DEPTH | _debug_symbol_D3D11_CLEAR_STENCIL, 1.0f, 0);
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_XMVECTOR _debug_symbol_ambient = _debug_symbol_XMLoadFloat4(&_debug_symbol_mAmbientColour);
_debug_symbol_XMVECTOR _debug_symbol_eyePos = _debug_symbol_XMVectorSet(_debug_symbol_mCam->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mCam->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_mCam->GetPos()._debug_symbol_m128_f32[2], 0.0f);
_debug_symbol_XMMATRIX _debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_mProj);
_debug_symbol_XMMATRIX _debug_symbol_view = _debug_symbol_mCam->GetView();
_debug_symbol_mLitTexEffect->_debug_symbol_SetPerFrameParams(_debug_symbol_ambient, _debug_symbol_eyePos, _debug_symbol_mPointLight, _debug_symbol_mSpotLight);
_debug_symbol_mTestTerrain->_debug_symbol_GetEffect()->_debug_symbol_SetPerFrameParams(_debug_symbol_ambient, _debug_symbol_eyePos, _debug_symbol_mPointLight, _debug_symbol_mSpotLight);
_debug_symbol_XMMATRIX vp = _debug_symbol_view * _debug_symbol_proj;
_debug_symbol_mSky->Draw(_debug_symbol_md3dImmediateContext, vp, _debug_symbol_eyePos);
_debug_symbol_mTestTerrain->Draw(_debug_symbol_md3dImmediateContext, vp);
_debug_symbol_mTower->Draw(_debug_symbol_md3dImmediateContext, vp);
_debug_symbol_mTestPlayer->Draw(_debug_symbol_md3dImmediateContext, vp);
vp = _debug_symbol_XMMatrixIdentity();
_debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj);
_debug_symbol_view = _debug_symbol_m2DCam->GetView();
vp = vp * _debug_symbol_view * _debug_symbol_proj;
float _debug_symbol_blendFactor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetBlendState(_debug_symbol_mTransparentBS, _debug_symbol_blendFactor, 0xffffffff);
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetDepthStencilState(_debug_symbol_mFontDS, 0);
_debug_symbol_mLitTexEffect->_debug_symbol_SetAmbient(_debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 1.0f));
_debug_symbol_mFont->_debug_symbol_DrawFont(_debug_symbol_md3dImmediateContext, _debug_symbol_XMVectorSet(275.0f, 700.0f, 0.0f, 0.0f), 50, 75, 10,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Nebulus 3D")));
if (_debug_symbol_mTimer <= 500)
{
_debug_symbol_isSplashing = true;
_debug_symbol_mFont->_debug_symbol_DrawFont(_debug_symbol_md3dImmediateContext, _debug_symbol_XMVectorSet(178.0f, 235.0f, 0.0f, 0.0f), 25, 75, 29,
decrypt::_debug_symbol_dec_debug(_T( "_debug_Get to the top of the tower  without falling in the water    -press SPACE to jump")));
}
else
{
_debug_symbol_isSplashing = false;
}
if (_debug_symbol_mIsGameWon)
{
_debug_symbol_mFont->_debug_symbol_DrawFont(_debug_symbol_md3dImmediateContext, _debug_symbol_XMVectorSet(235.0f, 550.0f, 0.0f, 0.0f), 75, 200, 10,  decrypt::_debug_symbol_dec_debug(_T( "_debug_You Win!")));
_debug_symbol_started = false;
}
if (_debug_symbol_mIsGameOver)
{
_debug_symbol_mFont->_debug_symbol_DrawFont(_debug_symbol_md3dImmediateContext, _debug_symbol_XMVectorSet(150.0f, 450.0f, 0.0f, 0.0f), 75, 200, 10,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Game Over!")));
_debug_symbol_started = false;
}
if (_debug_symbol_overTimer > 100)
{
exit(1);
}
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetDepthStencilState(0, 0);
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetBlendState(0, _debug_symbol_blendFactor, 0xffffffff);
_debug_symbol_HR(_debug_symbol_mSwapChain->_debug_symbol_Present(1, 0));
}
void _debug_symbol_InClassProj::_debug_symbol_OnMouseDown(WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
SetCapture(_debug_symbol_mhMainWnd);
}
void _debug_symbol_InClassProj::_debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mMouseReleased = false;
ReleaseCapture();
}
void _debug_symbol_InClassProj::OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y)
{
if ((_debug_symbol_btnState & MK_LBUTTON) != 0)
{
float dx = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(x - _debug_symbol_mLastMousePos.x));
float dy = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(y - _debug_symbol_mLastMousePos.y));
}
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
}
void _debug_symbol_InClassProj::_debug_symbol_UpdateKeyboardInput(float dt)
{
float _debug_symbol_rotation = 0.0f;
_debug_symbol_rotation = dt;
if (GetAsyncKeyState(VK_SPACE) & 0x8000)
{
_debug_symbol_mTestPlayer->_debug_symbol_Jump();
}
if (GetAsyncKeyState('A') & 0x8000 || GetAsyncKeyState(VK_LEFT) & 0x8000)
{
_debug_symbol_mTower->_debug_symbol_YawLocal(-_debug_symbol_rotation);
angle -= _debug_symbol_rotation;
_debug_symbol_mEnemy1->_debug_symbol_YawLocal(-_debug_symbol_rotation);
}
if (GetAsyncKeyState('D') & 0x8000 || GetAsyncKeyState(VK_RIGHT) & 0x8000)
{
_debug_symbol_mTower->_debug_symbol_YawLocal(_debug_symbol_rotation);
angle += _debug_symbol_rotation;
_debug_symbol_mEnemy1->_debug_symbol_YawLocal(_debug_symbol_rotation);
}
}
void _debug_symbol_InClassProj::_debug_symbol_UpdateGroundCollision()
{
_debug_symbol_XMVECTOR _debug_symbol_playerPos = _debug_symbol_mTestPlayer->GetPos();
float _debug_symbol_terrainHeight = _debug_symbol_mTestTerrain->GetHeight(_debug_symbol_playerPos._debug_symbol_m128_f32[0], _debug_symbol_playerPos._debug_symbol_m128_f32[2]);
if (_debug_symbol_playerPos._debug_symbol_m128_f32[1] <= _debug_symbol_terrainHeight)
{
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_playerPos._debug_symbol_m128_f32[0], _debug_symbol_terrainHeight, _debug_symbol_playerPos._debug_symbol_m128_f32[2], 1.0f));
_debug_symbol_mTestPlayer->_debug_symbol_HitGround();
if (_debug_symbol_started && !_debug_symbol_isSplashing)
{
_debug_symbol_mIsGameOver = true;
}
}
else
{
_debug_symbol_mTestPlayer->_debug_symbol_LeaveGround();
_debug_symbol_started = true;
}
}
void _debug_symbol_InClassProj::_debug_symbol_UpdateBoundingSpheres()
{
_debug_symbol_mBSPlayer._debug_symbol_Centre.x = _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_mBSPlayer._debug_symbol_Centre.y = _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[1];
_debug_symbol_mBSPlayer._debug_symbol_Centre._debug_symbol_z = _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[2];
_debug_symbol_mBSTower._debug_symbol_Centre.x = _debug_symbol_mTower->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_mBSTower._debug_symbol_Centre.y = _debug_symbol_mTestPlayer->GetPos()._debug_symbol_m128_f32[1];
_debug_symbol_mBSTower._debug_symbol_Centre._debug_symbol_z = _debug_symbol_mTower->GetPos()._debug_symbol_m128_f32[2];
_debug_symbol_mBSEnemy1._debug_symbol_Centre.x = _debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_mBSEnemy1._debug_symbol_Centre.y = _debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[1];
_debug_symbol_mBSEnemy1._debug_symbol_Centre._debug_symbol_z = _debug_symbol_mEnemy1->GetPos()._debug_symbol_m128_f32[2];
_debug_symbol_XMVECTOR diff;
diff = _debug_symbol_XMVectorSet(_debug_symbol_mBSTower._debug_symbol_Centre.x - _debug_symbol_mBSPlayer._debug_symbol_Centre.x, 0.0f, _debug_symbol_mBSTower._debug_symbol_Centre._debug_symbol_z - _debug_symbol_mBSPlayer._debug_symbol_Centre._debug_symbol_z, 0.0f);
float _debug_symbol_distance = _debug_symbol_XMVector3Length(diff)._debug_symbol_m128_f32[0];
float _debug_symbol_overlap = (_debug_symbol_mBSPlayer._debug_symbol_Radius + _debug_symbol_mBSTower._debug_symbol_Radius) - _debug_symbol_distance;
if (_debug_symbol_overlap > 0)
{
_debug_symbol_XMVECTOR _debug_symbol_moveOverlap = _debug_symbol_XMVectorZero();
_debug_symbol_moveOverlap = _debug_symbol_XMVector3Normalize(diff) * -_debug_symbol_overlap;
_debug_symbol_moveOverlap = _debug_symbol_moveOverlap + _debug_symbol_mTestPlayer->GetPos();
_debug_symbol_mTestPlayer->SetPos(_debug_symbol_moveOverlap);
}
}
_debug_symbol_XNA::_debug_symbol_OrientedBox* _debug_symbol_InClassProj::_debug_symbol_GetOrientedBox(_debug_symbol_FXMVECTOR _debug_symbol_extents, const _debug_symbol_GraphicalObject* obj)
{
_debug_symbol_XNA::_debug_symbol_OrientedBox* ret = new _debug_symbol_XNA::_debug_symbol_OrientedBox();
_debug_symbol_XMStoreFloat3(&ret->Extents, _debug_symbol_extents);
_debug_symbol_XMStoreFloat3(&ret->Center, obj->GetPos());
_debug_symbol_XMMATRIX _debug_symbol_rot =
_debug_symbol_XMMatrixSet(
obj->GetRight()._debug_symbol_m128_f32[0], obj->GetRight()._debug_symbol_m128_f32[1], obj->GetRight()._debug_symbol_m128_f32[2], 0.0f,
obj->_debug_symbol_GetUp()._debug_symbol_m128_f32[0],    obj->_debug_symbol_GetUp()._debug_symbol_m128_f32[1],    obj->_debug_symbol_GetUp()._debug_symbol_m128_f32[2],    0.0f,
obj->_debug_symbol_GetLook()._debug_symbol_m128_f32[0],  obj->_debug_symbol_GetLook()._debug_symbol_m128_f32[1],  obj->_debug_symbol_GetLook()._debug_symbol_m128_f32[2],  0.0f,
0.0f,       0.0f,        0.0f,         1.0f);
_debug_symbol_XMStoreFloat4(&ret->_debug_symbol_Orientation, _debug_symbol_XMQuaternionRotationMatrix(_debug_symbol_rot));
return ret;
}

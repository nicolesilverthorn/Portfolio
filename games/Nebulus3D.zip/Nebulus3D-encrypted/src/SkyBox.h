#pragma once
#include "d3dUtil.h"
#include "effect.h"
class _debug_symbol_SkyBox
{
public:
_debug_symbol_SkyBox(_debug_symbol_ID3D11Device* device, float _debug_symbol_skySphereRadius,
const std::wstring& _debug_symbol_cubmapFilename);
~_debug_symbol_SkyBox();
void Draw(_debug_symbol_ID3D11DeviceContext* dc, _debug_symbol_CXMMATRIX vp,
_debug_symbol_FXMVECTOR _debug_symbol_eye);
private:
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_mCubeMapSRV;
_debug_symbol_ID3D11Buffer* _debug_symbol_mIB, * _debug_symbol_mVB;
_debug_symbol_SkyBoxEffect* _debug_symbol_mSkyBoxEffect;
int _debug_symbol_mIndexCount;
};

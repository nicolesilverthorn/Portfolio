#include "terrain.h"
#include "vertex.h"
_debug_symbol_Terrain::~_debug_symbol_Terrain(void)
{
for (int i = 0; i < 4; ++i)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mDiffuseMaps[i]);
}
delete[] _debug_symbol_mDiffuseMaps;
_debug_symbol_ReleaseCOM(_debug_symbol_mBlendMap);
delete _debug_symbol_mEffect;
}
void _debug_symbol_Terrain::Init(_debug_symbol_ID3D11Device* device, const _debug_symbol_InitInfo& info)
{
_debug_symbol_mTerrainData = info;
_debug_symbol_LoadHeightMap();
_debug_symbol_InitVB(device);
_debug_symbol_InitIB(device);
_debug_symbol_mEffect = new _debug_symbol_TerrainEffect();
_debug_symbol_mEffect->_debug_symbol_LoadEffect( decrypt::_debug_symbol_dec_debug(_T( "_debug_FX/terrain.fx")), device);
_debug_symbol_LoadTextures(device);
}
void _debug_symbol_Terrain::_debug_symbol_LoadTextures(_debug_symbol_ID3D11Device* device)
{
_debug_symbol_mDiffuseMaps = new _debug_symbol_ID3D11ShaderResourceView*[4];
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_mTerrainData._debug_symbol_layerMapFilename0.c_str(), 0, 0, &_debug_symbol_mDiffuseMaps[0], 0));
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_mTerrainData._debug_symbol_layerMapFilename1.c_str(), 0, 0, &_debug_symbol_mDiffuseMaps[1], 0));
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_mTerrainData._debug_symbol_layerMapFilename2.c_str(), 0, 0, &_debug_symbol_mDiffuseMaps[2], 0));
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_mTerrainData._debug_symbol_layerMapFilename3.c_str(), 0, 0, &_debug_symbol_mDiffuseMaps[3], 0));
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_mTerrainData._debug_symbol_blendMapFilename.c_str(), 0, 0, &_debug_symbol_mBlendMap, 0));
}
void _debug_symbol_Terrain::_debug_symbol_LoadHeightMap()
{
std::vector<unsigned char> in(_debug_symbol_mTerrainData.width * _debug_symbol_mTerrainData.height);
std::ifstream _debug_symbol_inFile;
_debug_symbol_inFile.open(_debug_symbol_mTerrainData._debug_symbol_heightMapFilename, std::_debug_symbol_ios_base::_debug_symbol_binary);
if (_debug_symbol_inFile)
{
_debug_symbol_inFile.read((char*)&in[0], (std::_debug_symbol_streamsize)in.size());
_debug_symbol_inFile.close();
}
_debug_symbol_mHeightMap.resize(_debug_symbol_mTerrainData.height *  _debug_symbol_mTerrainData.width, 0);
for (UINT i = 0; i < _debug_symbol_mTerrainData.height * _debug_symbol_mTerrainData.width; ++i)
{
_debug_symbol_mHeightMap[i] = (in[i] / 255.0f)*_debug_symbol_mTerrainData._debug_symbol_heightScale;
}
}
void _debug_symbol_Terrain::_debug_symbol_InitVB(_debug_symbol_ID3D11Device* device)
{
std::vector<Vertex::_debug_symbol_TerrainVertex> _debug_symbol_vertexData(_debug_symbol_mTerrainData.width * _debug_symbol_mTerrainData.height);
UINT _debug_symbol_cellsWide = _debug_symbol_mTerrainData.width - 1;
UINT _debug_symbol_cellsHigh = _debug_symbol_mTerrainData.height - 1;
for (int row = 0; row < _debug_symbol_mTerrainData.height; ++row)
{
for (int col = 0; col < _debug_symbol_mTerrainData.width; ++col)
{
UINT index = row * _debug_symbol_mTerrainData.width + col;
_debug_symbol_vertexData[index].pos = _debug_symbol_XMFLOAT3(col * _debug_symbol_mTerrainData._debug_symbol_cellWidth, _debug_symbol_mHeightMap[index], row * _debug_symbol_mTerrainData._debug_symbol_cellHeight);
float _debug_symbol_u = _debug_symbol_mTerrainData._debug_symbol_texTilesWide / _debug_symbol_mTerrainData.width;
_debug_symbol_u *= col;
float v = _debug_symbol_mTerrainData._debug_symbol_texTilesHigh / _debug_symbol_mTerrainData.height;
v *= row;
_debug_symbol_vertexData[index]._debug_symbol_tiledTex.x = _debug_symbol_u;
_debug_symbol_vertexData[index]._debug_symbol_tiledTex.y = v;
_debug_symbol_u = (float)col / (_debug_symbol_mTerrainData.width - 1);
v = (float)row / (_debug_symbol_mTerrainData.height - 1);
_debug_symbol_vertexData[index]._debug_symbol_tex.x = _debug_symbol_u;
_debug_symbol_vertexData[index]._debug_symbol_tex.y = v;
}
}
std::vector<_debug_symbol_XMFLOAT3> normals;
for (int row = 0; row < _debug_symbol_cellsHigh; ++row)
{
for (int col = 0; col < _debug_symbol_cellsWide; ++col)
{
UINT top = row + 1;
UINT right = col + 1;
UINT _debug_symbol_bot = row;
UINT left = col;
_debug_symbol_XMVECTOR _debug_symbol_A = _debug_symbol_XMVectorSet(0.0f, _debug_symbol_mHeightMap[top * _debug_symbol_mTerrainData.width + left] -
_debug_symbol_mHeightMap[_debug_symbol_bot * _debug_symbol_mTerrainData.width + left], _debug_symbol_mTerrainData._debug_symbol_cellHeight, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_B = _debug_symbol_XMVectorSet(_debug_symbol_mTerrainData._debug_symbol_cellWidth, _debug_symbol_mHeightMap[_debug_symbol_bot * _debug_symbol_mTerrainData.width + right] -
_debug_symbol_mHeightMap[_debug_symbol_bot * _debug_symbol_mTerrainData.width + left], 0.0f, 0.0f);
_debug_symbol_XMVECTOR C = _debug_symbol_XMVectorSet(_debug_symbol_mTerrainData._debug_symbol_cellWidth, _debug_symbol_mHeightMap[top * _debug_symbol_mTerrainData.width + right] -
_debug_symbol_mHeightMap[top * _debug_symbol_mTerrainData.width + left], 0.0f, 0.0f);
_debug_symbol_XMVECTOR D = _debug_symbol_XMVectorSet(0.0f, _debug_symbol_mHeightMap[top * _debug_symbol_mTerrainData.width + right] -
_debug_symbol_mHeightMap[_debug_symbol_bot * _debug_symbol_mTerrainData.width + right], _debug_symbol_mTerrainData._debug_symbol_cellHeight, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_topNormal = _debug_symbol_XMVector3Cross(D, C);
_debug_symbol_XMVECTOR _debug_symbol_botNormal = _debug_symbol_XMVector3Cross(_debug_symbol_A, _debug_symbol_B);
_debug_symbol_topNormal = _debug_symbol_XMVector3Normalize(_debug_symbol_topNormal);
_debug_symbol_botNormal = _debug_symbol_XMVector3Normalize(_debug_symbol_botNormal);
_debug_symbol_XMFLOAT3 _debug_symbol_topNormalF3, _debug_symbol_botNormalF3;
_debug_symbol_XMStoreFloat3(&_debug_symbol_topNormalF3, _debug_symbol_topNormal);
_debug_symbol_XMStoreFloat3(&_debug_symbol_botNormalF3, _debug_symbol_botNormal);
normals.push_back(_debug_symbol_topNormalF3);
normals.push_back(_debug_symbol_botNormalF3);
}
}
for (int row = 0; row < _debug_symbol_mTerrainData.height; ++row)
{
for (int col = 0; col < _debug_symbol_mTerrainData.width; ++col)
{
UINT index = row * _debug_symbol_mTerrainData.width + col;
int top = row;
int _debug_symbol_bot = row - 1;
int left = col - 1;
int right = col;
int _debug_symbol_normalCounter = 0;
_debug_symbol_XMVECTOR _debug_symbol_normsCombined = _debug_symbol_XMVectorZero();
if (top < _debug_symbol_cellsHigh && left >= 0)
{
UINT _debug_symbol_topLeftIndex = (top * _debug_symbol_cellsWide + left) * 2;
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_topLeftIndex]);
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_topLeftIndex + 1]);
_debug_symbol_normalCounter += 2;
}
if (_debug_symbol_bot >= 0 && left >= 0)
{
UINT _debug_symbol_botLeftIndex = (_debug_symbol_bot * _debug_symbol_cellsWide + left) * 2;
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_botLeftIndex]);
_debug_symbol_normalCounter++;
}
if (top < _debug_symbol_cellsHigh && right < _debug_symbol_cellsWide)
{
UINT _debug_symbol_topRightIndex = (top * _debug_symbol_cellsWide + right) * 2;
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_topRightIndex]);
_debug_symbol_normalCounter++;
}
if (_debug_symbol_bot >= 0 && right < _debug_symbol_cellsWide)
{
UINT _debug_symbol_botRightIndex = (_debug_symbol_bot * _debug_symbol_cellsWide + right) * 2;
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_botRightIndex]);
_debug_symbol_normsCombined = _debug_symbol_normsCombined + _debug_symbol_XMLoadFloat3(&normals[_debug_symbol_botRightIndex + 1]);
_debug_symbol_normalCounter += 2;
}
_debug_symbol_normsCombined = _debug_symbol_normsCombined / (float)_debug_symbol_normalCounter;
_debug_symbol_XMStoreFloat3(&(_debug_symbol_vertexData[index].normal), _debug_symbol_normsCombined);
}
}
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(Vertex::_debug_symbol_TerrainVertex) * _debug_symbol_vertexData.size();
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_vbd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = &_debug_symbol_vertexData[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_mVB));
}
void _debug_symbol_Terrain::_debug_symbol_InitIB(_debug_symbol_ID3D11Device* device)
{
UINT _debug_symbol_cellsWide = _debug_symbol_mTerrainData.width - 1;
UINT _debug_symbol_cellsHigh = _debug_symbol_mTerrainData.height - 1;
std::vector<UINT> indices(_debug_symbol_cellsWide * _debug_symbol_cellsHigh * 6);
for (int row = 0; row < _debug_symbol_cellsHigh; ++row)
{
for (int col = 0; col < _debug_symbol_cellsWide; ++col)
{
UINT _debug_symbol_currCell = row * _debug_symbol_cellsWide + col;
UINT _debug_symbol_currIndex = _debug_symbol_currCell * 6;
UINT top = row + 1;
UINT _debug_symbol_bot = row;
UINT right = col + 1;
UINT left = col;
indices[_debug_symbol_currIndex] = top * _debug_symbol_mTerrainData.width + left;
indices[_debug_symbol_currIndex + 1] = top * _debug_symbol_mTerrainData.width + right;
indices[_debug_symbol_currIndex + 2] = _debug_symbol_bot * _debug_symbol_mTerrainData.width + right;
indices[_debug_symbol_currIndex + 3] = _debug_symbol_bot * _debug_symbol_mTerrainData.width + right;
indices[_debug_symbol_currIndex + 4] = _debug_symbol_bot * _debug_symbol_mTerrainData.width + left;
indices[_debug_symbol_currIndex + 5] = top * _debug_symbol_mTerrainData.width + left;
}
}
_debug_symbol_mIndexCount = indices.size();
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(UINT)* _debug_symbol_mIndexCount;
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iinitData;
_debug_symbol_iinitData._debug_symbol_pSysMem = &indices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iinitData, &_debug_symbol_mIB));
}
void _debug_symbol_Terrain::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX vp)
{
context->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetTerrainVertLayout());
context->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_XMMATRIX _debug_symbol_world = _debug_symbol_XMMatrixIdentity();
_debug_symbol_XMMATRIX _debug_symbol_wvp = _debug_symbol_world * vp;
_debug_symbol_mEffect->_debug_symbol_SetPerObjectParams(_debug_symbol_world, _debug_symbol_MathHelper::_debug_symbol_InverseTranspose(_debug_symbol_world), _debug_symbol_wvp, _debug_symbol_mDiffuseMaps[0], _debug_symbol_mDiffuseMaps[1], _debug_symbol_mDiffuseMaps[2], _debug_symbol_mDiffuseMaps[3], _debug_symbol_mBlendMap);
_debug_symbol_mEffect->Draw(context, _debug_symbol_mVB, _debug_symbol_mIB, GetIndexCount());
}
float _debug_symbol_Terrain::GetHeight(float x, float _debug_symbol_z)
{
x = min(_debug_symbol_mTerrainData.width * _debug_symbol_mTerrainData._debug_symbol_cellWidth, x);
x = max(0.0f, x);
_debug_symbol_z = min(_debug_symbol_mTerrainData.height * _debug_symbol_mTerrainData._debug_symbol_cellHeight, _debug_symbol_z);
_debug_symbol_z = max(0.0f, _debug_symbol_z);
float _debug_symbol_c = x / _debug_symbol_mTerrainData._debug_symbol_cellWidth;
float _debug_symbol_r = _debug_symbol_z / _debug_symbol_mTerrainData._debug_symbol_cellHeight;
int row = (int)_debug_symbol_floorf(_debug_symbol_r);
int col = (int)_debug_symbol_floorf(_debug_symbol_c);
float _debug_symbol_A = _debug_symbol_mHeightMap[(row + 1) * _debug_symbol_mTerrainData.width + col];
float _debug_symbol_B = _debug_symbol_mHeightMap[row * _debug_symbol_mTerrainData.width + col];
float C = _debug_symbol_mHeightMap[(row + 1) * _debug_symbol_mTerrainData.width + col + 1];
float D = _debug_symbol_mHeightMap[row * _debug_symbol_mTerrainData.width + col + 1];
float s = _debug_symbol_r - row;
float t = _debug_symbol_c - col;
if (s + t <= 1.0f)
{
float _debug_symbol_BD = D - _debug_symbol_B;
float _debug_symbol_BA = _debug_symbol_A - _debug_symbol_B;
return _debug_symbol_B + _debug_symbol_BD * t + _debug_symbol_BA * s;
}
else
{
float _debug_symbol_CA = _debug_symbol_A - C;
float CD = D - C;
return C + (_debug_symbol_CA * (1.0f - t)) + (CD * (1.0f - s));
}
}

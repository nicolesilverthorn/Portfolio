#include "fpscamera.h"
_debug_symbol_FPSCamera::~_debug_symbol_FPSCamera(void)
{
}
void _debug_symbol_FPSCamera::Pitch(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(right, angle);
_debug_symbol_look = _debug_symbol_XMVector3TransformNormal(_debug_symbol_look, rotate);
_debug_symbol_up = _debug_symbol_XMVector3Cross(_debug_symbol_look, right);
_debug_symbol_up = _debug_symbol_XMVector3Normalize(_debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_FPSCamera::_debug_symbol_YawLocal(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(_debug_symbol_up, angle);
right = _debug_symbol_XMVector3TransformNormal(right, rotate);
_debug_symbol_look = _debug_symbol_XMVector3Cross(_debug_symbol_up, right);
_debug_symbol_look = _debug_symbol_XMVector3Normalize(_debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_FPSCamera::_debug_symbol_YawGlobal(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationY(angle);
right = _debug_symbol_XMVector3TransformNormal(right, rotate);
_debug_symbol_look = _debug_symbol_XMVector3TransformNormal(_debug_symbol_look, rotate);
_debug_symbol_up = _debug_symbol_XMVector3Cross(_debug_symbol_look, right);
_debug_symbol_up = _debug_symbol_XMVector3Normalize(_debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_FPSCamera::_debug_symbol_Roll(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(_debug_symbol_look, angle);
_debug_symbol_up = _debug_symbol_XMVector3TransformNormal(_debug_symbol_up, rotate);
right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
right = _debug_symbol_XMVector3Normalize(right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_FPSCamera::_debug_symbol_MoveLook(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
pos += _debug_symbol_look * _debug_symbol_amt;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_FPSCamera::_debug_symbol_MoveStrafe(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
pos += right * _debug_symbol_amt;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mViewUpdated = true;
}

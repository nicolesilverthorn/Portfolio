#include "basicmodel.h"
#include "objloader.h"
_debug_symbol_BasicModel::_debug_symbol_BasicModel(_debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename, bool _debug_symbol_isRHS, bool _debug_symbol_isVFlipped)
{
_debug_symbol_mModelMesh = new _debug_symbol_MeshGeometry(_debug_symbol_effect);
std::vector<_debug_symbol_ID3D11ShaderResourceView*> _debug_symbol_srvs;
if(_debug_symbol_OBJLoader::_debug_symbol_LoadOBJ(device, filename, _debug_symbol_mVertices, _debug_symbol_mIndices, _debug_symbol_mSubsets, _debug_symbol_isRHS, _debug_symbol_isVFlipped))
{
_debug_symbol_mModelMesh->_debug_symbol_SetVertices(device, &_debug_symbol_mVertices[0], _debug_symbol_mVertices.size());
_debug_symbol_mModelMesh->_debug_symbol_SetIndices(device, &_debug_symbol_mIndices[0], _debug_symbol_mIndices.size());
_debug_symbol_mModelMesh->_debug_symbol_SetSubsetTable(_debug_symbol_mSubsets);
}
}
_debug_symbol_BasicModel::~_debug_symbol_BasicModel(void)
{
}

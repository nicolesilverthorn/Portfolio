#include "skybox.h"
#include "GeometryGenerator.h"
#include "vertex.h"
_debug_symbol_SkyBox::_debug_symbol_SkyBox(_debug_symbol_ID3D11Device* device, float _debug_symbol_skySphereRadius, const std::wstring& _debug_symbol_cubemapFilename)
{
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, _debug_symbol_cubemapFilename.c_str(), 0, 0, &_debug_symbol_mCubeMapSRV, 0));
_debug_symbol_GeometryGenerator::_debug_symbol_MeshData _debug_symbol_sphere;
_debug_symbol_GeometryGenerator _debug_symbol_geoGen;
_debug_symbol_geoGen._debug_symbol_CreateSphere(_debug_symbol_skySphereRadius, 30, 30, _debug_symbol_sphere);
std::vector<_debug_symbol_XMFLOAT3> _debug_symbol_vertices(_debug_symbol_sphere._debug_symbol_Vertices.size());
for (size_t i = 0; i < _debug_symbol_sphere._debug_symbol_Vertices.size(); ++i)
{
_debug_symbol_vertices[i] = _debug_symbol_sphere._debug_symbol_Vertices[i].Position;
}
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(_debug_symbol_XMFLOAT3) * _debug_symbol_vertices.size();
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_vbd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = &_debug_symbol_vertices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_mVB));
_debug_symbol_mIndexCount = _debug_symbol_sphere.Indices.size();
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(USHORT) * _debug_symbol_mIndexCount;
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
std::vector<USHORT> _debug_symbol_indices16;
_debug_symbol_indices16.assign(_debug_symbol_sphere.Indices.begin(), _debug_symbol_sphere.Indices.end());
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iinitData;
_debug_symbol_iinitData._debug_symbol_pSysMem = &_debug_symbol_indices16[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iinitData, &_debug_symbol_mIB));
_debug_symbol_mSkyBoxEffect = new _debug_symbol_SkyBoxEffect();
_debug_symbol_mSkyBoxEffect->_debug_symbol_LoadEffect( decrypt::_debug_symbol_dec_debug(_T( "_debug_FX/sky.fx")), device);
Vertex::_debug_symbol_InitBasicLayout(device, _debug_symbol_mSkyBoxEffect->_debug_symbol_GetTech());
}
_debug_symbol_SkyBox::~_debug_symbol_SkyBox()
{
}
void _debug_symbol_SkyBox::Draw(_debug_symbol_ID3D11DeviceContext* dc, _debug_symbol_CXMMATRIX vp, _debug_symbol_FXMVECTOR _debug_symbol_eye)
{
_debug_symbol_XMFLOAT3 _debug_symbol_eyePos;
_debug_symbol_XMStoreFloat3(&_debug_symbol_eyePos, _debug_symbol_eye);
_debug_symbol_XMMATRIX T = _debug_symbol_XMMatrixTranslation(_debug_symbol_eyePos.x, _debug_symbol_eyePos.y, _debug_symbol_eyePos._debug_symbol_z);
_debug_symbol_XMMATRIX _debug_symbol_WVP = _debug_symbol_XMMatrixMultiply(T, vp);
_debug_symbol_mSkyBoxEffect->_debug_symbol_SetPerObjectParams(_debug_symbol_WVP, _debug_symbol_mCubeMapSRV);
dc->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetBasicVertLayout());
dc->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_mSkyBoxEffect->Draw(dc, _debug_symbol_mVB, _debug_symbol_mIB, _debug_symbol_mIndexCount);
}

#pragma once
#include "character.h"
class _debug_symbol_Player :
public Character
{
private:
const float _debug_symbol_JUMP_FORCE;
public:
_debug_symbol_Player(void) : _debug_symbol_JUMP_FORCE(20.0f)
{
}
_debug_symbol_Player(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up, _debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename,
bool _debug_symbol_isRHS = false, bool _debug_symbol_isVFlipped = false, float speed = 0.0f, float _debug_symbol_sprintSpeed = 0.0f, float _debug_symbol_health = 0.0f) :
Character(pos, _debug_symbol_look, _debug_symbol_up, device, _debug_symbol_effect, filename, _debug_symbol_isRHS, _debug_symbol_isVFlipped, speed, _debug_symbol_sprintSpeed, _debug_symbol_health),
_debug_symbol_JUMP_FORCE(20.0f)
{
}
~_debug_symbol_Player(void);
void _debug_symbol_Jump();
};

#include "fontrasterizer.h"
const int _debug_symbol_MAX_CHARS = 2000;
_debug_symbol_FontRasterizer::_debug_symbol_FontRasterizer(_debug_symbol_BaseCamera* _debug_symbol_cam, _debug_symbol_CXMMATRIX _debug_symbol_proj, _debug_symbol_LitTexEffect* _debug_symbol_effect,
int _debug_symbol_numRows, int _debug_symbol_numCols, _debug_symbol_ID3D11ShaderResourceView* texture,
_debug_symbol_ID3D11Device* device) :
_debug_symbol_m2DCam(_debug_symbol_cam),
_debug_symbol_mEffect(_debug_symbol_effect),
_debug_symbol_mNumRows(_debug_symbol_numRows),
_debug_symbol_mNumCols(_debug_symbol_numCols),
_debug_symbol_mFontImage(texture)
{
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_proj);
_debug_symbol_InitVB(device);
_debug_symbol_InitIB(device);
}
_debug_symbol_FontRasterizer::~_debug_symbol_FontRasterizer()
{
}
void _debug_symbol_FontRasterizer::_debug_symbol_InitVB(_debug_symbol_ID3D11Device* device)
{
std::vector<Vertex::_debug_symbol_NormalTexVertex> _debug_symbol_vertices(_debug_symbol_MAX_CHARS);
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_DYNAMIC;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(Vertex::_debug_symbol_NormalTexVertex) * _debug_symbol_MAX_CHARS;
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = _debug_symbol_D3D11_CPU_ACCESS_WRITE;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = &_debug_symbol_vertices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_VB));
}
void _debug_symbol_FontRasterizer::_debug_symbol_InitIB(_debug_symbol_ID3D11Device* device)
{
std::vector<UINT> indices(_debug_symbol_MAX_CHARS * 6);
int _debug_symbol_currIndex = 0;
for (int i = 0; i < _debug_symbol_MAX_CHARS; ++i)
{
indices[_debug_symbol_currIndex] = i * 4;
indices[_debug_symbol_currIndex + 1] = (i * 4) + 1;
indices[_debug_symbol_currIndex + 2] = (i * 4) + 2;
indices[_debug_symbol_currIndex + 3] = (i * 4) + 0;
indices[_debug_symbol_currIndex + 4] = (i * 4) + 2;
indices[_debug_symbol_currIndex + 5] = (i * 4) + 3;
_debug_symbol_currIndex += 6;
}
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(UINT) * indices.size();
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iinitData;
_debug_symbol_iinitData._debug_symbol_pSysMem = &indices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iinitData, &_debug_symbol_IB));
}
void _debug_symbol_FontRasterizer::_debug_symbol_DrawFont(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_FXMVECTOR pos, float _debug_symbol_fontWidth, float _debug_symbol_fontHeight, int _debug_symbol_charsPerLine, std::string text)
{
_debug_symbol_D3D11_MAPPED_SUBRESOURCE _debug_symbol_mappedData;
_debug_symbol_HR(context->Map(_debug_symbol_VB, 0, _debug_symbol_D3D11_MAP_WRITE_DISCARD, 0, &_debug_symbol_mappedData));
Vertex::_debug_symbol_NormalTexVertex* v = reinterpret_cast<Vertex::_debug_symbol_NormalTexVertex*> (_debug_symbol_mappedData.pData);
float x = pos._debug_symbol_m128_f32[0];
float y = pos._debug_symbol_m128_f32[1];
for (int i = 0; i < text.size(); ++i)
{
_debug_symbol_DrawCharacter(text[i], x, y, _debug_symbol_fontWidth, _debug_symbol_fontHeight, v, i);
x += _debug_symbol_fontWidth;
if (i % _debug_symbol_charsPerLine == _debug_symbol_charsPerLine - 1)
{
y -= _debug_symbol_fontHeight;
x = pos._debug_symbol_m128_f32[0];
}
}
context->Unmap(_debug_symbol_VB, 0);
_debug_symbol_XMMATRIX vp = _debug_symbol_XMMatrixIdentity();
_debug_symbol_XMMATRIX _debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj);
_debug_symbol_XMMATRIX _debug_symbol_view = _debug_symbol_m2DCam->GetView();
vp = vp * _debug_symbol_view * _debug_symbol_proj;
context->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
context->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_mEffect->_debug_symbol_SetPerFrameParams(_debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 1.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 1.0f), _debug_symbol_PointLightOptimized(),
_debug_symbol_SpotLightOptimized());
_debug_symbol_mEffect->_debug_symbol_SetPerObjectParams(_debug_symbol_XMMatrixIdentity(), _debug_symbol_XMMatrixIdentity(),
vp, _debug_symbol_mFontImage);
_debug_symbol_mEffect->Draw(context, _debug_symbol_VB, _debug_symbol_IB, text.size() * 6);
}
void _debug_symbol_FontRasterizer::_debug_symbol_DrawCharacter(char _debug_symbol_c, float xPos, float yPos,
float _debug_symbol_charWidth, float _debug_symbol_charHeight, Vertex::_debug_symbol_NormalTexVertex* vb,
int _debug_symbol_charCount)
{
int index = _debug_symbol_c - ' ';
int _debug_symbol_vbIndex = _debug_symbol_charCount * 4;
int row = index / _debug_symbol_mNumCols;
int col = index % _debug_symbol_mNumCols;
float _debug_symbol_u = (float)col / (float)_debug_symbol_mNumCols;
float v = (float)row / (float)_debug_symbol_mNumRows;
float _debug_symbol_uWidth = 1.0f / _debug_symbol_mNumCols;
float _debug_symbol_vHeight = 1.0f / _debug_symbol_mNumRows;
vb[_debug_symbol_vbIndex].pos.x = xPos;
vb[_debug_symbol_vbIndex].pos.y = yPos;
vb[_debug_symbol_vbIndex].pos._debug_symbol_z = 0.0f;
vb[_debug_symbol_vbIndex]._debug_symbol_tex.x = _debug_symbol_u;
vb[_debug_symbol_vbIndex]._debug_symbol_tex.y = v;
_debug_symbol_XMStoreFloat3(&vb[_debug_symbol_vbIndex].normal, _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f));
vb[_debug_symbol_vbIndex + 1].pos.x = xPos + _debug_symbol_charWidth;
vb[_debug_symbol_vbIndex + 1].pos.y = yPos;
vb[_debug_symbol_vbIndex + 1].pos._debug_symbol_z = 0.0f;
vb[_debug_symbol_vbIndex + 1]._debug_symbol_tex.x = _debug_symbol_u + _debug_symbol_uWidth;
vb[_debug_symbol_vbIndex + 1]._debug_symbol_tex.y = v;
_debug_symbol_XMStoreFloat3(&vb[_debug_symbol_vbIndex + 1].normal, _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f));
vb[_debug_symbol_vbIndex + 2].pos.x = xPos + _debug_symbol_charWidth;
vb[_debug_symbol_vbIndex + 2].pos.y = yPos - _debug_symbol_charHeight;
vb[_debug_symbol_vbIndex + 2].pos._debug_symbol_z = 0.0f;
vb[_debug_symbol_vbIndex + 2]._debug_symbol_tex.x = _debug_symbol_u + _debug_symbol_uWidth;
vb[_debug_symbol_vbIndex + 2]._debug_symbol_tex.y = v + _debug_symbol_vHeight;
_debug_symbol_XMStoreFloat3(&vb[_debug_symbol_vbIndex + 2].normal, _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f));
vb[_debug_symbol_vbIndex + 3].pos.x = xPos;
vb[_debug_symbol_vbIndex + 3].pos.y = yPos - _debug_symbol_charHeight;
vb[_debug_symbol_vbIndex + 3].pos._debug_symbol_z = 0.0f;
vb[_debug_symbol_vbIndex + 3]._debug_symbol_tex.x = _debug_symbol_u;
vb[_debug_symbol_vbIndex + 3]._debug_symbol_tex.y = v + _debug_symbol_vHeight;
_debug_symbol_XMStoreFloat3(&vb[_debug_symbol_vbIndex + 3].normal, _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f));
}

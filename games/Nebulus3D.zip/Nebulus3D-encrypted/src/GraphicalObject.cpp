#include "graphicalobject.h"
#include "cube.h"
_debug_symbol_GraphicalObject::_debug_symbol_GraphicalObject(void) :
_debug_symbol_mPos(0.0f, 0.0f, 0.0f),
_debug_symbol_mLook(0.0f, 0.0f, 1.0f),
_debug_symbol_mUp(0.0f, 1.0f, 0.0f),
_debug_symbol_mRight(1.0f, 0.0f, 0.0f),
_debug_symbol_mWorldUpdated(true)
{
}
_debug_symbol_GraphicalObject::_debug_symbol_GraphicalObject(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up, _debug_symbol_ID3D11Device* device,
_debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename, bool _debug_symbol_isRHS, bool _debug_symbol_isVFlipped) :
_debug_symbol_BasicModel(device, _debug_symbol_effect, filename, _debug_symbol_isRHS, _debug_symbol_isVFlipped),
_debug_symbol_mWorldUpdated(true)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
}
_debug_symbol_GraphicalObject::~_debug_symbol_GraphicalObject(void)
{
}
void _debug_symbol_GraphicalObject::SetPos(_debug_symbol_FXMVECTOR pos)
{
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_SetFacing(_debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up)
{
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMVECTOR right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mWorldUpdated = true;
}
_debug_symbol_FXMVECTOR _debug_symbol_GraphicalObject::GetPos() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
}
_debug_symbol_FXMVECTOR _debug_symbol_GraphicalObject::_debug_symbol_GetLook() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
}
_debug_symbol_FXMVECTOR _debug_symbol_GraphicalObject::_debug_symbol_GetUp() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
}
_debug_symbol_FXMVECTOR _debug_symbol_GraphicalObject::GetRight() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
}
void _debug_symbol_GraphicalObject::Pitch(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(right, angle);
_debug_symbol_look = _debug_symbol_XMVector3TransformNormal(_debug_symbol_look, rotate);
_debug_symbol_up = _debug_symbol_XMVector3Cross(_debug_symbol_look, right);
_debug_symbol_up = _debug_symbol_XMVector3Normalize(_debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_YawLocal(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(_debug_symbol_up, angle);
right = _debug_symbol_XMVector3TransformNormal(right, rotate);
_debug_symbol_look = _debug_symbol_XMVector3Cross(_debug_symbol_up, right);
_debug_symbol_look = _debug_symbol_XMVector3Normalize(_debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_YawGlobal(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationY(angle);
right = _debug_symbol_XMVector3TransformNormal(right, rotate);
_debug_symbol_look = _debug_symbol_XMVector3TransformNormal(_debug_symbol_look, rotate);
_debug_symbol_up = _debug_symbol_XMVector3Cross(_debug_symbol_look, right);
_debug_symbol_up = _debug_symbol_XMVector3Normalize(_debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_Roll(float angle)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX rotate = _debug_symbol_XMMatrixRotationAxis(_debug_symbol_look, angle);
_debug_symbol_up = _debug_symbol_XMVector3TransformNormal(_debug_symbol_up, rotate);
right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
right = _debug_symbol_XMVector3Normalize(right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_MoveLook(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
pos += _debug_symbol_look * _debug_symbol_amt;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::_debug_symbol_MoveStrafe(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
pos += right * _debug_symbol_amt;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mWorldUpdated = true;
}
void _debug_symbol_GraphicalObject::Update()
{
if (_debug_symbol_mWorldUpdated)
{
_debug_symbol_mWorldUpdated = false;
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
pos._debug_symbol_m128_f32[3] = 1.0f;
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mWorld, _debug_symbol_XMMATRIX(right, _debug_symbol_up, _debug_symbol_look, pos));
}
}
void _debug_symbol_GraphicalObject::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX vp)
{
_debug_symbol_XMMATRIX _debug_symbol_world = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_mWorld);
_debug_symbol_XMMATRIX _debug_symbol_invTrn = _debug_symbol_MathHelper::_debug_symbol_InverseTranspose(_debug_symbol_world);
_debug_symbol_mModelMesh->Draw(context, _debug_symbol_world, _debug_symbol_invTrn, vp);
}

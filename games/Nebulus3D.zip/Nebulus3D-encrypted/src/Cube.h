#pragma once
#include "graphicalgeometry.h"
#include "d3dUtil.h"
class _debug_symbol_Cube : public _debug_symbol_GraphicalGeometry
{
private:
public:
_debug_symbol_Cube(void) : _debug_symbol_GraphicalGeometry()
{}
_debug_symbol_Cube(_debug_symbol_ID3D11Device* device, float width, float height, float depth);
~_debug_symbol_Cube(void)
{
if (_debug_symbol_mVB)
{
_debug_symbol_mVB->Release();
}
if (_debug_symbol_mIB)
{
_debug_symbol_mIB->Release();
}
}
_debug_symbol_ID3D11Buffer* _debug_symbol_GetVB()
{
return _debug_symbol_mVB;
}
_debug_symbol_ID3D11Buffer* _debug_symbol_GetIB()
{
return _debug_symbol_mIB;
}
void _debug_symbol_InitBuffers(_debug_symbol_ID3D11Device* device, float width, float height, float depth);
private:
void _debug_symbol_InitVB(_debug_symbol_ID3D11Device* device, float width, float height, float depth);
void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device);
};

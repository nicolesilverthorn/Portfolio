#include "character.h"
Character::Character(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up, _debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename,
bool _debug_symbol_isRHS, bool _debug_symbol_isVFlipped, float speed, float _debug_symbol_sprintSpeed, float _debug_symbol_health) :
_debug_symbol_GraphicalObject(pos, _debug_symbol_look, _debug_symbol_up, device, _debug_symbol_effect, filename, _debug_symbol_isRHS, _debug_symbol_isVFlipped),
_debug_symbol_mSpeed(speed),
_debug_symbol_mSprintSpeed(_debug_symbol_sprintSpeed),
_debug_symbol_mHealth(_debug_symbol_health),
_debug_symbol_mVelocity(0.0f, 0.0f, 0.0f),
_debug_symbol_mGrounded(true)
{
}
Character::~Character(void)
{
}
void Character::_debug_symbol_HitGround()
{
_debug_symbol_mGrounded = true;
_debug_symbol_mVelocity.y = 0.0f;
}
void Character::_debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_vel = _debug_symbol_vel + _debug_symbol_force;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
void Character::Update(float dt)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
pos = pos + (_debug_symbol_vel * dt);
_debug_symbol_mWorldUpdated = true;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_GraphicalObject::Update();
}
void Character::_debug_symbol_MoveLook(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_vel = _debug_symbol_vel + (_debug_symbol_look * _debug_symbol_amt);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
void Character::_debug_symbol_MoveStrafe(float _debug_symbol_amt)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_XMVECTOR right = _debug_symbol_XMLoadFloat3(&_debug_symbol_mRight);
_debug_symbol_vel = _debug_symbol_vel + (right * _debug_symbol_amt);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}

#pragma once
#include "basecamera.h"
class _debug_symbol_GraphicalObject;
class _debug_symbol_ThirdPersonCam : public _debug_symbol_BaseCamera
{
public:
_debug_symbol_ThirdPersonCam(void);
_debug_symbol_ThirdPersonCam(_debug_symbol_GraphicalObject* target, float _debug_symbol_offsetLook, float _debug_symbol_offsetUp, float _debug_symbol_targetYOffset);
~_debug_symbol_ThirdPersonCam(void);
virtual void Update();
void _debug_symbol_SetTarget(_debug_symbol_GraphicalObject* target)
{
_debug_symbol_mTarget = target;
}
protected:
float _debug_symbol_mOffsetLook;
float _debug_symbol_mOffsetUp;
float _debug_symbol_mTargetYOffset;
_debug_symbol_GraphicalObject* _debug_symbol_mTarget;
};

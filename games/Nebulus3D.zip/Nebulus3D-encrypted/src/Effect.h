#pragma once
#include "d3dUtil.h"
class _debug_symbol_Effect
{
protected:
_debug_symbol_ID3DX11Effect* _debug_symbol_mEffect;
_debug_symbol_ID3DX11EffectTechnique* _debug_symbol_mTech;
_debug_symbol_ID3DX11EffectMatrixVariable* _debug_symbol_mfxWVP;
public:
_debug_symbol_Effect(void);
virtual ~_debug_symbol_Effect(void);
void _debug_symbol_LoadEffect(std::wstring filename, _debug_symbol_ID3D11Device* device);
virtual void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount);
virtual void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int startIndex, int _debug_symbol_indexCount);
_debug_symbol_ID3DX11EffectMatrixVariable* _debug_symbol_GetWVP() const
{
return _debug_symbol_mfxWVP;
}
_debug_symbol_ID3DX11EffectTechnique* _debug_symbol_GetTech() const
{
return _debug_symbol_mTech;
}
protected:
virtual void _debug_symbol_LoadEffectParams();
virtual void _debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_wvp);
};
class _debug_symbol_SkyBoxEffect : public _debug_symbol_Effect
{
protected:
_debug_symbol_ID3DX11EffectShaderResourceVariable* _debug_symbol_mfxCubeMap;
public:
virtual void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount);
virtual void _debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_skybox);
virtual void _debug_symbol_LoadEffectParams();
};
class _debug_symbol_LitTexEffect : public _debug_symbol_Effect
{
protected:
_debug_symbol_ID3D11InputLayout* _debug_symbol_mInputLayout;
_debug_symbol_ID3DX11EffectMatrixVariable* _debug_symbol_mfxWorld;
_debug_symbol_ID3DX11EffectMatrixVariable* _debug_symbol_mfxInvTranspose;
_debug_symbol_ID3DX11EffectVectorVariable* _debug_symbol_mfxAmbientLight;
_debug_symbol_ID3DX11EffectVectorVariable* _debug_symbol_mfxEyePos;
_debug_symbol_ID3DX11EffectVariable* _debug_symbol_mfxPointLight;
_debug_symbol_ID3DX11EffectVariable* _debug_symbol_mfxSpotLight;
_debug_symbol_ID3DX11EffectShaderResourceVariable* _debug_symbol_mfxDiffuseMap;
public:
virtual ~_debug_symbol_LitTexEffect();
virtual void _debug_symbol_SetPerFrameParams(_debug_symbol_FXMVECTOR _debug_symbol_ambient, _debug_symbol_FXMVECTOR _debug_symbol_eyePos, const _debug_symbol_PointLightOptimized& point, const _debug_symbol_SpotLightOptimized& _debug_symbol_spot);
virtual void _debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_invTranspose, _debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* texture);
virtual void _debug_symbol_SetDiffuseMap(_debug_symbol_ID3D11ShaderResourceView* texture);
virtual void _debug_symbol_SetAmbient(_debug_symbol_FXMVECTOR _debug_symbol_ambient);
protected:
virtual void _debug_symbol_LoadEffectParams();
};
class _debug_symbol_TerrainEffect : public _debug_symbol_LitTexEffect
{
protected:
_debug_symbol_ID3DX11EffectShaderResourceVariable** _debug_symbol_mfxDiffuseMaps;
_debug_symbol_ID3DX11EffectShaderResourceVariable* _debug_symbol_mfxBlendMap;
virtual void _debug_symbol_LoadEffectParams();
public:
virtual ~_debug_symbol_TerrainEffect();
virtual void _debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_invTranspose, _debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* texture,
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture2, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture3, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture4, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_blendMap);
virtual void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount);
};

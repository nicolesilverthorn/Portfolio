#pragma once
#include "graphicalobject.h"
class Character :
public _debug_symbol_GraphicalObject
{
public:
Character(void){}
Character(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up, _debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename,
bool _debug_symbol_isRHS = false, bool _debug_symbol_isVFlipped = false, float speed = 0.0f, float _debug_symbol_sprintSpeed = 0.0f, float _debug_symbol_health = 0.0f);
virtual ~Character(void);
virtual void _debug_symbol_Attack(){}
virtual void Update(float dt);
float _debug_symbol_GetSpeed() const
{
return _debug_symbol_mSpeed;
}
float _debug_symbol_GetSprintSpeed() const
{
return _debug_symbol_mSprintSpeed;
}
virtual void _debug_symbol_MoveLook(float _debug_symbol_amt);
virtual void _debug_symbol_MoveStrafe(float _debug_symbol_amt);
virtual void _debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force);
virtual void _debug_symbol_HitGround();
virtual void _debug_symbol_LeaveGround()
{
_debug_symbol_mGrounded = false;
}
protected:
float _debug_symbol_mHealth;
_debug_symbol_XMFLOAT3 _debug_symbol_mVelocity;
float _debug_symbol_mSpeed;
float _debug_symbol_mSprintSpeed;
bool _debug_symbol_mGrounded;
};

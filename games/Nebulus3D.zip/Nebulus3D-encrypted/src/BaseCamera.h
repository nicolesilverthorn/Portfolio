#pragma once
#include "d3dUtil.h"
class _debug_symbol_BaseCamera
{
protected:
_debug_symbol_XMFLOAT3 _debug_symbol_mPos;
_debug_symbol_XMFLOAT3 _debug_symbol_mLook;
_debug_symbol_XMFLOAT3 _debug_symbol_mUp;
_debug_symbol_XMFLOAT3 _debug_symbol_mRight;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mView;
bool _debug_symbol_mViewUpdated;
public:
_debug_symbol_BaseCamera(void);
_debug_symbol_BaseCamera(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up);
virtual ~_debug_symbol_BaseCamera(void);
virtual void Update();
_debug_symbol_FXMVECTOR GetPos() const;
_debug_symbol_FXMVECTOR _debug_symbol_GetLook() const;
_debug_symbol_FXMVECTOR _debug_symbol_GetUp() const;
_debug_symbol_CXMMATRIX GetView() const;
void SetPos(_debug_symbol_FXMVECTOR pos);
void _debug_symbol_SetFacing(_debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up);
};

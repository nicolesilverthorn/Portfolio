#pragma once
#include "d3dUtil.h"
#include "basicmodel.h"
class _debug_symbol_GraphicalObject : public _debug_symbol_BasicModel
{
protected:
_debug_symbol_XMFLOAT3 _debug_symbol_mPos;
_debug_symbol_XMFLOAT3 _debug_symbol_mLook, _debug_symbol_mRight, _debug_symbol_mUp;
_debug_symbol_XMFLOAT3 _debug_symbol_mScale;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mWorld;
bool _debug_symbol_mWorldUpdated;
public:
_debug_symbol_GraphicalObject();
_debug_symbol_GraphicalObject(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up,
_debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename,
bool _debug_symbol_isRHS = false, bool _debug_symbol_isVFlipped = false);
~_debug_symbol_GraphicalObject(void);
void Update();
void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX vp);
_debug_symbol_FXMVECTOR GetPos() const;
_debug_symbol_FXMVECTOR _debug_symbol_GetLook() const;
_debug_symbol_FXMVECTOR _debug_symbol_GetUp() const;
_debug_symbol_FXMVECTOR GetRight() const;
void SetPos(_debug_symbol_FXMVECTOR pos);
void _debug_symbol_SetFacing(_debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up);
void Pitch(float angle);
void _debug_symbol_YawLocal(float angle);
void _debug_symbol_YawGlobal(float angle);
void _debug_symbol_Roll(float angle);
virtual void _debug_symbol_MoveLook(float _debug_symbol_amt);
virtual void _debug_symbol_MoveStrafe(float _debug_symbol_amt);
};

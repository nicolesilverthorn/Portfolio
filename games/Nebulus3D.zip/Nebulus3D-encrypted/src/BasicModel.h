#pragma once
#include "d3dUtil.h"
#include "meshgeometry.h"
#include "vertex.h"
class _debug_symbol_BasicModel
{
public:
_debug_symbol_BasicModel() :
_debug_symbol_mSubsetCount(0),
_debug_symbol_mModelMesh(0)
{}
_debug_symbol_BasicModel(_debug_symbol_ID3D11Device* device, _debug_symbol_LitTexEffect* _debug_symbol_effect, std::string filename,
bool _debug_symbol_isRHS, bool _debug_symbol_isVFlipped);
~_debug_symbol_BasicModel(void);
_debug_symbol_MeshGeometry* _debug_symbol_GetModelMesh() const
{
return _debug_symbol_mModelMesh;
}
protected:
UINT _debug_symbol_mSubsetCount;
std::vector<Vertex::_debug_symbol_NormalTexVertex> _debug_symbol_mVertices;
std::vector<UINT> _debug_symbol_mIndices;
std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset> _debug_symbol_mSubsets;
_debug_symbol_MeshGeometry* _debug_symbol_mModelMesh;
};

#pragma once
#include "d3dUtil.h"
#include basecamera.h"
class _debug_symbol_FPSCamera : public _debug_symbol_BaseCamera
{
public:
_debug_symbol_FPSCamera(void) : _debug_symbol_BaseCamera()
{}
_debug_symbol_FPSCamera(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up) :
_debug_symbol_BaseCamera(pos, _debug_symbol_look, _debug_symbol_up)
{}
virtual ~_debug_symbol_FPSCamera(void);
void Pitch(float angle);
void _debug_symbol_YawLocal(float angle);
void _debug_symbol_YawGlobal(float angle);
void _debug_symbol_Roll(float angle);
void _debug_symbol_MoveLook(float _debug_symbol_amt);
void _debug_symbol_MoveStrafe(float _debug_symbol_amt);
};

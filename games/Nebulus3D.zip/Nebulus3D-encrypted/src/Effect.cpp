#include "effect.h"
#include "vertex.h"
_debug_symbol_Effect::_debug_symbol_Effect(void)
{
}
_debug_symbol_Effect::~_debug_symbol_Effect(void)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mEffect);
}
void _debug_symbol_Effect::_debug_symbol_LoadEffect(std::wstring filename, _debug_symbol_ID3D11Device* device)
{
DWORD _debug_symbol_shaderFlags = 0;
#if defined( DEBUG ) || defined( _DEBUG )
_debug_symbol_shaderFlags |= _debug_symbol_D3D10_SHADER_DEBUG;
_debug_symbol_shaderFlags |= _debug_symbol_D3D10_SHADER_SKIP_OPTIMIZATION;
#endif
_debug_symbol_ID3D10Blob* _debug_symbol_compiledShader = 0;
_debug_symbol_ID3D10Blob* _debug_symbol_compilationMsgs = 0;
HRESULT hr = _debug_symbol_D3DX11CompileFromFile(filename.c_str(), 0, 0, 0,  decrypt::_debug_symbol_dec_debug(_T( "_debug_fx_5_0")), _debug_symbol_shaderFlags, 0, 0, &_debug_symbol_compiledShader, &_debug_symbol_compilationMsgs, 0);
if (_debug_symbol_compilationMsgs != 0)
{
MessageBoxA(0, (char*)_debug_symbol_compilationMsgs->_debug_symbol_GetBufferPointer(), 0, 0);
_debug_symbol_ReleaseCOM(_debug_symbol_compilationMsgs);
}
if (FAILED(hr))
{
_debug_symbol_DXTrace(__FILE__, (DWORD)__LINE__, hr,  decrypt::_debug_symbol_dec_debug(_T( "_debug_D3DX11CompileFromFile")), true);
}
_debug_symbol_HR(_debug_symbol_D3DX11CreateEffectFromMemory(_debug_symbol_compiledShader->_debug_symbol_GetBufferPointer(), _debug_symbol_compiledShader->GetBufferSize(), 0, device, &_debug_symbol_mEffect));
_debug_symbol_ReleaseCOM(_debug_symbol_compiledShader);
_debug_symbol_ReleaseCOM(_debug_symbol_compilationMsgs);
_debug_symbol_LoadEffectParams();
}
void _debug_symbol_Effect::_debug_symbol_LoadEffectParams()
{
_debug_symbol_mTech = _debug_symbol_mEffect->_debug_symbol_GetTechniqueByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_TestTech")));
_debug_symbol_mfxWVP = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gWVP")))->_debug_symbol_AsMatrix();
}
void _debug_symbol_Effect::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount)
{
UINT stride = sizeof(Vertex::_debug_symbol_NormalTexVertex);
UINT offset = 0;
context->_debug_symbol_IASetVertexBuffers(0, 1, &vb, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_ib, _debug_symbol_DXGI_FORMAT_R32_UINT, 0);
_debug_symbol_D3DX11_TECHNIQUE_DESC _debug_symbol_techDesc;
_debug_symbol_mTech->_debug_symbol_GetDesc(&_debug_symbol_techDesc);
for (UINT p = 0; p < _debug_symbol_techDesc._debug_symbol_Passes; ++p)
{
_debug_symbol_mTech->_debug_symbol_GetPassByIndex(p)->Apply(0, context);
context->_debug_symbol_DrawIndexed(_debug_symbol_indexCount, 0, 0);
}
}
void _debug_symbol_Effect::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int startIndex, int _debug_symbol_indexCount)
{
UINT stride = sizeof(Vertex::_debug_symbol_NormalTexVertex);
UINT offset = 0;
context->_debug_symbol_IASetVertexBuffers(0, 1, &vb, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_ib, _debug_symbol_DXGI_FORMAT_R32_UINT, 0);
_debug_symbol_D3DX11_TECHNIQUE_DESC _debug_symbol_techDesc;
_debug_symbol_mTech->_debug_symbol_GetDesc(&_debug_symbol_techDesc);
for (UINT p = 0; p < _debug_symbol_techDesc._debug_symbol_Passes; ++p)
{
_debug_symbol_mTech->_debug_symbol_GetPassByIndex(p)->Apply(0, context);
context->_debug_symbol_DrawIndexed(_debug_symbol_indexCount, startIndex, 0);
}
}
void _debug_symbol_Effect::_debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_wvp)
{
_debug_symbol_mfxWVP->_debug_symbol_SetMatrix(reinterpret_cast<const float*>(&_debug_symbol_wvp));
}
void _debug_symbol_SkyBoxEffect::_debug_symbol_LoadEffectParams()
{
_debug_symbol_mfxCubeMap = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gCubeMap")))->_debug_symbol_AsShaderResource();
_debug_symbol_Effect::_debug_symbol_LoadEffectParams();
}
void _debug_symbol_SkyBoxEffect::_debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_skybox)
{
_debug_symbol_mfxCubeMap->_debug_symbol_SetResource(_debug_symbol_skybox);
_debug_symbol_Effect::_debug_symbol_SetPerObjectParams(_debug_symbol_wvp);
}
void _debug_symbol_SkyBoxEffect::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount)
{
UINT stride = sizeof(_debug_symbol_XMFLOAT3);
UINT offset = 0;
context->_debug_symbol_IASetVertexBuffers(0, 1, &vb, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_ib, _debug_symbol_DXGI_FORMAT_R16_UINT, 0);
_debug_symbol_D3DX11_TECHNIQUE_DESC _debug_symbol_techDesc;
_debug_symbol_mTech->_debug_symbol_GetDesc(&_debug_symbol_techDesc);
for (UINT p = 0; p < _debug_symbol_techDesc._debug_symbol_Passes; ++p)
{
_debug_symbol_mTech->_debug_symbol_GetPassByIndex(p)->Apply(0, context);
context->_debug_symbol_DrawIndexed(_debug_symbol_indexCount, 0, 0);
}
}
_debug_symbol_LitTexEffect::~_debug_symbol_LitTexEffect()
{
}
void _debug_symbol_LitTexEffect::_debug_symbol_SetPerFrameParams(_debug_symbol_FXMVECTOR _debug_symbol_ambient, _debug_symbol_FXMVECTOR _debug_symbol_eyePos, const _debug_symbol_PointLightOptimized& point, const _debug_symbol_SpotLightOptimized& _debug_symbol_spot)
{
_debug_symbol_mfxEyePos->_debug_symbol_SetRawValue(&_debug_symbol_eyePos, 0, 12);
_debug_symbol_mfxPointLight->_debug_symbol_SetRawValue(&point, 0, sizeof(_debug_symbol_PointLightOptimized));
_debug_symbol_mfxSpotLight->_debug_symbol_SetRawValue(&_debug_symbol_spot, 0, sizeof(_debug_symbol_SpotLightOptimized));
_debug_symbol_mfxAmbientLight->_debug_symbol_SetRawValue(&_debug_symbol_ambient, 0, 16);
}
void _debug_symbol_LitTexEffect::_debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_invTranspose, _debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* texture)
{
_debug_symbol_Effect::_debug_symbol_SetPerObjectParams(_debug_symbol_wvp);
_debug_symbol_mfxInvTranspose->_debug_symbol_SetMatrix(reinterpret_cast<const float*>(&_debug_symbol_invTranspose));
_debug_symbol_mfxWorld->_debug_symbol_SetMatrix(reinterpret_cast<const float*>(&_debug_symbol_world));
_debug_symbol_mfxDiffuseMap->_debug_symbol_SetResource(texture);
}
void _debug_symbol_LitTexEffect::_debug_symbol_SetDiffuseMap(_debug_symbol_ID3D11ShaderResourceView* texture)
{
_debug_symbol_mfxDiffuseMap->_debug_symbol_SetResource(texture);
}
void _debug_symbol_LitTexEffect::_debug_symbol_LoadEffectParams()
{
_debug_symbol_Effect::_debug_symbol_LoadEffectParams();
_debug_symbol_mfxAmbientLight = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gAmbientLight")))->_debug_symbol_AsVector();
_debug_symbol_mfxEyePos = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gEyePos")))->_debug_symbol_AsVector();
_debug_symbol_mfxPointLight = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gPointLight")));
_debug_symbol_mfxSpotLight = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gSpotLight")));
_debug_symbol_mfxWorld = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gW")))->_debug_symbol_AsMatrix();
_debug_symbol_mfxInvTranspose = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gInvTransposeW")))->_debug_symbol_AsMatrix();
_debug_symbol_mfxDiffuseMap = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gDiffuseMap")))->_debug_symbol_AsShaderResource();
}
void _debug_symbol_LitTexEffect::_debug_symbol_SetAmbient(_debug_symbol_FXMVECTOR _debug_symbol_ambient)
{
_debug_symbol_mfxAmbientLight->_debug_symbol_SetRawValue(&_debug_symbol_ambient, 0, 16);
}
_debug_symbol_TerrainEffect::~_debug_symbol_TerrainEffect()
{
delete[] _debug_symbol_mfxDiffuseMaps;
}
void _debug_symbol_TerrainEffect::_debug_symbol_SetPerObjectParams(_debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_invTranspose, _debug_symbol_CXMMATRIX _debug_symbol_wvp, _debug_symbol_ID3D11ShaderResourceView* texture,
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture2, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture3, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_texture4, _debug_symbol_ID3D11ShaderResourceView* _debug_symbol_blendMap)
{
_debug_symbol_LitTexEffect::_debug_symbol_SetPerObjectParams(_debug_symbol_world, _debug_symbol_invTranspose, _debug_symbol_wvp, texture);
_debug_symbol_mfxDiffuseMaps[0]->_debug_symbol_SetResource(_debug_symbol_texture2);
_debug_symbol_mfxDiffuseMaps[1]->_debug_symbol_SetResource(_debug_symbol_texture3);
_debug_symbol_mfxDiffuseMaps[2]->_debug_symbol_SetResource(_debug_symbol_texture4);
_debug_symbol_mfxBlendMap->_debug_symbol_SetResource(_debug_symbol_blendMap);
}
void _debug_symbol_TerrainEffect::_debug_symbol_LoadEffectParams()
{
_debug_symbol_LitTexEffect::_debug_symbol_LoadEffectParams();
_debug_symbol_mfxDiffuseMaps = new _debug_symbol_ID3DX11EffectShaderResourceVariable*[3];
_debug_symbol_mfxDiffuseMaps[0] = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gDiffuseMap2")))->_debug_symbol_AsShaderResource();
_debug_symbol_mfxDiffuseMaps[1] = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gDiffuseMap3")))->_debug_symbol_AsShaderResource();
_debug_symbol_mfxDiffuseMaps[2] = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gDiffuseMap4")))->_debug_symbol_AsShaderResource();
_debug_symbol_mfxBlendMap = _debug_symbol_mEffect->_debug_symbol_GetVariableByName( decrypt::_debug_symbol_dec_debug(_T( "_debug_gBlend")))->_debug_symbol_AsShaderResource();
}
void _debug_symbol_TerrainEffect::Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_ID3D11Buffer* vb, _debug_symbol_ID3D11Buffer* _debug_symbol_ib, int _debug_symbol_indexCount)
{
UINT stride = sizeof(Vertex::_debug_symbol_TerrainVertex);
UINT offset = 0;
context->_debug_symbol_IASetVertexBuffers(0, 1, &vb, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_ib, _debug_symbol_DXGI_FORMAT_R32_UINT, 0);
_debug_symbol_D3DX11_TECHNIQUE_DESC _debug_symbol_techDesc;
_debug_symbol_mTech->_debug_symbol_GetDesc(&_debug_symbol_techDesc);
for (UINT p = 0; p < _debug_symbol_techDesc._debug_symbol_Passes; ++p)
{
_debug_symbol_mTech->_debug_symbol_GetPassByIndex(p)->Apply(0, context);
context->_debug_symbol_DrawIndexed(_debug_symbol_indexCount, 0, 0);
}
}

#pragma once
#include "basecamera.h"
#include "effect.h"
#include "vertex.h"
class _debug_symbol_FontRasterizer
{
private:
_debug_symbol_BaseCamera* _debug_symbol_m2DCam;
_debug_symbol_XMFLOAT4X4 _debug_symbol_m2DProj;
_debug_symbol_LitTexEffect* _debug_symbol_mEffect;
int _debug_symbol_mNumRows;
int _debug_symbol_mNumCols;
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_mFontImage;
_debug_symbol_ID3D11Buffer* _debug_symbol_VB;
_debug_symbol_ID3D11Buffer* _debug_symbol_IB;
void _debug_symbol_DrawCharacter(char _debug_symbol_c, float xPos, float yPos,
float _debug_symbol_charWidth, float _debug_symbol_charHeight, Vertex::_debug_symbol_NormalTexVertex* v,
int _debug_symbol_charCount);
void _debug_symbol_InitVB(_debug_symbol_ID3D11Device* device);
void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device);
public:
_debug_symbol_FontRasterizer(_debug_symbol_BaseCamera* _debug_symbol_cam, _debug_symbol_CXMMATRIX _debug_symbol_proj, _debug_symbol_LitTexEffect* _debug_symbol_effect,
int _debug_symbol_numRows, int _debug_symbol_numCols, _debug_symbol_ID3D11ShaderResourceView* texture,
_debug_symbol_ID3D11Device* device);
~_debug_symbol_FontRasterizer();
void _debug_symbol_DrawFont(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_FXMVECTOR pos,
float _debug_symbol_fontWidth, float _debug_symbol_fontHeight, int _debug_symbol_charsPerLine,
std::string text);
};

#include "objloader.h"
#include <fstream>
const UINT _debug_symbol_OBJLoader::_debug_symbol_MAX_VERTICES = 2000000;
std::_debug_symbol_wistream& operator>>(std::_debug_symbol_wistream& is, _debug_symbol_XMFLOAT3& v)
{
is >> v.x >> v.y >> v._debug_symbol_z;
return is;
}
std::_debug_symbol_wistream& operator>>(std::_debug_symbol_wistream& is, _debug_symbol_XMFLOAT2& v)
{
is >> v.x >> v.y;
return is;
}
bool operator == (const _debug_symbol_XMFLOAT3& _debug_symbol_lh, const _debug_symbol_XMFLOAT3& _debug_symbol_rh)
{
return _debug_symbol_lh.x == _debug_symbol_rh.x && _debug_symbol_lh.y == _debug_symbol_rh.y && _debug_symbol_lh._debug_symbol_z == _debug_symbol_rh._debug_symbol_z;
}
bool operator == (const _debug_symbol_XMFLOAT2& _debug_symbol_lh, const _debug_symbol_XMFLOAT2& _debug_symbol_rh)
{
return _debug_symbol_lh.x == _debug_symbol_rh.x && _debug_symbol_lh.y == _debug_symbol_rh.y;
}
_debug_symbol_OBJLoader::_debug_symbol_OBJLoader(void)
{
}
_debug_symbol_OBJLoader::~_debug_symbol_OBJLoader(void)
{
}
bool _debug_symbol_OBJLoader::_debug_symbol_LoadOBJ(_debug_symbol_ID3D11Device* device, std::string filename, std::vector<Vertex::_debug_symbol_NormalTexVertex>& _debug_symbol_vertices,
std::vector<UINT>& indices, std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets, bool _debug_symbol_isRHS, bool _debug_symbol_uvFlipped)
{
std::vector<std::vector<UINT>> _debug_symbol_subgroupIndices;
std::vector<UINT> _debug_symbol_subgroup;
_debug_symbol_subgroupIndices.push_back(_debug_symbol_subgroup);
std::vector<_debug_symbol_XMFLOAT3> _debug_symbol_vertPos;
_debug_symbol_vertPos.reserve(_debug_symbol_MAX_VERTICES);
std::vector<_debug_symbol_XMFLOAT3> normals;
_debug_symbol_vertPos.reserve(_debug_symbol_MAX_VERTICES);
std::vector<_debug_symbol_XMFLOAT2> _debug_symbol_uvs;
_debug_symbol_uvs.reserve(_debug_symbol_MAX_VERTICES);
std::map<UINT,_debug_symbol_HashEntry*> _debug_symbol_hashTable;
std::_debug_symbol_wifstream _debug_symbol_fin(filename.c_str());
if(!_debug_symbol_fin)
{
OutputDebugString( decrypt::_debug_symbol_dec_debug(_T( "_debug_Error loading mesh file.")));
return false;
}
UINT _debug_symbol_activeSubgroup = 0;
std::wstring symbol;
while(_debug_symbol_fin >> symbol)
{
if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_#")))
{
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_mtllib")))
{
_debug_symbol_fin >> symbol;
_debug_symbol_LoadMTL(device, symbol, _debug_symbol_subsets);
for(int i = 1; i < _debug_symbol_subsets.size(); ++i)
{
_debug_symbol_subgroupIndices.push_back(_debug_symbol_subgroup);
}
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_v")))
{
_debug_symbol_XMFLOAT3 _debug_symbol_newPos;
_debug_symbol_fin >> _debug_symbol_newPos;
_debug_symbol_vertPos.push_back(_debug_symbol_newPos);
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_vn")))
{
_debug_symbol_XMFLOAT3 _debug_symbol_newNorm;
_debug_symbol_fin >> _debug_symbol_newNorm;
normals.push_back(_debug_symbol_newNorm);
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_vt")))
{
_debug_symbol_XMFLOAT2 _debug_symbol_newUV;
_debug_symbol_fin >> _debug_symbol_newUV;
_debug_symbol_uvs.push_back(_debug_symbol_newUV);
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_f")))
{
for(int i = 0; i < 4; ++i)
{
if(_debug_symbol_fin.peek() == '\n')
{
break;
}
UINT _debug_symbol_tempPosIndex = 0;
UINT _debug_symbol_tempTexIndex = 0;
_debug_symbol_fin >> _debug_symbol_tempPosIndex;
Vertex::_debug_symbol_NormalTexVertex _debug_symbol_newVertex;
_debug_symbol_newVertex.pos = _debug_symbol_vertPos[_debug_symbol_tempPosIndex - 1];
if(_debug_symbol_fin.peek() == '/')
{
_debug_symbol_fin.ignore();
if(_debug_symbol_fin.peek() != '/')
{
_debug_symbol_fin >> _debug_symbol_tempTexIndex;
_debug_symbol_newVertex._debug_symbol_tex = _debug_symbol_uvs[_debug_symbol_tempTexIndex - 1];
if(_debug_symbol_uvFlipped)
{
_debug_symbol_newVertex._debug_symbol_tex.y = 1 - _debug_symbol_newVertex._debug_symbol_tex.y;
}
}
if(_debug_symbol_fin.peek() == '/')
{
_debug_symbol_fin.ignore();
if(_debug_symbol_fin.peek() != '\n')
{
UINT _debug_symbol_tempNormalIndex = 0;
_debug_symbol_fin >> _debug_symbol_tempNormalIndex;
_debug_symbol_newVertex.normal = normals[_debug_symbol_tempNormalIndex - 1];
}
}
}
if(i == 3)
{
if(_debug_symbol_isRHS)
{
UINT _debug_symbol_subgroupSize = _debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size();
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].push_back(_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupSize - 2]);
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].push_back(_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupSize - 3]);
}
else
{
UINT _debug_symbol_subgroupSize = _debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size();
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].push_back(_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupSize - 3]);
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].push_back(_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupSize - 1]);
}
}
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].push_back(_debug_symbol_AddVertex(_debug_symbol_newVertex, _debug_symbol_vertices, _debug_symbol_hashTable, _debug_symbol_tempPosIndex));
if(i == 2 && _debug_symbol_isRHS)
{
UINT temp = _debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size() - 2];
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size() - 2] =
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size() - 1];
_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup][_debug_symbol_subgroupIndices[_debug_symbol_activeSubgroup].size() - 1] = temp;
}
}
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_usemtl")))
{
std::wstring _debug_symbol_subsetName;
_debug_symbol_fin >> _debug_symbol_subsetName;
_debug_symbol_activeSubgroup = _debug_symbol_GetSubset(_debug_symbol_subsetName, _debug_symbol_subsets);
}
std::getline(_debug_symbol_fin, symbol);
}
for(std::map<UINT, _debug_symbol_HashEntry*>::iterator it = _debug_symbol_hashTable.begin(); it != _debug_symbol_hashTable.end(); ++it)
{
_debug_symbol_HashEntry* _debug_symbol_curr = (*it).second;
while(_debug_symbol_curr != NULL)
{
_debug_symbol_HashEntry* next = _debug_symbol_curr->pNext;
delete _debug_symbol_curr;
_debug_symbol_curr = next;
}
}
int _debug_symbol_indexCount = 0;
for(int i = 0; i < _debug_symbol_subgroupIndices.size(); ++i)
{
_debug_symbol_indexCount += _debug_symbol_subgroupIndices[i].size();
}
if(_debug_symbol_indexCount > _debug_symbol_MAX_VERTICES)
{
return false;
}
indices.reserve(_debug_symbol_indexCount);
for(int i = 0; i < _debug_symbol_subgroupIndices.size(); ++i)
{
_debug_symbol_subsets[i]._debug_symbol_faceCount = _debug_symbol_subgroupIndices[i].size() / 3;
_debug_symbol_subsets[i]._debug_symbol_faceStartIndex = indices.size() / 3;
_debug_symbol_subsets[i].id = i;
_debug_symbol_subsets[i]._debug_symbol_vertexStart = 0;
_debug_symbol_subsets[i]._debug_symbol_vertexCount = _debug_symbol_vertices.size();
indices.insert(indices.end(), _debug_symbol_subgroupIndices[i].begin(), _debug_symbol_subgroupIndices[i].end());
}
return true;
}
UINT _debug_symbol_OBJLoader::_debug_symbol_AddVertex(Vertex::_debug_symbol_NormalTexVertex _debug_symbol_vertex, std::vector<Vertex::_debug_symbol_NormalTexVertex>& _debug_symbol_vertBuf, std::map<UINT, _debug_symbol_HashEntry*>& _debug_symbol_hashTable, UINT _debug_symbol_hashValue)
{
_debug_symbol_HashEntry* _debug_symbol_currEntry = _debug_symbol_hashTable[_debug_symbol_hashValue];
_debug_symbol_HashEntry* _debug_symbol_prevEntry = NULL;
while(_debug_symbol_currEntry != NULL)
{
if(_debug_symbol_vertex.pos == _debug_symbol_vertBuf[_debug_symbol_currEntry->index].pos && _debug_symbol_vertex._debug_symbol_tex == _debug_symbol_vertBuf[_debug_symbol_currEntry->index]._debug_symbol_tex && _debug_symbol_vertex.normal == _debug_symbol_vertBuf[_debug_symbol_currEntry->index].normal)
{
return _debug_symbol_currEntry->index;
}
_debug_symbol_prevEntry = _debug_symbol_currEntry;
_debug_symbol_currEntry = _debug_symbol_currEntry->pNext;
}
_debug_symbol_currEntry = new _debug_symbol_HashEntry();
_debug_symbol_currEntry->index = _debug_symbol_vertBuf.size();
_debug_symbol_currEntry->pNext = NULL;
if(_debug_symbol_prevEntry != NULL)
{
_debug_symbol_prevEntry->pNext = _debug_symbol_currEntry;
}
else
{
_debug_symbol_hashTable[_debug_symbol_hashValue] = _debug_symbol_currEntry;
}
_debug_symbol_vertBuf.push_back(_debug_symbol_vertex);
return _debug_symbol_currEntry->index;
}
void _debug_symbol_OBJLoader::_debug_symbol_LoadMTL(_debug_symbol_ID3D11Device* device, std::wstring filename, std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets)
{
std::_debug_symbol_wifstream _debug_symbol_fin(filename.c_str());
if(!_debug_symbol_fin)
{
OutputDebugString( decrypt::_debug_symbol_dec_debug(_T( "_debug_Error loading material file.")));
}
std::wstring symbol;
_debug_symbol_MeshGeometry::_debug_symbol_Subset newData;
while(_debug_symbol_fin >> symbol)
{
if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_#")))
{
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_map_Kd")))
{
_debug_symbol_fin >> symbol;
_debug_symbol_HR(_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device, symbol.c_str(), 0, 0, &newData._debug_symbol_srv, 0));
_debug_symbol_subsets.push_back(newData);
newData = _debug_symbol_MeshGeometry::_debug_symbol_Subset();
}
else if(symbol ==  decrypt::_debug_symbol_dec_debug(_T( "_debug_newmtl")))
{
_debug_symbol_fin >> symbol;
newData.name = symbol;
}
std::getline(_debug_symbol_fin, symbol);
}
}
UINT _debug_symbol_OBJLoader::_debug_symbol_GetSubset(std::wstring name, const std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets)
{
for(int i = 0; i < _debug_symbol_subsets.size(); ++i)
{
if(_debug_symbol_subsets[i].name == name)
{
return i;
}
}
return 0;
}

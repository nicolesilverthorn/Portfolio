#pragma once
#include "d3dUtil.h"
class Vertex
{
public:
struct _debug_symbol_BasicVertex
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_BasicVertex() : pos(0.0f, 0.0f, 0.0f) {}
};
struct _debug_symbol_NormalTexVertex
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_XMFLOAT3 normal;
_debug_symbol_XMFLOAT2 _debug_symbol_tex;
};
struct _debug_symbol_TerrainVertex
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_XMFLOAT3 normal;
_debug_symbol_XMFLOAT2 _debug_symbol_tiledTex;
_debug_symbol_XMFLOAT2 _debug_symbol_tex;
};
struct _debug_symbol_ParticleVertex
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_XMFLOAT2 size;
};
private:
static _debug_symbol_ID3D11InputLayout* _debug_symbol_mBasicVertLayout;
static _debug_symbol_ID3D11InputLayout* _debug_symbol_mNormalTexVertLayout;
static _debug_symbol_ID3D11InputLayout* _debug_symbol_mTerrainVertLayout;
static _debug_symbol_ID3D11InputLayout* _debug_symbol_mParticleVertLayout;
public:
static void _debug_symbol_InitBasicLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech);
static void _debug_symbol_InitLitTexLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech);
static void _debug_symbol_InitTerrainVertLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech);
static void _debug_symbol_InitParticleVertLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech);
static _debug_symbol_ID3D11InputLayout* _debug_symbol_GetBasicVertLayout()
{
return _debug_symbol_mBasicVertLayout;
}
static _debug_symbol_ID3D11InputLayout* _debug_symbol_GetNormalTexVertLayout()
{
return _debug_symbol_mNormalTexVertLayout;
}
static _debug_symbol_ID3D11InputLayout* _debug_symbol_GetTerrainVertLayout()
{
return _debug_symbol_mTerrainVertLayout;
}
static _debug_symbol_ID3D11InputLayout* _debug_symbol_GetParticleVertLayout()
{
return _debug_symbol_mParticleVertLayout;
}
static void _debug_symbol_CleanLayouts();
private:
Vertex() {}
};

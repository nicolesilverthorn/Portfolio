#pragma once
#include "sprite.h"
class _debug_symbol_Projectile : public _debug_symbol_Sprite
{
protected:
float _debug_symbol_mDistanceTravelled;
float _debug_symbol_mProjWidth;
float _debug_symbol_mProjHeight;
public:
_debug_symbol_Projectile(_debug_symbol_FXMVECTOR _debug_symbol_pos2D, _debug_symbol_FXMVECTOR _debug_symbol_scale2D, _debug_symbol_uint16_t _debug_symbol_frameWidth, _debug_symbol_uint16_t _debug_symbol_frameHeight, float depth, const std::vector<Frame*>& _debug_symbol_frames,
float _debug_symbol_frameRate, _debug_symbol_ID3D11Device* device, float _debug_symbol_health, _debug_symbol_XMVECTOR _debug_symbol_velocity = _debug_symbol_XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f)) :
_debug_symbol_Sprite(_debug_symbol_pos2D, _debug_symbol_scale2D, _debug_symbol_frameWidth, _debug_symbol_frameHeight, depth, _debug_symbol_frames, _debug_symbol_frameRate, device, _debug_symbol_health),
_debug_symbol_MAX_DISTANCE(1000.0f),
_debug_symbol_MIN_DISTANCE(-1000.0f),
_debug_symbol_mDistanceTravelled(0.0f),
_debug_symbol_mProjWidth(22.0f),
_debug_symbol_mProjHeight(9.0f)
{
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_velocity);
}
virtual ~_debug_symbol_Projectile();
void _debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force);
virtual void Update(float dt);
float _debug_symbol_GetDistanceTravelled()
{
return _debug_symbol_mDistanceTravelled;
}
const float _debug_symbol_MAX_DISTANCE;
const float _debug_symbol_MIN_DISTANCE;
float _debug_symbol_GetProjWidth()
{
return _debug_symbol_mProjWidth;
}
float _debug_symbol_GetProjHeight()
{
return _debug_symbol_mProjHeight;
}
};

#include "xnacollision.h"
namespace _debug_symbol_XNA
{
static const _debug_symbol_XMVECTOR _debug_symbol_g_UnitQuaternionEpsilon =
{
1.0e-4f, 1.0e-4f, 1.0e-4f, 1.0e-4f
};
static const _debug_symbol_XMVECTOR _debug_symbol_g_UnitVectorEpsilon =
{
1.0e-4f, 1.0e-4f, 1.0e-4f, 1.0e-4f
};
static const _debug_symbol_XMVECTOR _debug_symbol_g_UnitPlaneEpsilon =
{
1.0e-4f, 1.0e-4f, 1.0e-4f, 1.0e-4f
};
static inline BOOL _debug_symbol_XMVector3AnyTrue( _debug_symbol_FXMVECTOR _debug_symbol_V )
{
_debug_symbol_XMVECTOR C;
C = _debug_symbol_XMVectorSwizzle( _debug_symbol_V, 0, 1, 2, 0 );
return _debug_symbol_XMComparisonAnyTrue( _debug_symbol_XMVector4EqualIntR( C, _debug_symbol_XMVectorTrueInt() ) );
}
static inline BOOL _debug_symbol_XMVector3AllTrue( _debug_symbol_FXMVECTOR _debug_symbol_V )
{
_debug_symbol_XMVECTOR C;
C = _debug_symbol_XMVectorSwizzle( _debug_symbol_V, 0, 1, 2, 0 );
return _debug_symbol_XMComparisonAllTrue( _debug_symbol_XMVector4EqualIntR( C, _debug_symbol_XMVectorTrueInt() ) );
}
static inline BOOL _debug_symbol_XMVector3IsUnit( _debug_symbol_FXMVECTOR _debug_symbol_V )
{
_debug_symbol_XMVECTOR Difference = _debug_symbol_XMVector3Length( _debug_symbol_V ) - _debug_symbol_XMVectorSplatOne();
return _debug_symbol_XMVector4Less( _debug_symbol_XMVectorAbs( Difference ), _debug_symbol_g_UnitVectorEpsilon );
}
static inline BOOL _debug_symbol_XMQuaternionIsUnit( _debug_symbol_FXMVECTOR Q )
{
_debug_symbol_XMVECTOR Difference = _debug_symbol_XMVector4Length( Q ) - _debug_symbol_XMVectorSplatOne();
return _debug_symbol_XMVector4Less( _debug_symbol_XMVectorAbs( Difference ), _debug_symbol_g_UnitQuaternionEpsilon );
}
static inline BOOL _debug_symbol_XMPlaneIsUnit( _debug_symbol_FXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMVECTOR Difference = _debug_symbol_XMVector3Length( _debug_symbol_Plane ) - _debug_symbol_XMVectorSplatOne();
return _debug_symbol_XMVector4Less( _debug_symbol_XMVectorAbs( Difference ), _debug_symbol_g_UnitPlaneEpsilon );
}
static inline _debug_symbol_XMVECTOR _debug_symbol_TransformPlane( _debug_symbol_FXMVECTOR _debug_symbol_Plane, _debug_symbol_FXMVECTOR _debug_symbol_Rotation, _debug_symbol_FXMVECTOR _debug_symbol_Translation )
{
_debug_symbol_XMVECTOR _debug_symbol_Normal = _debug_symbol_XMVector3Rotate( _debug_symbol_Plane, _debug_symbol_Rotation );
_debug_symbol_XMVECTOR D = _debug_symbol_XMVectorSplatW( _debug_symbol_Plane ) - _debug_symbol_XMVector3Dot( _debug_symbol_Normal, _debug_symbol_Translation );
return _debug_symbol_XMVectorInsert( _debug_symbol_Normal, D, 0, 0, 0, 0, 1 );
}
static inline _debug_symbol_XMVECTOR _debug_symbol_PointOnLineSegmentNearestPoint( _debug_symbol_FXMVECTOR _debug_symbol_S1, _debug_symbol_FXMVECTOR _debug_symbol_S2, _debug_symbol_FXMVECTOR _debug_symbol_P )
{
_debug_symbol_XMVECTOR Dir = _debug_symbol_S2 - _debug_symbol_S1;
_debug_symbol_XMVECTOR _debug_symbol_Projection = ( _debug_symbol_XMVector3Dot( _debug_symbol_P, Dir ) - _debug_symbol_XMVector3Dot( _debug_symbol_S1, Dir ) );
_debug_symbol_XMVECTOR _debug_symbol_LengthSq = _debug_symbol_XMVector3Dot( Dir, Dir );
_debug_symbol_XMVECTOR t = _debug_symbol_Projection * _debug_symbol_XMVectorReciprocal( _debug_symbol_LengthSq );
_debug_symbol_XMVECTOR Point = _debug_symbol_S1 + t * Dir;
_debug_symbol_XMVECTOR _debug_symbol_SelectS1 = _debug_symbol_XMVectorLess( _debug_symbol_Projection, _debug_symbol_XMVectorZero() );
Point = _debug_symbol_XMVectorSelect( Point, _debug_symbol_S1, _debug_symbol_SelectS1 );
_debug_symbol_XMVECTOR _debug_symbol_SelectS2 = _debug_symbol_XMVectorGreater( _debug_symbol_Projection, _debug_symbol_LengthSq );
Point = _debug_symbol_XMVectorSelect( Point, _debug_symbol_S2, _debug_symbol_SelectS2 );
return Point;
}
static inline _debug_symbol_XMVECTOR _debug_symbol_PointOnPlaneInsideTriangle( _debug_symbol_FXMVECTOR _debug_symbol_P, _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_CXMVECTOR _debug_symbol_V2 )
{
_debug_symbol_XMVECTOR N = _debug_symbol_XMVector3Cross( _debug_symbol_V2 - _debug_symbol_V0, _debug_symbol_V1 - _debug_symbol_V0 );
_debug_symbol_XMVECTOR _debug_symbol_C0 = _debug_symbol_XMVector3Cross( _debug_symbol_P - _debug_symbol_V0, _debug_symbol_V1 - _debug_symbol_V0 );
_debug_symbol_XMVECTOR _debug_symbol_C1 = _debug_symbol_XMVector3Cross( _debug_symbol_P - _debug_symbol_V1, _debug_symbol_V2 - _debug_symbol_V1 );
_debug_symbol_XMVECTOR _debug_symbol_C2 = _debug_symbol_XMVector3Cross( _debug_symbol_P - _debug_symbol_V2, _debug_symbol_V0 - _debug_symbol_V2 );
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_Inside0 = _debug_symbol_XMVectorGreaterOrEqual( _debug_symbol_XMVector3Dot( _debug_symbol_C0, N ), Zero );
_debug_symbol_XMVECTOR _debug_symbol_Inside1 = _debug_symbol_XMVectorGreaterOrEqual( _debug_symbol_XMVector3Dot( _debug_symbol_C1, N ), Zero );
_debug_symbol_XMVECTOR _debug_symbol_Inside2 = _debug_symbol_XMVectorGreaterOrEqual( _debug_symbol_XMVector3Dot( _debug_symbol_C2, N ), Zero );
return _debug_symbol_XMVectorAndInt( _debug_symbol_XMVectorAndInt( _debug_symbol_Inside0, _debug_symbol_Inside1 ), _debug_symbol_Inside2 );
}
VOID _debug_symbol_ComputeBoundingSphereFromPoints( _debug_symbol_Sphere* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( Count > 0 );
_debug_symbol_XMASSERT( pPoints );
_debug_symbol_XMVECTOR _debug_symbol_MinX, _debug_symbol_MaxX, _debug_symbol_MinY, _debug_symbol_MaxY, _debug_symbol_MinZ, _debug_symbol_MaxZ;
_debug_symbol_MinX = _debug_symbol_MaxX = _debug_symbol_MinY = _debug_symbol_MaxY = _debug_symbol_MinZ = _debug_symbol_MaxZ = _debug_symbol_XMLoadFloat3( pPoints );
for( UINT i = 1; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) );
float px = _debug_symbol_XMVectorGetX( Point );
float py = _debug_symbol_XMVectorGetY( Point );
float _debug_symbol_pz = _debug_symbol_XMVectorGetZ( Point );
if( px < _debug_symbol_XMVectorGetX( _debug_symbol_MinX ) )
_debug_symbol_MinX = Point;
if( px > _debug_symbol_XMVectorGetX( _debug_symbol_MaxX ) )
_debug_symbol_MaxX = Point;
if( py < _debug_symbol_XMVectorGetY( _debug_symbol_MinY ) )
_debug_symbol_MinY = Point;
if( py > _debug_symbol_XMVectorGetY( _debug_symbol_MaxY ) )
_debug_symbol_MaxY = Point;
if( _debug_symbol_pz < _debug_symbol_XMVectorGetZ( _debug_symbol_MinZ ) )
_debug_symbol_MinZ = Point;
if( _debug_symbol_pz > _debug_symbol_XMVectorGetZ( _debug_symbol_MaxZ ) )
_debug_symbol_MaxZ = Point;
}
_debug_symbol_XMVECTOR _debug_symbol_DeltaX = _debug_symbol_MaxX - _debug_symbol_MinX;
_debug_symbol_XMVECTOR _debug_symbol_DistX = _debug_symbol_XMVector3Length( _debug_symbol_DeltaX );
_debug_symbol_XMVECTOR _debug_symbol_DeltaY = _debug_symbol_MaxY - _debug_symbol_MinY;
_debug_symbol_XMVECTOR _debug_symbol_DistY = _debug_symbol_XMVector3Length( _debug_symbol_DeltaY );
_debug_symbol_XMVECTOR _debug_symbol_DeltaZ = _debug_symbol_MaxZ - _debug_symbol_MinZ;
_debug_symbol_XMVECTOR _debug_symbol_DistZ = _debug_symbol_XMVector3Length( _debug_symbol_DeltaZ );
_debug_symbol_XMVECTOR Center;
_debug_symbol_XMVECTOR _debug_symbol_Radius;
if( _debug_symbol_XMVector3Greater( _debug_symbol_DistX, _debug_symbol_DistY ) )
{
if( _debug_symbol_XMVector3Greater( _debug_symbol_DistX, _debug_symbol_DistZ ) )
{
Center = ( _debug_symbol_MaxX + _debug_symbol_MinX ) * 0.5f;
_debug_symbol_Radius = _debug_symbol_DistX * 0.5f;
}
else
{
Center = ( _debug_symbol_MaxZ + _debug_symbol_MinZ ) * 0.5f;
_debug_symbol_Radius = _debug_symbol_DistZ * 0.5f;
}
}
else
{
if( _debug_symbol_XMVector3Greater( _debug_symbol_DistY, _debug_symbol_DistZ ) )
{
Center = ( _debug_symbol_MaxY + _debug_symbol_MinY ) * 0.5f;
_debug_symbol_Radius = _debug_symbol_DistY * 0.5f;
}
else
{
Center = ( _debug_symbol_MaxZ + _debug_symbol_MinZ ) * 0.5f;
_debug_symbol_Radius = _debug_symbol_DistZ * 0.5f;
}
}
for( UINT i = 0; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) );
_debug_symbol_XMVECTOR Delta = Point - Center;
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector3Length( Delta );
if( _debug_symbol_XMVector3Greater( _debug_symbol_Dist, _debug_symbol_Radius ) )
{
_debug_symbol_Radius = ( _debug_symbol_Radius + _debug_symbol_Dist ) * 0.5f;
Center += ( _debug_symbol_XMVectorReplicate( 1.0f ) - _debug_symbol_Radius * _debug_symbol_XMVectorReciprocal( _debug_symbol_Dist ) ) * Delta;
}
}
_debug_symbol_XMStoreFloat3( &pOut->Center, Center );
_debug_symbol_XMStoreFloat( &pOut->_debug_symbol_Radius, _debug_symbol_Radius );
return;
}
VOID _debug_symbol_ComputeBoundingAxisAlignedBoxFromPoints( _debug_symbol_AxisAlignedBox* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( Count > 0 );
_debug_symbol_XMASSERT( pPoints );
_debug_symbol_XMVECTOR _debug_symbol_vMin, _debug_symbol_vMax;
_debug_symbol_vMin = _debug_symbol_vMax = _debug_symbol_XMLoadFloat3( pPoints );
for( UINT i = 1; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) );
_debug_symbol_vMin = _debug_symbol_XMVectorMin( _debug_symbol_vMin, Point );
_debug_symbol_vMax = _debug_symbol_XMVectorMax( _debug_symbol_vMax, Point );
}
_debug_symbol_XMStoreFloat3( &pOut->Center, ( _debug_symbol_vMin + _debug_symbol_vMax ) * 0.5f );
_debug_symbol_XMStoreFloat3( &pOut->Extents, ( _debug_symbol_vMax - _debug_symbol_vMin ) * 0.5f );
return;
}
static inline BOOL _debug_symbol_SolveCubic( FLOAT _debug_symbol_e, FLOAT _debug_symbol_f, FLOAT _debug_symbol_g, FLOAT* t, FLOAT* _debug_symbol_u, FLOAT* v )
{
FLOAT p, _debug_symbol_q, h, rc, _debug_symbol_d, _debug_symbol_theta, _debug_symbol_costh3, _debug_symbol_sinth3;
p = _debug_symbol_f - _debug_symbol_e * _debug_symbol_e / 3.0f;
_debug_symbol_q = _debug_symbol_g - _debug_symbol_e * _debug_symbol_f / 3.0f + _debug_symbol_e * _debug_symbol_e * _debug_symbol_e * 2.0f / 27.0f;
h = _debug_symbol_q * _debug_symbol_q / 4.0f + p * p * p / 27.0f;
if( h > 0.0 )
{
return FALSE;
}
if( ( h == 0.0 ) && ( _debug_symbol_q == 0.0 ) )
{
*t = - _debug_symbol_e / 3;
*_debug_symbol_u = - _debug_symbol_e / 3;
*v = - _debug_symbol_e / 3;
return TRUE;
}
_debug_symbol_d = _debug_symbol_sqrtf( _debug_symbol_q * _debug_symbol_q / 4.0f - h );
if( _debug_symbol_d < 0 )
rc = -_debug_symbol_powf( -_debug_symbol_d, 1.0f / 3.0f );
else
rc = _debug_symbol_powf( _debug_symbol_d, 1.0f / 3.0f );
_debug_symbol_theta = _debug_symbol_acosf( -_debug_symbol_q / ( 2.0f * _debug_symbol_d ) );
_debug_symbol_costh3 = _debug_symbol_cosf( _debug_symbol_theta / 3.0f );
_debug_symbol_sinth3 = _debug_symbol_sqrtf( 3.0f ) * _debug_symbol_sinf( _debug_symbol_theta / 3.0f );
*t = 2.0f * rc * _debug_symbol_costh3 - _debug_symbol_e / 3.0f;
*_debug_symbol_u = -rc * ( _debug_symbol_costh3 + _debug_symbol_sinth3 ) - _debug_symbol_e / 3.0f;
*v = -rc * ( _debug_symbol_costh3 - _debug_symbol_sinth3 ) - _debug_symbol_e / 3.0f;
return TRUE;
}
static inline _debug_symbol_XMVECTOR _debug_symbol_CalculateEigenVector( FLOAT _debug_symbol_m11, FLOAT _debug_symbol_m12, FLOAT _debug_symbol_m13,
FLOAT _debug_symbol_m22, FLOAT _debug_symbol_m23, FLOAT _debug_symbol_m33, FLOAT _debug_symbol_e )
{
FLOAT _debug_symbol_f1, _debug_symbol_f2, _debug_symbol_f3;
FLOAT _debug_symbol_fTmp[3];
_debug_symbol_fTmp[0] = ( FLOAT )( _debug_symbol_m12 * _debug_symbol_m23 - _debug_symbol_m13 * ( _debug_symbol_m22 - _debug_symbol_e ) );
_debug_symbol_fTmp[1] = ( FLOAT )( _debug_symbol_m13 * _debug_symbol_m12 - _debug_symbol_m23 * ( _debug_symbol_m11 - _debug_symbol_e ) );
_debug_symbol_fTmp[2] = ( FLOAT )( ( _debug_symbol_m11 - _debug_symbol_e ) * ( _debug_symbol_m22 - _debug_symbol_e ) - _debug_symbol_m12 * _debug_symbol_m12 );
_debug_symbol_XMVECTOR _debug_symbol_vTmp = _debug_symbol_XMLoadFloat3( (_debug_symbol_XMFLOAT3*)_debug_symbol_fTmp );
if( _debug_symbol_XMVector3Equal( _debug_symbol_vTmp, _debug_symbol_XMVectorZero() ) )
{
if( ( _debug_symbol_m11 - _debug_symbol_e != 0.0 ) || ( _debug_symbol_m12 != 0.0 ) || ( _debug_symbol_m13 != 0.0 ) )
{
_debug_symbol_f1 = _debug_symbol_m11 - _debug_symbol_e; _debug_symbol_f2 = _debug_symbol_m12; _debug_symbol_f3 = _debug_symbol_m13;
}
else if( ( _debug_symbol_m12 != 0.0 ) || ( _debug_symbol_m22 - _debug_symbol_e != 0.0 ) || ( _debug_symbol_m23 != 0.0 ) )
{
_debug_symbol_f1 = _debug_symbol_m12; _debug_symbol_f2 = _debug_symbol_m22 - _debug_symbol_e; _debug_symbol_f3 = _debug_symbol_m23;
}
else if( ( _debug_symbol_m13 != 0.0 ) || ( _debug_symbol_m23 != 0.0 ) || ( _debug_symbol_m33 - _debug_symbol_e != 0.0 ) )
{
_debug_symbol_f1 = _debug_symbol_m13; _debug_symbol_f2 = _debug_symbol_m23; _debug_symbol_f3 = _debug_symbol_m33 - _debug_symbol_e;
}
else
{
_debug_symbol_f1 = 1.0; _debug_symbol_f2 = 0.0; _debug_symbol_f3 = 0.0;
}
if( _debug_symbol_f1 == 0.0 )
_debug_symbol_vTmp = _debug_symbol_XMVectorSetX( _debug_symbol_vTmp, 0.0f );
else
_debug_symbol_vTmp = _debug_symbol_XMVectorSetX( _debug_symbol_vTmp, 1.0f );
if( _debug_symbol_f2 == 0.0 )
_debug_symbol_vTmp = _debug_symbol_XMVectorSetY( _debug_symbol_vTmp, 0.0f );
else
_debug_symbol_vTmp = _debug_symbol_XMVectorSetY( _debug_symbol_vTmp, 1.0f );
if( _debug_symbol_f3 == 0.0 )
{
_debug_symbol_vTmp = _debug_symbol_XMVectorSetZ( _debug_symbol_vTmp, 0.0f );
if( _debug_symbol_m12 != 0.0 )
_debug_symbol_vTmp = _debug_symbol_XMVectorSetY( _debug_symbol_vTmp, ( FLOAT )( -_debug_symbol_f1 / _debug_symbol_f2 ) );
}
else
{
_debug_symbol_vTmp = _debug_symbol_XMVectorSetZ( _debug_symbol_vTmp, ( FLOAT )( ( _debug_symbol_f2 - _debug_symbol_f1 ) / _debug_symbol_f3 ) );
}
}
if( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3LengthSq( _debug_symbol_vTmp ) ) > 1e-5f )
{
return _debug_symbol_XMVector3Normalize( _debug_symbol_vTmp );
}
else
{
_debug_symbol_vTmp *= 1e5f;
return _debug_symbol_XMVector3Normalize( _debug_symbol_vTmp );
}
}
static inline BOOL _debug_symbol_CalculateEigenVectors( FLOAT _debug_symbol_m11, FLOAT _debug_symbol_m12, FLOAT _debug_symbol_m13,
FLOAT _debug_symbol_m22, FLOAT _debug_symbol_m23, FLOAT _debug_symbol_m33,
FLOAT _debug_symbol_e1, FLOAT _debug_symbol_e2, FLOAT _debug_symbol_e3,
_debug_symbol_XMVECTOR* _debug_symbol_pV1, _debug_symbol_XMVECTOR* _debug_symbol_pV2, _debug_symbol_XMVECTOR* _debug_symbol_pV3 )
{
_debug_symbol_XMVECTOR _debug_symbol_vTmp, _debug_symbol_vUp, _debug_symbol_vRight;
BOOL _debug_symbol_v1z, _debug_symbol_v2z, _debug_symbol_v3z, _debug_symbol_e12, _debug_symbol_e13, _debug_symbol_e23;
_debug_symbol_vUp = _debug_symbol_XMVectorSetBinaryConstant( 0, 1, 0, 0 );
_debug_symbol_vRight = _debug_symbol_XMVectorSetBinaryConstant( 1, 0, 0, 0 );
*_debug_symbol_pV1 = _debug_symbol_CalculateEigenVector( _debug_symbol_m11, _debug_symbol_m12, _debug_symbol_m13, _debug_symbol_m22, _debug_symbol_m23, _debug_symbol_m33, _debug_symbol_e1 );
*_debug_symbol_pV2 = _debug_symbol_CalculateEigenVector( _debug_symbol_m11, _debug_symbol_m12, _debug_symbol_m13, _debug_symbol_m22, _debug_symbol_m23, _debug_symbol_m33, _debug_symbol_e2 );
*_debug_symbol_pV3 = _debug_symbol_CalculateEigenVector( _debug_symbol_m11, _debug_symbol_m12, _debug_symbol_m13, _debug_symbol_m22, _debug_symbol_m23, _debug_symbol_m33, _debug_symbol_e3 );
_debug_symbol_v1z = _debug_symbol_v2z = _debug_symbol_v3z = FALSE;
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
if ( _debug_symbol_XMVector3Equal( *_debug_symbol_pV1, Zero ) )
_debug_symbol_v1z = TRUE;
if ( _debug_symbol_XMVector3Equal( *_debug_symbol_pV2, Zero ) )
_debug_symbol_v2z = TRUE;
if ( _debug_symbol_XMVector3Equal( *_debug_symbol_pV3, Zero ))
_debug_symbol_v3z = TRUE;
_debug_symbol_e12 = ( _debug_symbol_fabsf( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3Dot( *_debug_symbol_pV1, *_debug_symbol_pV2 ) ) ) > 0.1f );
_debug_symbol_e13 = ( _debug_symbol_fabsf( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3Dot( *_debug_symbol_pV1, *_debug_symbol_pV3 ) ) ) > 0.1f );
_debug_symbol_e23 = ( _debug_symbol_fabsf( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3Dot( *_debug_symbol_pV2, *_debug_symbol_pV3 ) ) ) > 0.1f );
if( ( _debug_symbol_v1z && _debug_symbol_v2z && _debug_symbol_v3z ) || ( _debug_symbol_e12 && _debug_symbol_e13 && _debug_symbol_e23 ) ||
( _debug_symbol_e12 && _debug_symbol_v3z ) || ( _debug_symbol_e13 && _debug_symbol_v2z ) || ( _debug_symbol_e23 && _debug_symbol_v1z ) )
{
*_debug_symbol_pV1 = _debug_symbol_XMVectorSetBinaryConstant( 1, 0, 0, 0 );
*_debug_symbol_pV2 = _debug_symbol_XMVectorSetBinaryConstant( 0, 1, 0, 0 );
*_debug_symbol_pV3 = _debug_symbol_XMVectorSetBinaryConstant( 0, 0, 1, 0 );
return TRUE;
}
if( _debug_symbol_v1z && _debug_symbol_v2z )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vUp, *_debug_symbol_pV3 );
if( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3LengthSq( _debug_symbol_vTmp ) ) < 1e-5f )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vRight, *_debug_symbol_pV3 );
}
*_debug_symbol_pV1 = _debug_symbol_XMVector3Normalize( _debug_symbol_vTmp );
*_debug_symbol_pV2 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV3, *_debug_symbol_pV1 );
return TRUE;
}
if( _debug_symbol_v3z && _debug_symbol_v1z )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vUp, *_debug_symbol_pV2 );
if( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3LengthSq( _debug_symbol_vTmp ) ) < 1e-5f )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vRight, *_debug_symbol_pV2 );
}
*_debug_symbol_pV3 = _debug_symbol_XMVector3Normalize( _debug_symbol_vTmp );
*_debug_symbol_pV1 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV2, *_debug_symbol_pV3 );
return TRUE;
}
if( _debug_symbol_v2z && _debug_symbol_v3z )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vUp, *_debug_symbol_pV1 );
if( _debug_symbol_XMVectorGetX( _debug_symbol_XMVector3LengthSq( _debug_symbol_vTmp ) ) < 1e-5f )
{
_debug_symbol_vTmp = _debug_symbol_XMVector3Cross( _debug_symbol_vRight, *_debug_symbol_pV1 );
}
*_debug_symbol_pV2 = _debug_symbol_XMVector3Normalize( _debug_symbol_vTmp );
*_debug_symbol_pV3 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV1, *_debug_symbol_pV2 );
return TRUE;
}
if( ( _debug_symbol_v1z ) || _debug_symbol_e12 )
{
*_debug_symbol_pV1 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV2, *_debug_symbol_pV3 );
return TRUE;
}
if( ( _debug_symbol_v2z ) || _debug_symbol_e23 )
{
*_debug_symbol_pV2 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV3, *_debug_symbol_pV1 );
return TRUE;
}
if( ( _debug_symbol_v3z ) || _debug_symbol_e13 )
{
*_debug_symbol_pV3 = _debug_symbol_XMVector3Cross( *_debug_symbol_pV1, *_debug_symbol_pV2 );
return TRUE;
}
return TRUE;
}
static inline BOOL _debug_symbol_CalculateEigenVectorsFromCovarianceMatrix( FLOAT _debug_symbol_Cxx, FLOAT _debug_symbol_Cyy, FLOAT _debug_symbol_Czz,
FLOAT _debug_symbol_Cxy, FLOAT _debug_symbol_Cxz, FLOAT _debug_symbol_Cyz,
_debug_symbol_XMVECTOR* _debug_symbol_pV1, _debug_symbol_XMVECTOR* _debug_symbol_pV2, _debug_symbol_XMVECTOR* _debug_symbol_pV3 )
{
FLOAT _debug_symbol_e, _debug_symbol_f, _debug_symbol_g, _debug_symbol_ev1, _debug_symbol_ev2, _debug_symbol_ev3;
_debug_symbol_e = -( _debug_symbol_Cxx + _debug_symbol_Cyy + _debug_symbol_Czz );
_debug_symbol_f = _debug_symbol_Cxx * _debug_symbol_Cyy + _debug_symbol_Cyy * _debug_symbol_Czz + _debug_symbol_Czz * _debug_symbol_Cxx - _debug_symbol_Cxy * _debug_symbol_Cxy - _debug_symbol_Cxz * _debug_symbol_Cxz - _debug_symbol_Cyz * _debug_symbol_Cyz;
_debug_symbol_g = _debug_symbol_Cxy * _debug_symbol_Cxy * _debug_symbol_Czz + _debug_symbol_Cxz * _debug_symbol_Cxz * _debug_symbol_Cyy + _debug_symbol_Cyz * _debug_symbol_Cyz * _debug_symbol_Cxx - _debug_symbol_Cxy * _debug_symbol_Cyz * _debug_symbol_Cxz * 2.0f - _debug_symbol_Cxx * _debug_symbol_Cyy * _debug_symbol_Czz;
if( !_debug_symbol_SolveCubic( _debug_symbol_e, _debug_symbol_f, _debug_symbol_g, &_debug_symbol_ev1, &_debug_symbol_ev2, &_debug_symbol_ev3 ) )
{
*_debug_symbol_pV1 = _debug_symbol_XMVectorSetBinaryConstant( 1, 0, 0, 0 );
*_debug_symbol_pV2 = _debug_symbol_XMVectorSetBinaryConstant( 0, 1, 0, 0 );
*_debug_symbol_pV3 = _debug_symbol_XMVectorSetBinaryConstant( 0, 0, 1, 0 );
return FALSE;
}
return _debug_symbol_CalculateEigenVectors( _debug_symbol_Cxx, _debug_symbol_Cxy, _debug_symbol_Cxz, _debug_symbol_Cyy, _debug_symbol_Cyz, _debug_symbol_Czz, _debug_symbol_ev1, _debug_symbol_ev2, _debug_symbol_ev3, _debug_symbol_pV1, _debug_symbol_pV2, _debug_symbol_pV3 );
}
VOID _debug_symbol_ComputeBoundingOrientedBoxFromPoints( _debug_symbol_OrientedBox* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride )
{
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_PermuteXXY =
{
_debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0W
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_PermuteYZZ =
{
_debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0W
};
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( Count > 0 );
_debug_symbol_XMASSERT( pPoints );
_debug_symbol_XMVECTOR _debug_symbol_CenterOfMass = _debug_symbol_XMVectorZero();
for( UINT i = 0; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) );
_debug_symbol_CenterOfMass += Point;
}
_debug_symbol_CenterOfMass *= _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorReplicate( FLOAT( Count ) ) );
_debug_symbol_XMVECTOR _debug_symbol_XX_YY_ZZ = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_XY_XZ_YZ = _debug_symbol_XMVectorZero();
for( UINT i = 0; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) ) - _debug_symbol_CenterOfMass;
_debug_symbol_XX_YY_ZZ += Point * Point;
_debug_symbol_XMVECTOR _debug_symbol_XXY = _debug_symbol_XMVectorPermute( Point, Point, _debug_symbol_PermuteXXY );
_debug_symbol_XMVECTOR _debug_symbol_YZZ = _debug_symbol_XMVectorPermute( Point, Point, _debug_symbol_PermuteYZZ );
_debug_symbol_XY_XZ_YZ += _debug_symbol_XXY * _debug_symbol_YZZ;
}
_debug_symbol_XMVECTOR v1, v2, _debug_symbol_v3;
_debug_symbol_CalculateEigenVectorsFromCovarianceMatrix( _debug_symbol_XMVectorGetX( _debug_symbol_XX_YY_ZZ ), _debug_symbol_XMVectorGetY( _debug_symbol_XX_YY_ZZ ),
_debug_symbol_XMVectorGetZ( _debug_symbol_XX_YY_ZZ ),
_debug_symbol_XMVectorGetX( _debug_symbol_XY_XZ_YZ ), _debug_symbol_XMVectorGetY( _debug_symbol_XY_XZ_YZ ),
_debug_symbol_XMVectorGetZ( _debug_symbol_XY_XZ_YZ ),
&v1, &v2, &_debug_symbol_v3 );
_debug_symbol_XMMATRIX _debug_symbol_R;
_debug_symbol_R._debug_symbol_r[0] = _debug_symbol_XMVectorSetW( v1, 0._debug_symbol_f );
_debug_symbol_R._debug_symbol_r[1] = _debug_symbol_XMVectorSetW( v2, 0._debug_symbol_f );
_debug_symbol_R._debug_symbol_r[2] = _debug_symbol_XMVectorSetW( _debug_symbol_v3, 0._debug_symbol_f );
_debug_symbol_R._debug_symbol_r[3] = _debug_symbol_XMVectorSetBinaryConstant( 0, 0, 0, 1 );
_debug_symbol_XMVECTOR _debug_symbol_Det = _debug_symbol_XMMatrixDeterminant( _debug_symbol_R );
if( _debug_symbol_XMVector4Less( _debug_symbol_Det, _debug_symbol_XMVectorZero() ) )
{
const _debug_symbol_XMVECTORF32 _debug_symbol_VectorNegativeOne =
{
-1.0f, -1.0f, -1.0f, -1.0f
};
_debug_symbol_R._debug_symbol_r[0] *= _debug_symbol_VectorNegativeOne;
_debug_symbol_R._debug_symbol_r[1] *= _debug_symbol_VectorNegativeOne;
_debug_symbol_R._debug_symbol_r[2] *= _debug_symbol_VectorNegativeOne;
}
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMQuaternionRotationMatrix( _debug_symbol_R );
_debug_symbol_Orientation = _debug_symbol_XMQuaternionNormalize( _debug_symbol_Orientation );
_debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( _debug_symbol_Orientation );
_debug_symbol_XMMATRIX _debug_symbol_InverseR = _debug_symbol_XMMatrixTranspose( _debug_symbol_R );
_debug_symbol_XMVECTOR _debug_symbol_vMin, _debug_symbol_vMax;
_debug_symbol_vMin = _debug_symbol_vMax = _debug_symbol_XMVector3TransformNormal( _debug_symbol_XMLoadFloat3( pPoints ), _debug_symbol_InverseR );
for( UINT i = 1; i < Count; i++ )
{
_debug_symbol_XMVECTOR Point = _debug_symbol_XMVector3TransformNormal( _debug_symbol_XMLoadFloat3( ( _debug_symbol_XMFLOAT3* )( ( BYTE* )pPoints + i * Stride ) ),
_debug_symbol_InverseR );
_debug_symbol_vMin = _debug_symbol_XMVectorMin( _debug_symbol_vMin, Point );
_debug_symbol_vMax = _debug_symbol_XMVectorMax( _debug_symbol_vMax, Point );
}
_debug_symbol_XMVECTOR Center = ( _debug_symbol_vMin + _debug_symbol_vMax ) * 0.5f;
Center = _debug_symbol_XMVector3TransformNormal( Center, _debug_symbol_R );
_debug_symbol_XMStoreFloat3( &pOut->Center, Center );
_debug_symbol_XMStoreFloat3( &pOut->Extents, ( _debug_symbol_vMax - _debug_symbol_vMin ) * 0.5f );
_debug_symbol_XMStoreFloat4( &pOut->_debug_symbol_Orientation, _debug_symbol_Orientation );
return;
}
VOID _debug_symbol_ComputeFrustumFromProjection( _debug_symbol_Frustum* pOut, _debug_symbol_XMMATRIX* _debug_symbol_pProjection )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( _debug_symbol_pProjection );
static _debug_symbol_XMVECTOR _debug_symbol_HomogenousPoints[6] =
{
{  1.0f,  0.0f, 1.0f, 1.0f },
{ -1.0f,  0.0f, 1.0f, 1.0f },
{  0.0f,  1.0f, 1.0f, 1.0f },
{  0.0f, -1.0f, 1.0f, 1.0f },
{ 0.0f, 0.0f, 0.0f, 1.0f },
{ 0.0f, 0.0f, 1.0f, 1.0f }
};
_debug_symbol_XMVECTOR _debug_symbol_Determinant;
_debug_symbol_XMMATRIX _debug_symbol_matInverse = _debug_symbol_XMMatrixInverse( &_debug_symbol_Determinant, *_debug_symbol_pProjection );
_debug_symbol_XMVECTOR Points[6];
for( INT i = 0; i < 6; i++ )
{
Points[i] = _debug_symbol_XMVector4Transform( _debug_symbol_HomogenousPoints[i], _debug_symbol_matInverse );
}
pOut->_debug_symbol_Origin = _debug_symbol_XMFLOAT3( 0.0f, 0.0f, 0.0f );
pOut->_debug_symbol_Orientation = _debug_symbol_XMFLOAT4( 0.0f, 0.0f, 0.0f, 1.0f );
Points[0] = Points[0] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatZ( Points[0] ) );
Points[1] = Points[1] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatZ( Points[1] ) );
Points[2] = Points[2] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatZ( Points[2] ) );
Points[3] = Points[3] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatZ( Points[3] ) );
pOut->_debug_symbol_RightSlope = _debug_symbol_XMVectorGetX( Points[0] );
pOut->_debug_symbol_LeftSlope = _debug_symbol_XMVectorGetX( Points[1] );
pOut->_debug_symbol_TopSlope = _debug_symbol_XMVectorGetY( Points[2] );
pOut->_debug_symbol_BottomSlope = _debug_symbol_XMVectorGetY( Points[3] );
Points[4] = Points[4] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatW( Points[4] ) );
Points[5] = Points[5] * _debug_symbol_XMVectorReciprocal( _debug_symbol_XMVectorSplatW( Points[5] ) );
pOut->_debug_symbol_Near = _debug_symbol_XMVectorGetZ( Points[4] );
pOut->Far = _debug_symbol_XMVectorGetZ( Points[5] );
return;
}
VOID _debug_symbol_ComputePlanesFromFrustum( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_XMVECTOR* _debug_symbol_pPlane0, _debug_symbol_XMVECTOR* _debug_symbol_pPlane1, _debug_symbol_XMVECTOR* _debug_symbol_pPlane2,
_debug_symbol_XMVECTOR* _debug_symbol_pPlane3, _debug_symbol_XMVECTOR* _debug_symbol_pPlane4, _debug_symbol_XMVECTOR* _debug_symbol_pPlane5 )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_pPlane0 );
_debug_symbol_XMASSERT( _debug_symbol_pPlane1 );
_debug_symbol_XMASSERT( _debug_symbol_pPlane2 );
_debug_symbol_XMASSERT( _debug_symbol_pPlane3 );
_debug_symbol_XMASSERT( _debug_symbol_pPlane4 );
_debug_symbol_XMASSERT( _debug_symbol_pPlane5 );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_Plane0 = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, _debug_symbol_pVolume->_debug_symbol_Near );
_debug_symbol_XMVECTOR _debug_symbol_Plane1 = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, -_debug_symbol_pVolume->Far );
_debug_symbol_XMVECTOR _debug_symbol_Plane2 = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolume->_debug_symbol_RightSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Plane3 = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolume->_debug_symbol_LeftSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Plane4 = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolume->_debug_symbol_TopSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Plane5 = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 0.0f );
_debug_symbol_Plane0 = _debug_symbol_TransformPlane( _debug_symbol_Plane0, _debug_symbol_Orientation, _debug_symbol_Origin );
_debug_symbol_Plane1 = _debug_symbol_TransformPlane( _debug_symbol_Plane1, _debug_symbol_Orientation, _debug_symbol_Origin );
_debug_symbol_Plane2 = _debug_symbol_TransformPlane( _debug_symbol_Plane2, _debug_symbol_Orientation, _debug_symbol_Origin );
_debug_symbol_Plane3 = _debug_symbol_TransformPlane( _debug_symbol_Plane3, _debug_symbol_Orientation, _debug_symbol_Origin );
_debug_symbol_Plane4 = _debug_symbol_TransformPlane( _debug_symbol_Plane4, _debug_symbol_Orientation, _debug_symbol_Origin );
_debug_symbol_Plane5 = _debug_symbol_TransformPlane( _debug_symbol_Plane5, _debug_symbol_Orientation, _debug_symbol_Origin );
*_debug_symbol_pPlane0 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane0 );
*_debug_symbol_pPlane1 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane1 );
*_debug_symbol_pPlane2 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane2 );
*_debug_symbol_pPlane3 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane3 );
*_debug_symbol_pPlane4 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane4 );
*_debug_symbol_pPlane5 = _debug_symbol_XMPlaneNormalize( _debug_symbol_Plane5 );
}
VOID _debug_symbol_TransformSphere( _debug_symbol_Sphere* pOut, const _debug_symbol_Sphere* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation, _debug_symbol_FXMVECTOR _debug_symbol_Translation )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( pIn );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Rotation ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &pIn->Center );
Center = _debug_symbol_XMVector3Rotate( Center * _debug_symbol_XMVectorReplicate( Scale ), _debug_symbol_Rotation ) + _debug_symbol_Translation;
_debug_symbol_XMStoreFloat3( &pOut->Center, Center );
pOut->_debug_symbol_Radius = pIn->_debug_symbol_Radius * Scale;
return;
}
VOID _debug_symbol_TransformAxisAlignedBox( _debug_symbol_AxisAlignedBox* pOut, const _debug_symbol_AxisAlignedBox* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation,
_debug_symbol_FXMVECTOR _debug_symbol_Translation )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( pIn );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Rotation ) );
static _debug_symbol_XMVECTOR Offset[8] =
{
{ -1.0f, -1.0f, -1.0f, 0.0f },
{ -1.0f, -1.0f,  1.0f, 0.0f },
{ -1.0f,  1.0f, -1.0f, 0.0f },
{ -1.0f,  1.0f,  1.0f, 0.0f },
{  1.0f, -1.0f, -1.0f, 0.0f },
{  1.0f, -1.0f,  1.0f, 0.0f },
{  1.0f,  1.0f, -1.0f, 0.0f },
{  1.0f,  1.0f,  1.0f, 0.0f }
};
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &pIn->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &pIn->Extents );
_debug_symbol_XMVECTOR _debug_symbol_VectorScale = _debug_symbol_XMVectorReplicate( Scale );
_debug_symbol_XMVECTOR _debug_symbol_Corner = Center + Extents * Offset[0];
_debug_symbol_Corner = _debug_symbol_XMVector3Rotate( _debug_symbol_Corner * _debug_symbol_VectorScale, _debug_symbol_Rotation ) + _debug_symbol_Translation;
_debug_symbol_XMVECTOR Min, Max;
Min = Max = _debug_symbol_Corner;
for( INT i = 1; i < 8; i++ )
{
_debug_symbol_Corner = Center + Extents * Offset[i];
_debug_symbol_Corner = _debug_symbol_XMVector3Rotate( _debug_symbol_Corner * _debug_symbol_VectorScale, _debug_symbol_Rotation ) + _debug_symbol_Translation;
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Corner );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Corner );
}
_debug_symbol_XMStoreFloat3( &pOut->Center, ( Min + Max ) * 0.5f );
_debug_symbol_XMStoreFloat3( &pOut->Extents, ( Max - Min ) * 0.5f );
return;
}
VOID _debug_symbol_TransformOrientedBox( _debug_symbol_OrientedBox* pOut, const _debug_symbol_OrientedBox* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation,
_debug_symbol_FXMVECTOR _debug_symbol_Translation )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( pIn );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Rotation ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &pIn->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &pIn->Extents );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &pIn->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_Orientation = _debug_symbol_XMQuaternionMultiply( _debug_symbol_Orientation, _debug_symbol_Rotation );
_debug_symbol_XMVECTOR _debug_symbol_VectorScale = _debug_symbol_XMVectorReplicate( Scale );
Center = _debug_symbol_XMVector3Rotate( Center * _debug_symbol_VectorScale, _debug_symbol_Rotation ) + _debug_symbol_Translation;
Extents = Extents * _debug_symbol_VectorScale;
_debug_symbol_XMStoreFloat3( &pOut->Center, Center );
_debug_symbol_XMStoreFloat3( &pOut->Extents, Extents );
_debug_symbol_XMStoreFloat4( &pOut->_debug_symbol_Orientation, _debug_symbol_Orientation );
return;
}
VOID _debug_symbol_TransformFrustum( _debug_symbol_Frustum* pOut, const _debug_symbol_Frustum* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation, _debug_symbol_FXMVECTOR _debug_symbol_Translation )
{
_debug_symbol_XMASSERT( pOut );
_debug_symbol_XMASSERT( pIn );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Rotation ) );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &pIn->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &pIn->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_Orientation = _debug_symbol_XMQuaternionMultiply( _debug_symbol_Orientation, _debug_symbol_Rotation );
_debug_symbol_Origin = _debug_symbol_XMVector3Rotate( _debug_symbol_Origin * _debug_symbol_XMVectorReplicate( Scale ), _debug_symbol_Rotation ) + _debug_symbol_Translation;
_debug_symbol_XMStoreFloat3( &pOut->_debug_symbol_Origin, _debug_symbol_Origin );
_debug_symbol_XMStoreFloat4( &pOut->_debug_symbol_Orientation, _debug_symbol_Orientation );
pOut->_debug_symbol_Near = pIn->_debug_symbol_Near * Scale;
pOut->Far = pIn->Far * Scale;
pOut->_debug_symbol_RightSlope = pIn->_debug_symbol_RightSlope;
pOut->_debug_symbol_LeftSlope = pIn->_debug_symbol_LeftSlope;
pOut->_debug_symbol_TopSlope = pIn->_debug_symbol_TopSlope;
pOut->_debug_symbol_BottomSlope = pIn->_debug_symbol_BottomSlope;
return;
}
BOOL _debug_symbol_IntersectPointSphere( _debug_symbol_FXMVECTOR Point, const _debug_symbol_Sphere* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Radius );
_debug_symbol_XMVECTOR _debug_symbol_DistanceSquared = _debug_symbol_XMVector3LengthSq( Point - Center );
_debug_symbol_XMVECTOR _debug_symbol_RadiusSquared = _debug_symbol_Radius * _debug_symbol_Radius;
return _debug_symbol_XMVector4LessOrEqual( _debug_symbol_DistanceSquared, _debug_symbol_RadiusSquared );
}
BOOL _debug_symbol_IntersectPointAxisAlignedBox( _debug_symbol_FXMVECTOR Point, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
return _debug_symbol_XMVector3InBounds( Point - Center, Extents );
}
BOOL _debug_symbol_IntersectPointOrientedBox( _debug_symbol_FXMVECTOR Point, const _debug_symbol_OrientedBox* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMVECTOR _debug_symbol_TPoint = _debug_symbol_XMVector3InverseRotate( Point - Center, _debug_symbol_Orientation );
return _debug_symbol_XMVector3InBounds( _debug_symbol_TPoint, Extents );
}
BOOL _debug_symbol_IntersectPointFrustum( _debug_symbol_FXMVECTOR Point, const _debug_symbol_Frustum* _debug_symbol_pVolume )
{
static const _debug_symbol_XMVECTORU32 _debug_symbol_SelectW = {_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1};
static const _debug_symbol_XMVECTORU32 _debug_symbol_SelectZ = {_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0};
static const _debug_symbol_XMVECTOR _debug_symbol_BasePlanes[6] =
{
{  0.0f,  0.0f, -1.0f, 0.0f },
{  0.0f,  0.0f,  1.0f, 0.0f },
{  1.0f,  0.0f,  0.0f, 0.0f },
{ -1.0f,  0.0f,  0.0f, 0.0f },
{  0.0f,  1.0f,  0.0f, 0.0f },
{  0.0f, -1.0f,  0.0f, 0.0f },
};
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Planes[6];
Planes[0] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[0], _debug_symbol_XMVectorSplatX(  _debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->_debug_symbol_Near ) ),
_debug_symbol_SelectW );
Planes[1] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[1], _debug_symbol_XMVectorSplatX( -_debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->Far ) ),
_debug_symbol_SelectW );
Planes[2] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[2], _debug_symbol_XMVectorSplatX( -_debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->_debug_symbol_RightSlope ) ),
_debug_symbol_SelectZ );
Planes[3] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[3], _debug_symbol_XMVectorSplatX(  _debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->_debug_symbol_LeftSlope ) ),
_debug_symbol_SelectZ );
Planes[4] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[4], _debug_symbol_XMVectorSplatX( -_debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->_debug_symbol_TopSlope ) ),
_debug_symbol_SelectZ );
Planes[5] = _debug_symbol_XMVectorSelect( _debug_symbol_BasePlanes[5], _debug_symbol_XMVectorSplatX(  _debug_symbol_XMLoadFloat( &_debug_symbol_pVolume->_debug_symbol_BottomSlope ) ),
_debug_symbol_SelectZ );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMVECTOR _debug_symbol_TPoint = _debug_symbol_XMVector3InverseRotate( Point - _debug_symbol_Origin, _debug_symbol_Orientation );
_debug_symbol_TPoint = _debug_symbol_XMVectorInsert( _debug_symbol_TPoint, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_Outside = Zero;
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Dot = _debug_symbol_XMVector4Dot( _debug_symbol_TPoint, Planes[i] );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_Dot, Zero ) );
}
return _debug_symbol_XMVector4NotEqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() );
}
BOOL _debug_symbol_IntersectRayTriangle( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_CXMVECTOR _debug_symbol_V1, _debug_symbol_CXMVECTOR _debug_symbol_V2,
FLOAT* _debug_symbol_pDist )
{
_debug_symbol_XMASSERT( _debug_symbol_pDist );
_debug_symbol_XMASSERT( _debug_symbol_XMVector3IsUnit( Direction ) );
static const _debug_symbol_XMVECTOR _debug_symbol_Epsilon =
{
1e-20f, 1e-20f, 1e-20f, 1e-20f
};
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_e1 = _debug_symbol_V1 - _debug_symbol_V0;
_debug_symbol_XMVECTOR _debug_symbol_e2 = _debug_symbol_V2 - _debug_symbol_V0;
_debug_symbol_XMVECTOR p = _debug_symbol_XMVector3Cross( Direction, _debug_symbol_e2 );
_debug_symbol_XMVECTOR _debug_symbol_det = _debug_symbol_XMVector3Dot( _debug_symbol_e1, p );
_debug_symbol_XMVECTOR _debug_symbol_u, v, t;
if( _debug_symbol_XMVector3GreaterOrEqual( _debug_symbol_det, _debug_symbol_Epsilon ) )
{
_debug_symbol_XMVECTOR s = _debug_symbol_Origin - _debug_symbol_V0;
_debug_symbol_u = _debug_symbol_XMVector3Dot( s, p );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorLess( _debug_symbol_u, Zero );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( _debug_symbol_u, _debug_symbol_det ) );
_debug_symbol_XMVECTOR _debug_symbol_q = _debug_symbol_XMVector3Cross( s, _debug_symbol_e1 );
v = _debug_symbol_XMVector3Dot( Direction, _debug_symbol_q );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( v, Zero ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( _debug_symbol_u + v, _debug_symbol_det ) );
t = _debug_symbol_XMVector3Dot( _debug_symbol_e2, _debug_symbol_q );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( t, Zero ) );
if( _debug_symbol_XMVector4EqualInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorTrueInt() ) )
return FALSE;
}
else if( _debug_symbol_XMVector3LessOrEqual( _debug_symbol_det, -_debug_symbol_Epsilon ) )
{
_debug_symbol_XMVECTOR s = _debug_symbol_Origin - _debug_symbol_V0;
_debug_symbol_u = _debug_symbol_XMVector3Dot( s, p );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorGreater( _debug_symbol_u, Zero );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( _debug_symbol_u, _debug_symbol_det ) );
_debug_symbol_XMVECTOR _debug_symbol_q = _debug_symbol_XMVector3Cross( s, _debug_symbol_e1 );
v = _debug_symbol_XMVector3Dot( Direction, _debug_symbol_q );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( v, Zero ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( _debug_symbol_u + v, _debug_symbol_det ) );
t = _debug_symbol_XMVector3Dot( _debug_symbol_e2, _debug_symbol_q );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( t, Zero ) );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorTrueInt() ) )
return FALSE;
}
else
{
return FALSE;
}
_debug_symbol_XMVECTOR _debug_symbol_inv_det = _debug_symbol_XMVectorReciprocal( _debug_symbol_det );
t *= _debug_symbol_inv_det;
_debug_symbol_XMStoreFloat( _debug_symbol_pDist, t );
return TRUE;
}
BOOL _debug_symbol_IntersectRaySphere( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_Sphere* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_pDist );
_debug_symbol_XMASSERT( _debug_symbol_XMVector3IsUnit( Direction ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Radius );
_debug_symbol_XMVECTOR l = Center - _debug_symbol_Origin;
_debug_symbol_XMVECTOR s = _debug_symbol_XMVector3Dot( l, Direction );
_debug_symbol_XMVECTOR _debug_symbol_l2 = _debug_symbol_XMVector3Dot( l, l );
_debug_symbol_XMVECTOR _debug_symbol_r2 = _debug_symbol_Radius * _debug_symbol_Radius;
_debug_symbol_XMVECTOR _debug_symbol_m2 = _debug_symbol_l2 - s * s;
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection;
_debug_symbol_NoIntersection = _debug_symbol_XMVectorAndInt( _debug_symbol_XMVectorLess( s, _debug_symbol_XMVectorZero() ), _debug_symbol_XMVectorGreater( _debug_symbol_l2, _debug_symbol_r2 ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( _debug_symbol_m2, _debug_symbol_r2 ) );
_debug_symbol_XMVECTOR _debug_symbol_q = _debug_symbol_XMVectorSqrt( _debug_symbol_r2 - _debug_symbol_m2 );
_debug_symbol_XMVECTOR t1 = s - _debug_symbol_q;
_debug_symbol_XMVECTOR t2 = s + _debug_symbol_q;
_debug_symbol_XMVECTOR _debug_symbol_OriginInside = _debug_symbol_XMVectorLessOrEqual( _debug_symbol_l2, _debug_symbol_r2 );
_debug_symbol_XMVECTOR t = _debug_symbol_XMVectorSelect( t1, t2, _debug_symbol_OriginInside );
if( _debug_symbol_XMVector4NotEqualInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorTrueInt() ) )
{
_debug_symbol_XMStoreFloat( _debug_symbol_pDist, t );
return TRUE;
}
return FALSE;
}
BOOL _debug_symbol_IntersectRayAxisAlignedBox( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_pDist );
_debug_symbol_XMASSERT( _debug_symbol_XMVector3IsUnit( Direction ) );
static const _debug_symbol_XMVECTOR _debug_symbol_Epsilon =
{
1e-20f, 1e-20f, 1e-20f, 1e-20f
};
static const _debug_symbol_XMVECTOR _debug_symbol_FltMin =
{
-FLT_MAX, -FLT_MAX, -FLT_MAX, -FLT_MAX
};
static const _debug_symbol_XMVECTOR _debug_symbol_FltMax =
{
FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
};
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_TOrigin = Center - _debug_symbol_Origin;
_debug_symbol_XMVECTOR _debug_symbol_AxisDotOrigin = _debug_symbol_TOrigin;
_debug_symbol_XMVECTOR _debug_symbol_AxisDotDirection = Direction;
_debug_symbol_XMVECTOR _debug_symbol_IsParallel = _debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVectorAbs( _debug_symbol_AxisDotDirection ), _debug_symbol_Epsilon );
_debug_symbol_XMVECTOR _debug_symbol_InverseAxisDotDirection = _debug_symbol_XMVectorReciprocal( _debug_symbol_AxisDotDirection );
_debug_symbol_XMVECTOR t1 = ( _debug_symbol_AxisDotOrigin - Extents ) * _debug_symbol_InverseAxisDotDirection;
_debug_symbol_XMVECTOR t2 = ( _debug_symbol_AxisDotOrigin + Extents ) * _debug_symbol_InverseAxisDotDirection;
_debug_symbol_XMVECTOR _debug_symbol_t_min = _debug_symbol_XMVectorSelect( _debug_symbol_XMVectorMin( t1, t2 ), _debug_symbol_FltMin, _debug_symbol_IsParallel );
_debug_symbol_XMVECTOR _debug_symbol_t_max = _debug_symbol_XMVectorSelect( _debug_symbol_XMVectorMax( t1, t2 ), _debug_symbol_FltMax, _debug_symbol_IsParallel );
_debug_symbol_t_min = _debug_symbol_XMVectorMax( _debug_symbol_t_min, _debug_symbol_XMVectorSplatY( _debug_symbol_t_min ) );
_debug_symbol_t_min = _debug_symbol_XMVectorMax( _debug_symbol_t_min, _debug_symbol_XMVectorSplatZ( _debug_symbol_t_min ) );
_debug_symbol_t_max = _debug_symbol_XMVectorMin( _debug_symbol_t_max, _debug_symbol_XMVectorSplatY( _debug_symbol_t_max ) );
_debug_symbol_t_max = _debug_symbol_XMVectorMin( _debug_symbol_t_max, _debug_symbol_XMVectorSplatZ( _debug_symbol_t_max ) );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorGreater( _debug_symbol_XMVectorSplatX( _debug_symbol_t_min ), _debug_symbol_XMVectorSplatX( _debug_symbol_t_max ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( _debug_symbol_XMVectorSplatX( _debug_symbol_t_max ), _debug_symbol_XMVectorZero() ) );
_debug_symbol_XMVECTOR _debug_symbol_ParallelOverlap = _debug_symbol_XMVectorInBounds( _debug_symbol_AxisDotOrigin, Extents );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorAndCInt( _debug_symbol_IsParallel, _debug_symbol_ParallelOverlap ) );
if( !_debug_symbol_XMVector3AnyTrue( _debug_symbol_NoIntersection ) )
{
_debug_symbol_XMStoreFloat( _debug_symbol_pDist, _debug_symbol_t_min );
return TRUE;
}
return FALSE;
}
BOOL _debug_symbol_IntersectRayOrientedBox( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_OrientedBox* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_pDist );
_debug_symbol_XMASSERT( _debug_symbol_XMVector3IsUnit( Direction ) );
static const _debug_symbol_XMVECTOR _debug_symbol_Epsilon =
{
1e-20f, 1e-20f, 1e-20f, 1e-20f
};
static const _debug_symbol_XMVECTOR _debug_symbol_FltMin =
{
-FLT_MAX, -FLT_MAX, -FLT_MAX, -FLT_MAX
};
static const _debug_symbol_XMVECTOR _debug_symbol_FltMax =
{
FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectY =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectZ =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0
};
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMMATRIX _debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_TOrigin = Center - _debug_symbol_Origin;
_debug_symbol_XMVECTOR _debug_symbol_AxisDotOrigin = _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[0], _debug_symbol_TOrigin );
_debug_symbol_AxisDotOrigin = _debug_symbol_XMVectorSelect( _debug_symbol_AxisDotOrigin, _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[1], _debug_symbol_TOrigin ), _debug_symbol_SelectY );
_debug_symbol_AxisDotOrigin = _debug_symbol_XMVectorSelect( _debug_symbol_AxisDotOrigin, _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[2], _debug_symbol_TOrigin ), _debug_symbol_SelectZ );
_debug_symbol_XMVECTOR _debug_symbol_AxisDotDirection = _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[0], Direction );
_debug_symbol_AxisDotDirection = _debug_symbol_XMVectorSelect( _debug_symbol_AxisDotDirection, _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[1], Direction ), _debug_symbol_SelectY );
_debug_symbol_AxisDotDirection = _debug_symbol_XMVectorSelect( _debug_symbol_AxisDotDirection, _debug_symbol_XMVector3Dot( _debug_symbol_R._debug_symbol_r[2], Direction ), _debug_symbol_SelectZ );
_debug_symbol_XMVECTOR _debug_symbol_IsParallel = _debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVectorAbs( _debug_symbol_AxisDotDirection ), _debug_symbol_Epsilon );
_debug_symbol_XMVECTOR _debug_symbol_InverseAxisDotDirection = _debug_symbol_XMVectorReciprocal( _debug_symbol_AxisDotDirection );
_debug_symbol_XMVECTOR t1 = ( _debug_symbol_AxisDotOrigin - Extents ) * _debug_symbol_InverseAxisDotDirection;
_debug_symbol_XMVECTOR t2 = ( _debug_symbol_AxisDotOrigin + Extents ) * _debug_symbol_InverseAxisDotDirection;
_debug_symbol_XMVECTOR _debug_symbol_t_min = _debug_symbol_XMVectorSelect( _debug_symbol_XMVectorMin( t1, t2 ), _debug_symbol_FltMin, _debug_symbol_IsParallel );
_debug_symbol_XMVECTOR _debug_symbol_t_max = _debug_symbol_XMVectorSelect( _debug_symbol_XMVectorMax( t1, t2 ), _debug_symbol_FltMax, _debug_symbol_IsParallel );
_debug_symbol_t_min = _debug_symbol_XMVectorMax( _debug_symbol_t_min, _debug_symbol_XMVectorSplatY( _debug_symbol_t_min ) );
_debug_symbol_t_min = _debug_symbol_XMVectorMax( _debug_symbol_t_min, _debug_symbol_XMVectorSplatZ( _debug_symbol_t_min ) );
_debug_symbol_t_max = _debug_symbol_XMVectorMin( _debug_symbol_t_max, _debug_symbol_XMVectorSplatY( _debug_symbol_t_max ) );
_debug_symbol_t_max = _debug_symbol_XMVectorMin( _debug_symbol_t_max, _debug_symbol_XMVectorSplatZ( _debug_symbol_t_max ) );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorGreater( _debug_symbol_XMVectorSplatX( _debug_symbol_t_min ), _debug_symbol_XMVectorSplatX( _debug_symbol_t_max ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( _debug_symbol_XMVectorSplatX( _debug_symbol_t_max ), _debug_symbol_XMVectorZero() ) );
_debug_symbol_XMVECTOR _debug_symbol_ParallelOverlap = _debug_symbol_XMVectorInBounds( _debug_symbol_AxisDotOrigin, Extents );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorAndCInt( _debug_symbol_IsParallel, _debug_symbol_ParallelOverlap ) );
if( !_debug_symbol_XMVector3AnyTrue( _debug_symbol_NoIntersection ) )
{
_debug_symbol_XMStoreFloat( _debug_symbol_pDist, _debug_symbol_t_min );
return TRUE;
}
return FALSE;
}
BOOL _debug_symbol_IntersectTriangleTriangle( _debug_symbol_FXMVECTOR _debug_symbol_A0, _debug_symbol_FXMVECTOR _debug_symbol_A1, _debug_symbol_FXMVECTOR _debug_symbol_A2, _debug_symbol_CXMVECTOR _debug_symbol_B0, _debug_symbol_CXMVECTOR _debug_symbol_B1, _debug_symbol_CXMVECTOR _debug_symbol_B2 )
{
static const _debug_symbol_XMVECTOR _debug_symbol_Epsilon =
{
1e-20f, 1e-20f, 1e-20f, 1e-20f
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectY =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectZ =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_Select0111 =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_1
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_Select1011 =
{
_debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_1
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_Select1101 =
{
_debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1
};
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_N1 = _debug_symbol_XMVector3Cross( _debug_symbol_A1 - _debug_symbol_A0, _debug_symbol_A2 - _debug_symbol_A0 );
_debug_symbol_XMASSERT( !_debug_symbol_XMVector3Equal( _debug_symbol_N1, Zero ) );
_debug_symbol_XMVECTOR _debug_symbol_BDist = _debug_symbol_XMVector3Dot( _debug_symbol_N1, _debug_symbol_B0 - _debug_symbol_A0 );
_debug_symbol_BDist = _debug_symbol_XMVectorSelect( _debug_symbol_BDist, _debug_symbol_XMVector3Dot( _debug_symbol_N1, _debug_symbol_B1 - _debug_symbol_A0 ), _debug_symbol_SelectY );
_debug_symbol_BDist = _debug_symbol_XMVectorSelect( _debug_symbol_BDist, _debug_symbol_XMVector3Dot( _debug_symbol_N1, _debug_symbol_B2 - _debug_symbol_A0 ), _debug_symbol_SelectZ );
UINT _debug_symbol_BDistIsZeroCR;
_debug_symbol_XMVECTOR _debug_symbol_BDistIsZero = _debug_symbol_XMVectorGreaterR( &_debug_symbol_BDistIsZeroCR, _debug_symbol_Epsilon, _debug_symbol_XMVectorAbs( _debug_symbol_BDist ) );
_debug_symbol_BDist = _debug_symbol_XMVectorSelect( _debug_symbol_BDist, Zero, _debug_symbol_BDistIsZero );
UINT _debug_symbol_BDistIsLessCR;
_debug_symbol_XMVECTOR _debug_symbol_BDistIsLess = _debug_symbol_XMVectorGreaterR( &_debug_symbol_BDistIsLessCR, Zero, _debug_symbol_BDist );
UINT _debug_symbol_BDistIsGreaterCR;
_debug_symbol_XMVECTOR _debug_symbol_BDistIsGreater = _debug_symbol_XMVectorGreaterR( &_debug_symbol_BDistIsGreaterCR, _debug_symbol_BDist, Zero );
if( _debug_symbol_XMComparisonAllTrue( _debug_symbol_BDistIsLessCR ) || _debug_symbol_XMComparisonAllTrue( _debug_symbol_BDistIsGreaterCR ) )
return FALSE;
_debug_symbol_XMVECTOR _debug_symbol_N2 = _debug_symbol_XMVector3Cross( _debug_symbol_B1 - _debug_symbol_B0, _debug_symbol_B2 - _debug_symbol_B0 );
_debug_symbol_XMASSERT( !_debug_symbol_XMVector3Equal( _debug_symbol_N2, Zero ) );
_debug_symbol_XMVECTOR _debug_symbol_ADist = _debug_symbol_XMVector3Dot( _debug_symbol_N2, _debug_symbol_A0 - _debug_symbol_B0 );
_debug_symbol_ADist = _debug_symbol_XMVectorSelect( _debug_symbol_ADist, _debug_symbol_XMVector3Dot( _debug_symbol_N2, _debug_symbol_A1 - _debug_symbol_B0 ), _debug_symbol_SelectY );
_debug_symbol_ADist = _debug_symbol_XMVectorSelect( _debug_symbol_ADist, _debug_symbol_XMVector3Dot( _debug_symbol_N2, _debug_symbol_A2 - _debug_symbol_B0 ), _debug_symbol_SelectZ );
UINT _debug_symbol_ADistIsZeroCR;
_debug_symbol_XMVECTOR _debug_symbol_ADistIsZero = _debug_symbol_XMVectorGreaterR( &_debug_symbol_ADistIsZeroCR, _debug_symbol_Epsilon, _debug_symbol_XMVectorAbs( _debug_symbol_BDist ) );
_debug_symbol_ADist = _debug_symbol_XMVectorSelect( _debug_symbol_ADist, Zero, _debug_symbol_ADistIsZero );
UINT _debug_symbol_ADistIsLessCR;
_debug_symbol_XMVECTOR _debug_symbol_ADistIsLess = _debug_symbol_XMVectorGreaterR( &_debug_symbol_ADistIsLessCR, Zero, _debug_symbol_ADist );
UINT _debug_symbol_ADistIsGreaterCR;
_debug_symbol_XMVECTOR _debug_symbol_ADistIsGreater = _debug_symbol_XMVectorGreaterR( &_debug_symbol_ADistIsGreaterCR, _debug_symbol_ADist, Zero );
if( _debug_symbol_XMComparisonAllTrue( _debug_symbol_ADistIsLessCR ) || _debug_symbol_XMComparisonAllTrue( _debug_symbol_ADistIsGreaterCR ) )
return FALSE;
if( _debug_symbol_XMComparisonAllTrue( _debug_symbol_ADistIsZeroCR ) || _debug_symbol_XMComparisonAllTrue( _debug_symbol_BDistIsZeroCR ) )
{
_debug_symbol_XMVECTOR Axis, _debug_symbol_Dist, _debug_symbol_MinDist;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N1, _debug_symbol_A1 - _debug_symbol_A0 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_A0 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_B0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N1, _debug_symbol_A2 - _debug_symbol_A1 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_A1 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_B0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N1, _debug_symbol_A0 - _debug_symbol_A2 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_A2 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_B0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_B2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N2, _debug_symbol_B1 - _debug_symbol_B0 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_B0 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_A0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N2, _debug_symbol_B2 - _debug_symbol_B1 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_B1 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_A0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
Axis = _debug_symbol_XMVector3Cross( _debug_symbol_N2, _debug_symbol_B0 - _debug_symbol_B2 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_B2 );
_debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_A0, Axis );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A1, Axis ) );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_XMVector3Dot( _debug_symbol_A2, Axis ) );
if( _debug_symbol_XMVector4GreaterOrEqual( _debug_symbol_MinDist, _debug_symbol_Dist ) )
return FALSE;
return TRUE;
}
_debug_symbol_XMVECTOR _debug_symbol_ADistIsLessEqual = _debug_symbol_XMVectorOrInt( _debug_symbol_ADistIsLess, _debug_symbol_ADistIsZero );
_debug_symbol_XMVECTOR _debug_symbol_ADistIsGreaterEqual = _debug_symbol_XMVectorOrInt( _debug_symbol_ADistIsGreater, _debug_symbol_ADistIsZero );
_debug_symbol_XMVECTOR _debug_symbol_AA0, _debug_symbol_AA1, _debug_symbol_AA2;
bool _debug_symbol_bPositiveA;
if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreaterEqual, _debug_symbol_ADistIsLess, _debug_symbol_Select0111 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreater, _debug_symbol_ADistIsLessEqual, _debug_symbol_Select0111 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A0; _debug_symbol_AA1 = _debug_symbol_A1; _debug_symbol_AA2 = _debug_symbol_A2;
_debug_symbol_bPositiveA = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLessEqual, _debug_symbol_ADistIsGreater, _debug_symbol_Select0111 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLess, _debug_symbol_ADistIsGreaterEqual, _debug_symbol_Select0111 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A0; _debug_symbol_AA1 = _debug_symbol_A2; _debug_symbol_AA2 = _debug_symbol_A1;
_debug_symbol_bPositiveA = false;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreaterEqual, _debug_symbol_ADistIsLess, _debug_symbol_Select1011 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreater, _debug_symbol_ADistIsLessEqual, _debug_symbol_Select1011 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A1; _debug_symbol_AA1 = _debug_symbol_A2; _debug_symbol_AA2 = _debug_symbol_A0;
_debug_symbol_bPositiveA = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLessEqual, _debug_symbol_ADistIsGreater, _debug_symbol_Select1011 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLess, _debug_symbol_ADistIsGreaterEqual, _debug_symbol_Select1011 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A1; _debug_symbol_AA1 = _debug_symbol_A0; _debug_symbol_AA2 = _debug_symbol_A2;
_debug_symbol_bPositiveA = false;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreaterEqual, _debug_symbol_ADistIsLess, _debug_symbol_Select1101 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsGreater, _debug_symbol_ADistIsLessEqual, _debug_symbol_Select1101 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A2; _debug_symbol_AA1 = _debug_symbol_A0; _debug_symbol_AA2 = _debug_symbol_A1;
_debug_symbol_bPositiveA = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLessEqual, _debug_symbol_ADistIsGreater, _debug_symbol_Select1101 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_ADistIsLess, _debug_symbol_ADistIsGreaterEqual, _debug_symbol_Select1101 ) ) )
{
_debug_symbol_AA0 = _debug_symbol_A2; _debug_symbol_AA1 = _debug_symbol_A1; _debug_symbol_AA2 = _debug_symbol_A0;
_debug_symbol_bPositiveA = false;
}
else
{
_debug_symbol_XMASSERT( FALSE );
return FALSE;
}
_debug_symbol_XMVECTOR _debug_symbol_BDistIsLessEqual = _debug_symbol_XMVectorOrInt( _debug_symbol_BDistIsLess, _debug_symbol_BDistIsZero );
_debug_symbol_XMVECTOR _debug_symbol_BDistIsGreaterEqual = _debug_symbol_XMVectorOrInt( _debug_symbol_BDistIsGreater, _debug_symbol_BDistIsZero );
_debug_symbol_XMVECTOR _debug_symbol_BB0, _debug_symbol_BB1, _debug_symbol_BB2;
bool _debug_symbol_bPositiveB;
if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreaterEqual, _debug_symbol_BDistIsLess, _debug_symbol_Select0111 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreater, _debug_symbol_BDistIsLessEqual, _debug_symbol_Select0111 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B0; _debug_symbol_BB1 = _debug_symbol_B1; _debug_symbol_BB2 = _debug_symbol_B2;
_debug_symbol_bPositiveB = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLessEqual, _debug_symbol_BDistIsGreater, _debug_symbol_Select0111 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLess, _debug_symbol_BDistIsGreaterEqual, _debug_symbol_Select0111 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B0; _debug_symbol_BB1 = _debug_symbol_B2; _debug_symbol_BB2 = _debug_symbol_B1;
_debug_symbol_bPositiveB = false;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreaterEqual, _debug_symbol_BDistIsLess, _debug_symbol_Select1011 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreater, _debug_symbol_BDistIsLessEqual, _debug_symbol_Select1011 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B1; _debug_symbol_BB1 = _debug_symbol_B2; _debug_symbol_BB2 = _debug_symbol_B0;
_debug_symbol_bPositiveB = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLessEqual, _debug_symbol_BDistIsGreater, _debug_symbol_Select1011 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLess, _debug_symbol_BDistIsGreaterEqual, _debug_symbol_Select1011 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B1; _debug_symbol_BB1 = _debug_symbol_B0; _debug_symbol_BB2 = _debug_symbol_B2;
_debug_symbol_bPositiveB = false;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreaterEqual, _debug_symbol_BDistIsLess, _debug_symbol_Select1101 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsGreater, _debug_symbol_BDistIsLessEqual, _debug_symbol_Select1101 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B2; _debug_symbol_BB1 = _debug_symbol_B0; _debug_symbol_BB2 = _debug_symbol_B1;
_debug_symbol_bPositiveB = true;
}
else if( _debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLessEqual, _debug_symbol_BDistIsGreater, _debug_symbol_Select1101 ) ) ||
_debug_symbol_XMVector3AllTrue( _debug_symbol_XMVectorSelect( _debug_symbol_BDistIsLess, _debug_symbol_BDistIsGreaterEqual, _debug_symbol_Select1101 ) ) )
{
_debug_symbol_BB0 = _debug_symbol_B2; _debug_symbol_BB1 = _debug_symbol_B1; _debug_symbol_BB2 = _debug_symbol_B0;
_debug_symbol_bPositiveB = false;
}
else
{
_debug_symbol_XMASSERT( FALSE );
return FALSE;
}
_debug_symbol_XMVECTOR _debug_symbol_Delta0, _debug_symbol_Delta1;
if( _debug_symbol_bPositiveA ^ _debug_symbol_bPositiveB )
{
_debug_symbol_Delta0 = ( _debug_symbol_BB0 - _debug_symbol_AA0 );
_debug_symbol_Delta1 = ( _debug_symbol_AA0 - _debug_symbol_BB0 );
}
else
{
_debug_symbol_Delta0 = ( _debug_symbol_AA0 - _debug_symbol_BB0 );
_debug_symbol_Delta1 = ( _debug_symbol_BB0 - _debug_symbol_AA0 );
}
_debug_symbol_XMVECTOR _debug_symbol_Dist0 = _debug_symbol_XMVector3Dot( _debug_symbol_Delta0, _debug_symbol_XMVector3Cross( ( _debug_symbol_BB2 - _debug_symbol_BB0 ), ( _debug_symbol_AA2 - _debug_symbol_AA0 ) ) );
if( _debug_symbol_XMVector4Greater( _debug_symbol_Dist0, Zero ) )
return FALSE;
_debug_symbol_XMVECTOR _debug_symbol_Dist1 = _debug_symbol_XMVector3Dot( _debug_symbol_Delta1, _debug_symbol_XMVector3Cross( ( _debug_symbol_BB1 - _debug_symbol_BB0 ), ( _debug_symbol_AA1 - _debug_symbol_AA0 ) ) );
if( _debug_symbol_XMVector4Greater( _debug_symbol_Dist1, Zero ) )
return FALSE;
return TRUE;
}
BOOL _debug_symbol_IntersectTriangleSphere( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_Sphere* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Radius );
_debug_symbol_XMVECTOR N = _debug_symbol_XMVector3Normalize( _debug_symbol_XMVector3Cross( _debug_symbol_V1 - _debug_symbol_V0, _debug_symbol_V2 - _debug_symbol_V0 ) );
_debug_symbol_XMASSERT( !_debug_symbol_XMVector3Equal( N, _debug_symbol_XMVectorZero() ) );
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector3Dot( Center - _debug_symbol_V0, N );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorLess( _debug_symbol_Dist, -_debug_symbol_Radius );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_Radius ) );
_debug_symbol_XMVECTOR Point = Center - ( N * _debug_symbol_Dist );
_debug_symbol_XMVECTOR _debug_symbol_Intersection = _debug_symbol_PointOnPlaneInsideTriangle( Point, _debug_symbol_V0, _debug_symbol_V1, _debug_symbol_V2 );
_debug_symbol_XMVECTOR _debug_symbol_RadiusSq = _debug_symbol_Radius * _debug_symbol_Radius;
Point = _debug_symbol_PointOnLineSegmentNearestPoint( _debug_symbol_V0, _debug_symbol_V1, Center );
_debug_symbol_Intersection = _debug_symbol_XMVectorOrInt( _debug_symbol_Intersection, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVector3LengthSq( Center - Point ), _debug_symbol_RadiusSq ) );
Point = _debug_symbol_PointOnLineSegmentNearestPoint( _debug_symbol_V1, _debug_symbol_V2, Center );
_debug_symbol_Intersection = _debug_symbol_XMVectorOrInt( _debug_symbol_Intersection, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVector3LengthSq( Center - Point ), _debug_symbol_RadiusSq ) );
Point = _debug_symbol_PointOnLineSegmentNearestPoint( _debug_symbol_V2, _debug_symbol_V0, Center );
_debug_symbol_Intersection = _debug_symbol_XMVectorOrInt( _debug_symbol_Intersection, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVector3LengthSq( Center - Point ), _debug_symbol_RadiusSq ) );
return _debug_symbol_XMVector4EqualInt( _debug_symbol_XMVectorAndCInt( _debug_symbol_Intersection, _debug_symbol_NoIntersection ), _debug_symbol_XMVectorTrueInt() );
}
BOOL _debug_symbol_IntersectTriangleAxisAlignedBox( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute0W1Z0Y0X =
{
_debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_1Z, _debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0X
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute0Z0W1X0Y =
{
_debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_1X, _debug_symbol_XM_PERMUTE_0Y
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute1Y0X0W0Z =
{
_debug_symbol_XM_PERMUTE_1Y, _debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_0Z
};
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxMin = Center - Extents;
_debug_symbol_XMVECTOR _debug_symbol_BoxMax = Center + Extents;
_debug_symbol_XMVECTOR _debug_symbol_TriMin = _debug_symbol_XMVectorMin( _debug_symbol_XMVectorMin( _debug_symbol_V0, _debug_symbol_V1 ), _debug_symbol_V2 );
_debug_symbol_XMVECTOR _debug_symbol_TriMax = _debug_symbol_XMVectorMax( _debug_symbol_XMVectorMax( _debug_symbol_V0, _debug_symbol_V1 ), _debug_symbol_V2 );
_debug_symbol_XMVECTOR _debug_symbol_Disjoint = _debug_symbol_XMVectorOrInt( _debug_symbol_XMVectorGreater( _debug_symbol_TriMin, _debug_symbol_BoxMax ), _debug_symbol_XMVectorGreater( _debug_symbol_BoxMin, _debug_symbol_TriMax ) );
if( _debug_symbol_XMVector3AnyTrue( _debug_symbol_Disjoint ) )
return FALSE;
_debug_symbol_XMVECTOR _debug_symbol_Normal = _debug_symbol_XMVector3Cross( _debug_symbol_V1 - _debug_symbol_V0, _debug_symbol_V2 - _debug_symbol_V0 );
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Normal, _debug_symbol_V0 );
_debug_symbol_XMASSERT( !_debug_symbol_XMVector3Equal( _debug_symbol_Normal, Zero ) );
_debug_symbol_XMVECTOR _debug_symbol_NormalSelect = _debug_symbol_XMVectorGreater( _debug_symbol_Normal, Zero );
_debug_symbol_XMVECTOR _debug_symbol_V_Min = _debug_symbol_XMVectorSelect( _debug_symbol_BoxMax, _debug_symbol_BoxMin, _debug_symbol_NormalSelect );
_debug_symbol_XMVECTOR _debug_symbol_V_Max = _debug_symbol_XMVectorSelect( _debug_symbol_BoxMin, _debug_symbol_BoxMax, _debug_symbol_NormalSelect );
_debug_symbol_XMVECTOR _debug_symbol_MinDist = _debug_symbol_XMVector3Dot( _debug_symbol_V_Min, _debug_symbol_Normal );
_debug_symbol_XMVECTOR _debug_symbol_MaxDist = _debug_symbol_XMVector3Dot( _debug_symbol_V_Max, _debug_symbol_Normal );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorGreater( _debug_symbol_MinDist, _debug_symbol_Dist );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( _debug_symbol_MaxDist, _debug_symbol_Dist ) );
_debug_symbol_XMVECTOR _debug_symbol_TV0 = _debug_symbol_V0 - Center;
_debug_symbol_XMVECTOR _debug_symbol_TV1 = _debug_symbol_V1 - Center;
_debug_symbol_XMVECTOR _debug_symbol_TV2 = _debug_symbol_V2 - Center;
_debug_symbol_XMVECTOR _debug_symbol_e0 = _debug_symbol_TV1 - _debug_symbol_TV0;
_debug_symbol_XMVECTOR _debug_symbol_e1 = _debug_symbol_TV2 - _debug_symbol_TV1;
_debug_symbol_XMVECTOR _debug_symbol_e2 = _debug_symbol_TV0 - _debug_symbol_TV2;
_debug_symbol_e0 = _debug_symbol_XMVectorInsert( _debug_symbol_e0, Zero, 0, 0, 0, 0, 1 );
_debug_symbol_e1 = _debug_symbol_XMVectorInsert( _debug_symbol_e1, Zero, 0, 0, 0, 0, 1 );
_debug_symbol_e2 = _debug_symbol_XMVectorInsert( _debug_symbol_e2, Zero, 0, 0, 0, 0, 1 );
_debug_symbol_XMVECTOR Axis;
_debug_symbol_XMVECTOR _debug_symbol_p0, p1, p2;
_debug_symbol_XMVECTOR Min, Max;
_debug_symbol_XMVECTOR _debug_symbol_Radius;
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e0, -_debug_symbol_e0, _debug_symbol_Permute0W1Z0Y0X );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p2 = _debug_symbol_XMVector3Dot( _debug_symbol_TV2, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p2 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p2 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e1, -_debug_symbol_e1, _debug_symbol_Permute0W1Z0Y0X );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e2, -_debug_symbol_e2, _debug_symbol_Permute0W1Z0Y0X );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e0, -_debug_symbol_e0, _debug_symbol_Permute0Z0W1X0Y );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p2 = _debug_symbol_XMVector3Dot( _debug_symbol_TV2, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p2 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p2 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e1, -_debug_symbol_e1, _debug_symbol_Permute0Z0W1X0Y );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e2, -_debug_symbol_e2, _debug_symbol_Permute0Z0W1X0Y );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e0, -_debug_symbol_e0, _debug_symbol_Permute1Y0X0W0Z );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p2 = _debug_symbol_XMVector3Dot( _debug_symbol_TV2, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p2 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p2 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e1, -_debug_symbol_e1, _debug_symbol_Permute1Y0X0W0Z );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
Axis = _debug_symbol_XMVectorPermute( _debug_symbol_e2, -_debug_symbol_e2, _debug_symbol_Permute1Y0X0W0Z );
_debug_symbol_p0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Axis );
p1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Axis );
Min = _debug_symbol_XMVectorMin( _debug_symbol_p0, p1 );
Max = _debug_symbol_XMVectorMax( _debug_symbol_p0, p1 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( Axis ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorGreater( Min, _debug_symbol_Radius ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorLess( Max, -_debug_symbol_Radius ) );
return _debug_symbol_XMVector4NotEqualInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorTrueInt() );
}
BOOL _debug_symbol_IntersectTriangleOrientedBox( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_OrientedBox* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMVECTOR _debug_symbol_TV0 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V0 - Center, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_TV1 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V1 - Center, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_TV2 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V2 - Center, _debug_symbol_Orientation );
_debug_symbol_AxisAlignedBox _debug_symbol_Box;
_debug_symbol_Box.Center = _debug_symbol_XMFLOAT3( 0.0f, 0.0f, 0.0f );
_debug_symbol_Box.Extents = _debug_symbol_pVolume->Extents;
return _debug_symbol_IntersectTriangleAxisAlignedBox( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, &_debug_symbol_Box );
}
BOOL _debug_symbol_IntersectSphereSphere( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_Sphere* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_CenterA = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_RadiusA = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Radius );
_debug_symbol_XMVECTOR _debug_symbol_CenterB = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR _debug_symbol_RadiusB = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->_debug_symbol_Radius );
_debug_symbol_XMVECTOR Delta = _debug_symbol_CenterB - _debug_symbol_CenterA;
_debug_symbol_XMVECTOR _debug_symbol_DistanceSquared = _debug_symbol_XMVector3LengthSq( Delta );
_debug_symbol_XMVECTOR _debug_symbol_RadiusSquared = _debug_symbol_RadiusA + _debug_symbol_RadiusB;
_debug_symbol_RadiusSquared = _debug_symbol_RadiusSquared * _debug_symbol_RadiusSquared;
return _debug_symbol_XMVector4LessOrEqual( _debug_symbol_DistanceSquared, _debug_symbol_RadiusSquared );
}
BOOL _debug_symbol_IntersectSphereAxisAlignedBox( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_SphereCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_SphereRadius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Radius );
_debug_symbol_XMVECTOR _debug_symbol_BoxCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR _debug_symbol_BoxExtents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxMin = _debug_symbol_BoxCenter - _debug_symbol_BoxExtents;
_debug_symbol_XMVECTOR _debug_symbol_BoxMax = _debug_symbol_BoxCenter + _debug_symbol_BoxExtents;
_debug_symbol_XMVECTOR _debug_symbol_d = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_LessThanMin = _debug_symbol_XMVectorLess( _debug_symbol_SphereCenter, _debug_symbol_BoxMin );
_debug_symbol_XMVECTOR _debug_symbol_GreaterThanMax = _debug_symbol_XMVectorGreater( _debug_symbol_SphereCenter, _debug_symbol_BoxMax );
_debug_symbol_XMVECTOR _debug_symbol_MinDelta = _debug_symbol_SphereCenter - _debug_symbol_BoxMin;
_debug_symbol_XMVECTOR _debug_symbol_MaxDelta = _debug_symbol_SphereCenter - _debug_symbol_BoxMax;
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, _debug_symbol_MinDelta, _debug_symbol_LessThanMin );
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, _debug_symbol_MaxDelta, _debug_symbol_GreaterThanMax );
_debug_symbol_XMVECTOR _debug_symbol_d2 = _debug_symbol_XMVector3Dot( _debug_symbol_d, _debug_symbol_d );
return _debug_symbol_XMVector4LessOrEqual( _debug_symbol_d2, _debug_symbol_XMVectorMultiply( _debug_symbol_SphereRadius, _debug_symbol_SphereRadius ) );
}
float _debug_symbol_OverlapSphereOrientedBox( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB, _debug_symbol_XMFLOAT3& dir )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_SphereCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_SphereRadius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Radius );
_debug_symbol_XMVECTOR _debug_symbol_BoxCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR _debug_symbol_BoxExtents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_BoxOrientation ) );
_debug_symbol_SphereCenter = _debug_symbol_XMVector3InverseRotate( _debug_symbol_SphereCenter - _debug_symbol_BoxCenter, _debug_symbol_BoxOrientation );
_debug_symbol_XMVECTOR _debug_symbol_d = _debug_symbol_SphereCenter;
_debug_symbol_XMVECTOR _debug_symbol_LessThanMin = _debug_symbol_XMVectorLess( _debug_symbol_SphereCenter, -_debug_symbol_BoxExtents );
_debug_symbol_XMVECTOR _debug_symbol_GreaterThanMax = _debug_symbol_XMVectorGreater( _debug_symbol_SphereCenter, _debug_symbol_BoxExtents );
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, -_debug_symbol_BoxExtents, _debug_symbol_LessThanMin );
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, _debug_symbol_BoxExtents, _debug_symbol_GreaterThanMax );
_debug_symbol_d = _debug_symbol_SphereCenter - _debug_symbol_d;
_debug_symbol_XMVECTOR _debug_symbol_d2 = _debug_symbol_XMVector3Length(_debug_symbol_d);
_debug_symbol_XMVECTOR _debug_symbol_correct = _debug_symbol_d;
_debug_symbol_correct = _debug_symbol_XMVector3Normalize(_debug_symbol_correct);
_debug_symbol_correct = _debug_symbol_XMVector3Rotate(_debug_symbol_correct, _debug_symbol_BoxOrientation);
_debug_symbol_XMStoreFloat3(&dir, _debug_symbol_correct);
float _debug_symbol_overlap = _debug_symbol_pVolumeA->_debug_symbol_Radius - _debug_symbol_d2._debug_symbol_m128_f32[0];
return _debug_symbol_overlap;
}
BOOL _debug_symbol_IntersectSphereOrientedBox( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_SphereCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_SphereRadius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Radius );
_debug_symbol_XMVECTOR _debug_symbol_BoxCenter = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR _debug_symbol_BoxExtents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_BoxOrientation ) );
_debug_symbol_SphereCenter = _debug_symbol_XMVector3InverseRotate( _debug_symbol_SphereCenter - _debug_symbol_BoxCenter, _debug_symbol_BoxOrientation );
_debug_symbol_XMVECTOR _debug_symbol_d = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_LessThanMin = _debug_symbol_XMVectorLess( _debug_symbol_SphereCenter, -_debug_symbol_BoxExtents );
_debug_symbol_XMVECTOR _debug_symbol_GreaterThanMax = _debug_symbol_XMVectorGreater( _debug_symbol_SphereCenter, _debug_symbol_BoxExtents );
_debug_symbol_XMVECTOR _debug_symbol_MinDelta = _debug_symbol_SphereCenter + _debug_symbol_BoxExtents;
_debug_symbol_XMVECTOR _debug_symbol_MaxDelta = _debug_symbol_SphereCenter - _debug_symbol_BoxExtents;
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, _debug_symbol_MinDelta, _debug_symbol_LessThanMin );
_debug_symbol_d = _debug_symbol_XMVectorSelect( _debug_symbol_d, _debug_symbol_MaxDelta, _debug_symbol_GreaterThanMax );
_debug_symbol_XMVECTOR _debug_symbol_d2 = _debug_symbol_XMVector3Dot( _debug_symbol_d, _debug_symbol_d );
return _debug_symbol_XMVector4LessOrEqual( _debug_symbol_d2, _debug_symbol_XMVectorMultiply( _debug_symbol_SphereRadius, _debug_symbol_SphereRadius ) );
}
BOOL _debug_symbol_IntersectAxisAlignedBoxAxisAlignedBox( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_CenterA = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_ExtentsA = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Extents );
_debug_symbol_XMVECTOR _debug_symbol_CenterB = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR _debug_symbol_ExtentsB = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Extents );
_debug_symbol_XMVECTOR _debug_symbol_MinA = _debug_symbol_CenterA - _debug_symbol_ExtentsA;
_debug_symbol_XMVECTOR _debug_symbol_MaxA = _debug_symbol_CenterA + _debug_symbol_ExtentsA;
_debug_symbol_XMVECTOR _debug_symbol_MinB = _debug_symbol_CenterB - _debug_symbol_ExtentsB;
_debug_symbol_XMVECTOR _debug_symbol_MaxB = _debug_symbol_CenterB + _debug_symbol_ExtentsB;
_debug_symbol_XMVECTOR _debug_symbol_Disjoint = _debug_symbol_XMVectorOrInt( _debug_symbol_XMVectorGreater( _debug_symbol_MinA, _debug_symbol_MaxB ), _debug_symbol_XMVectorGreater( _debug_symbol_MinB, _debug_symbol_MaxA ) );
return !_debug_symbol_XMVector3AnyTrue( _debug_symbol_Disjoint );
}
BOOL _debug_symbol_IntersectAxisAlignedBoxOrientedBox( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_OrientedBox _debug_symbol_BoxA;
_debug_symbol_BoxA.Center = _debug_symbol_pVolumeA->Center;
_debug_symbol_BoxA.Extents = _debug_symbol_pVolumeA->Extents;
_debug_symbol_BoxA._debug_symbol_Orientation.x = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation.y = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation._debug_symbol_z = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation.w = 1.0f;
return _debug_symbol_IntersectOrientedBoxOrientedBox( &_debug_symbol_BoxA, _debug_symbol_pVolumeB );
}
BOOL _debug_symbol_IntersectOrientedBoxOrientedBox( const _debug_symbol_OrientedBox* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB )
{
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute0W1Z0Y0X  =
{
_debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_1Z, _debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0X
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute0Z0W1X0Y =
{
_debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_1X, _debug_symbol_XM_PERMUTE_0Y
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_Permute1Y0X0W0Z =
{
_debug_symbol_XM_PERMUTE_1Y, _debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_0Z
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_PermuteWZYX =
{
_debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0X
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_PermuteZWXY =
{
_debug_symbol_XM_PERMUTE_0Z, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0Y
};
static CONST _debug_symbol_XMVECTORI32 _debug_symbol_PermuteYXWZ =
{
_debug_symbol_XM_PERMUTE_0Y, _debug_symbol_XM_PERMUTE_0X, _debug_symbol_XM_PERMUTE_0W, _debug_symbol_XM_PERMUTE_0Z
};
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_A_quat = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeA->_debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_B_quat = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_A_quat ) );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_B_quat ) );
_debug_symbol_XMVECTOR Q = _debug_symbol_XMQuaternionMultiply( _debug_symbol_A_quat, _debug_symbol_XMQuaternionConjugate( _debug_symbol_B_quat ) );
_debug_symbol_XMMATRIX _debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( Q );
_debug_symbol_XMVECTOR _debug_symbol_A_cent = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_B_cent = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Center );
_debug_symbol_XMVECTOR t = _debug_symbol_XMVector3InverseRotate( _debug_symbol_B_cent - _debug_symbol_A_cent, _debug_symbol_A_quat );
_debug_symbol_XMVECTOR _debug_symbol_h_A = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Extents );
_debug_symbol_XMVECTOR _debug_symbol_h_B = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->Extents );
_debug_symbol_XMVECTOR _debug_symbol_R0X = _debug_symbol_R._debug_symbol_r[0];
_debug_symbol_XMVECTOR _debug_symbol_R1X = _debug_symbol_R._debug_symbol_r[1];
_debug_symbol_XMVECTOR _debug_symbol_R2X = _debug_symbol_R._debug_symbol_r[2];
_debug_symbol_R = _debug_symbol_XMMatrixTranspose( _debug_symbol_R );
_debug_symbol_XMVECTOR _debug_symbol_RX0 = _debug_symbol_R._debug_symbol_r[0];
_debug_symbol_XMVECTOR _debug_symbol_RX1 = _debug_symbol_R._debug_symbol_r[1];
_debug_symbol_XMVECTOR _debug_symbol_RX2 = _debug_symbol_R._debug_symbol_r[2];
_debug_symbol_XMVECTOR _debug_symbol_AR0X = _debug_symbol_XMVectorAbs( _debug_symbol_R0X );
_debug_symbol_XMVECTOR _debug_symbol_AR1X = _debug_symbol_XMVectorAbs( _debug_symbol_R1X );
_debug_symbol_XMVECTOR _debug_symbol_AR2X = _debug_symbol_XMVectorAbs( _debug_symbol_R2X );
_debug_symbol_XMVECTOR _debug_symbol_ARX0 = _debug_symbol_XMVectorAbs( _debug_symbol_RX0 );
_debug_symbol_XMVECTOR _debug_symbol_ARX1 = _debug_symbol_XMVectorAbs( _debug_symbol_RX1 );
_debug_symbol_XMVECTOR _debug_symbol_ARX2 = _debug_symbol_XMVectorAbs( _debug_symbol_RX2 );
_debug_symbol_XMVECTOR _debug_symbol_d, _debug_symbol_d_A, _debug_symbol_d_B;
_debug_symbol_d = _debug_symbol_XMVectorSplatX( t );
_debug_symbol_d_A = _debug_symbol_XMVectorSplatX( _debug_symbol_h_A );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_AR0X );
_debug_symbol_XMVECTOR _debug_symbol_NoIntersection = _debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) );
_debug_symbol_d = _debug_symbol_XMVectorSplatY( t );
_debug_symbol_d_A = _debug_symbol_XMVectorSplatY( _debug_symbol_h_A );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_AR1X );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVectorSplatZ( t );
_debug_symbol_d_A = _debug_symbol_XMVectorSplatZ( _debug_symbol_h_A );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_AR2X );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_RX0 );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_ARX0 );
_debug_symbol_d_B = _debug_symbol_XMVectorSplatX( _debug_symbol_h_B );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_RX1 );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_ARX1 );
_debug_symbol_d_B = _debug_symbol_XMVectorSplatY( _debug_symbol_h_B );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_RX2 );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_ARX2 );
_debug_symbol_d_B = _debug_symbol_XMVectorSplatZ( _debug_symbol_h_B );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX0, -_debug_symbol_RX0, _debug_symbol_Permute0W1Z0Y0X ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX0, _debug_symbol_ARX0, _debug_symbol_PermuteWZYX ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR0X, _debug_symbol_AR0X, _debug_symbol_PermuteWZYX ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX1, -_debug_symbol_RX1, _debug_symbol_Permute0W1Z0Y0X ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX1, _debug_symbol_ARX1, _debug_symbol_PermuteWZYX ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR0X, _debug_symbol_AR0X, _debug_symbol_PermuteZWXY ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX2, -_debug_symbol_RX2, _debug_symbol_Permute0W1Z0Y0X ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX2, _debug_symbol_ARX2, _debug_symbol_PermuteWZYX ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR0X, _debug_symbol_AR0X, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX0, -_debug_symbol_RX0, _debug_symbol_Permute0Z0W1X0Y ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX0, _debug_symbol_ARX0, _debug_symbol_PermuteZWXY ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR1X, _debug_symbol_AR1X, _debug_symbol_PermuteWZYX ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX1, -_debug_symbol_RX1, _debug_symbol_Permute0Z0W1X0Y ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX1, _debug_symbol_ARX1, _debug_symbol_PermuteZWXY ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR1X, _debug_symbol_AR1X, _debug_symbol_PermuteZWXY ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX2, -_debug_symbol_RX2, _debug_symbol_Permute0Z0W1X0Y ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX2, _debug_symbol_ARX2, _debug_symbol_PermuteZWXY ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR1X, _debug_symbol_AR1X, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX0, -_debug_symbol_RX0, _debug_symbol_Permute1Y0X0W0Z ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX0, _debug_symbol_ARX0, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR2X, _debug_symbol_AR2X, _debug_symbol_PermuteWZYX ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX1, -_debug_symbol_RX1, _debug_symbol_Permute1Y0X0W0Z ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX1, _debug_symbol_ARX1, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR2X, _debug_symbol_AR2X, _debug_symbol_PermuteZWXY ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
_debug_symbol_d = _debug_symbol_XMVector3Dot( t, _debug_symbol_XMVectorPermute( _debug_symbol_RX2, -_debug_symbol_RX2, _debug_symbol_Permute1Y0X0W0Z ) );
_debug_symbol_d_A = _debug_symbol_XMVector3Dot( _debug_symbol_h_A, _debug_symbol_XMVectorPermute( _debug_symbol_ARX2, _debug_symbol_ARX2, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_d_B = _debug_symbol_XMVector3Dot( _debug_symbol_h_B, _debug_symbol_XMVectorPermute( _debug_symbol_AR2X, _debug_symbol_AR2X, _debug_symbol_PermuteYXWZ ) );
_debug_symbol_NoIntersection = _debug_symbol_XMVectorOrInt( _debug_symbol_NoIntersection,
_debug_symbol_XMVectorGreater( _debug_symbol_XMVectorAbs(_debug_symbol_d), _debug_symbol_XMVectorAdd( _debug_symbol_d_A, _debug_symbol_d_B ) ) );
return _debug_symbol_XMVector4NotEqualInt( _debug_symbol_NoIntersection, _debug_symbol_XMVectorTrueInt() );
}
INT _debug_symbol_IntersectTriangleFrustum( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_Frustum* _debug_symbol_pVolume )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Planes[6];
Planes[0] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, -_debug_symbol_pVolume->_debug_symbol_Near );
Planes[1] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, _debug_symbol_pVolume->Far );
Planes[2] = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolume->_debug_symbol_RightSlope, 0.0f );
Planes[3] = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolume->_debug_symbol_LeftSlope, 0.0f );
Planes[4] = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolume->_debug_symbol_TopSlope, 0.0f );
Planes[5] = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMVECTOR _debug_symbol_TV0 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V0 - _debug_symbol_Origin, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_TV1 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V1 - _debug_symbol_Origin, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_TV2 = _debug_symbol_XMVector3InverseRotate( _debug_symbol_V2 - _debug_symbol_Origin, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_Outside = _debug_symbol_XMVectorFalseInt();
_debug_symbol_XMVECTOR _debug_symbol_InsideAll = _debug_symbol_XMVectorTrueInt();
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist0 = _debug_symbol_XMVector3Dot( _debug_symbol_TV0, Planes[i] );
_debug_symbol_XMVECTOR _debug_symbol_Dist1 = _debug_symbol_XMVector3Dot( _debug_symbol_TV1, Planes[i] );
_debug_symbol_XMVECTOR _debug_symbol_Dist2 = _debug_symbol_XMVector3Dot( _debug_symbol_TV2, Planes[i] );
_debug_symbol_XMVECTOR _debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_Dist2 );
_debug_symbol_XMVECTOR _debug_symbol_MaxDist = _debug_symbol_XMVectorMax( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MaxDist = _debug_symbol_XMVectorMax( _debug_symbol_MaxDist, _debug_symbol_Dist2 );
_debug_symbol_XMVECTOR _debug_symbol_PlaneDist = _debug_symbol_XMVectorSplatW( Planes[i] );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_MinDist, _debug_symbol_PlaneDist ) );
_debug_symbol_InsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_MaxDist, _debug_symbol_PlaneDist ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 2;
_debug_symbol_XMVECTOR _debug_symbol_RightTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Near = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Near );
_debug_symbol_XMVECTOR Far = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->Far );
_debug_symbol_XMVECTOR _debug_symbol_Corners[8];
_debug_symbol_Corners[0] = _debug_symbol_RightTop * _debug_symbol_Near;
_debug_symbol_Corners[1] = _debug_symbol_RightBottom * _debug_symbol_Near;
_debug_symbol_Corners[2] = _debug_symbol_LeftTop * _debug_symbol_Near;
_debug_symbol_Corners[3] = _debug_symbol_LeftBottom * _debug_symbol_Near;
_debug_symbol_Corners[4] = _debug_symbol_RightTop * Far;
_debug_symbol_Corners[5] = _debug_symbol_RightBottom * Far;
_debug_symbol_Corners[6] = _debug_symbol_LeftTop * Far;
_debug_symbol_Corners[7] = _debug_symbol_LeftBottom * Far;
_debug_symbol_XMVECTOR _debug_symbol_Normal = _debug_symbol_XMVector3Cross( _debug_symbol_V1 - _debug_symbol_V0, _debug_symbol_V2 - _debug_symbol_V0 );
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Normal, _debug_symbol_V0 );
_debug_symbol_XMVECTOR _debug_symbol_MinDist, _debug_symbol_MaxDist;
_debug_symbol_MinDist = _debug_symbol_MaxDist = _debug_symbol_XMVector3Dot( _debug_symbol_Corners[0], _debug_symbol_Normal );
for( INT i = 1; i < 8; i++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( _debug_symbol_Corners[i], _debug_symbol_Normal );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_Temp );
_debug_symbol_MaxDist = _debug_symbol_XMVectorMax( _debug_symbol_MaxDist, _debug_symbol_Temp );
}
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_XMVectorGreater( _debug_symbol_MinDist, _debug_symbol_Dist ), _debug_symbol_XMVectorLess( _debug_symbol_MaxDist, _debug_symbol_Dist ) );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
_debug_symbol_XMVECTOR _debug_symbol_TriangleEdgeAxis[3];
_debug_symbol_TriangleEdgeAxis[0] = _debug_symbol_V1 - _debug_symbol_V0;
_debug_symbol_TriangleEdgeAxis[1] = _debug_symbol_V2 - _debug_symbol_V1;
_debug_symbol_TriangleEdgeAxis[2] = _debug_symbol_V0 - _debug_symbol_V2;
_debug_symbol_XMVECTOR _debug_symbol_FrustumEdgeAxis[6];
_debug_symbol_FrustumEdgeAxis[0] = _debug_symbol_RightTop;
_debug_symbol_FrustumEdgeAxis[1] = _debug_symbol_RightBottom;
_debug_symbol_FrustumEdgeAxis[2] = _debug_symbol_LeftTop;
_debug_symbol_FrustumEdgeAxis[3] = _debug_symbol_LeftBottom;
_debug_symbol_FrustumEdgeAxis[4] = _debug_symbol_RightTop - _debug_symbol_LeftTop;
_debug_symbol_FrustumEdgeAxis[5] = _debug_symbol_LeftBottom - _debug_symbol_LeftTop;
for( INT i = 0; i < 3; i++ )
{
for( INT j = 0; j < 6; j++ )
{
_debug_symbol_XMVECTOR Axis = _debug_symbol_XMVector3Cross( _debug_symbol_TriangleEdgeAxis[i], _debug_symbol_FrustumEdgeAxis[j] );
_debug_symbol_XMVECTOR _debug_symbol_MinA, _debug_symbol_MaxA;
_debug_symbol_XMVECTOR _debug_symbol_Dist0 = _debug_symbol_XMVector3Dot( _debug_symbol_V0, Axis );
_debug_symbol_XMVECTOR _debug_symbol_Dist1 = _debug_symbol_XMVector3Dot( _debug_symbol_V1, Axis );
_debug_symbol_XMVECTOR _debug_symbol_Dist2 = _debug_symbol_XMVector3Dot( _debug_symbol_V2, Axis );
_debug_symbol_MinA = _debug_symbol_XMVectorMin( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MinA = _debug_symbol_XMVectorMin( _debug_symbol_MinA, _debug_symbol_Dist2 );
_debug_symbol_MaxA = _debug_symbol_XMVectorMax( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MaxA = _debug_symbol_XMVectorMax( _debug_symbol_MaxA, _debug_symbol_Dist2 );
_debug_symbol_XMVECTOR _debug_symbol_MinB, _debug_symbol_MaxB;
_debug_symbol_MinB = _debug_symbol_MaxB = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_Corners[0] );
for( INT _debug_symbol_k = 1; _debug_symbol_k < 8; _debug_symbol_k++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_Corners[_debug_symbol_k] );
_debug_symbol_MinB = _debug_symbol_XMVectorMin( _debug_symbol_MinB, _debug_symbol_Temp );
_debug_symbol_MaxB = _debug_symbol_XMVectorMax( _debug_symbol_MaxB, _debug_symbol_Temp );
}
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_MinA, _debug_symbol_MaxB ) );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_MinB, _debug_symbol_MaxA ) );
}
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
return 1;
}
INT _debug_symbol_IntersectSphereFrustum( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR Planes[6];
Planes[0] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, _debug_symbol_pVolumeB->_debug_symbol_Near );
Planes[1] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, -_debug_symbol_pVolumeB->Far );
Planes[2] = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolumeB->_debug_symbol_RightSlope, 0.0f );
Planes[3] = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, 0.0f );
Planes[4] = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolumeB->_debug_symbol_TopSlope, 0.0f );
Planes[5] = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 0.0f );
Planes[2] = _debug_symbol_XMVector3Normalize( Planes[2] );
Planes[3] = _debug_symbol_XMVector3Normalize( Planes[3] );
Planes[4] = _debug_symbol_XMVector3Normalize( Planes[4] );
Planes[5] = _debug_symbol_XMVector3Normalize( Planes[5] );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Radius );
Center = _debug_symbol_XMVector3InverseRotate( Center - _debug_symbol_Origin, _debug_symbol_Orientation );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_Outside = _debug_symbol_XMVectorFalseInt();
_debug_symbol_XMVECTOR _debug_symbol_InsideAll = _debug_symbol_XMVectorTrueInt();
_debug_symbol_XMVECTOR _debug_symbol_CenterInsideAll = _debug_symbol_XMVectorTrueInt();
_debug_symbol_XMVECTOR _debug_symbol_Dist[6];
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_Dist[i] = _debug_symbol_XMVector4Dot( Center, Planes[i] );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_Dist[i], _debug_symbol_Radius ) );
_debug_symbol_InsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_Dist[i], -_debug_symbol_Radius ) );
_debug_symbol_CenterInsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_CenterInsideAll, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_Dist[i], Zero ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 2;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_CenterInsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 1;
static const INT _debug_symbol_adjacent_faces[6][4] =
{
{ 2, 3, 4, 5 },
{ 2, 3, 4, 5 },
{ 0, 1, 4, 5 },
{ 0, 1, 4, 5 },
{ 0, 1, 2, 3 },
{ 0, 1, 2, 3 }
};
_debug_symbol_XMVECTOR _debug_symbol_Intersects = _debug_symbol_XMVectorFalseInt();
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR Point = Center - (Planes[i] * _debug_symbol_Dist[i]);
Point = _debug_symbol_XMVectorInsert( Point, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1 );
_debug_symbol_XMVECTOR _debug_symbol_InsideFace = _debug_symbol_XMVectorTrueInt();
for ( INT j = 0; j < 4; j++ )
{
INT _debug_symbol_plane_index = _debug_symbol_adjacent_faces[i][j];
_debug_symbol_InsideFace = _debug_symbol_XMVectorAndInt( _debug_symbol_InsideFace,
_debug_symbol_XMVectorLessOrEqual( _debug_symbol_XMVector4Dot( Point, Planes[_debug_symbol_plane_index] ), Zero ) );
}
_debug_symbol_Intersects = _debug_symbol_XMVectorOrInt( _debug_symbol_Intersects,
_debug_symbol_XMVectorAndInt( _debug_symbol_XMVectorGreater( _debug_symbol_Dist[i], Zero ), _debug_symbol_InsideFace ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Intersects, _debug_symbol_XMVectorTrueInt() ) )
return 1;
_debug_symbol_XMVECTOR _debug_symbol_RightTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Near = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->_debug_symbol_Near );
_debug_symbol_XMVECTOR Far = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->Far );
_debug_symbol_XMVECTOR _debug_symbol_Corners[8];
_debug_symbol_Corners[0] = _debug_symbol_RightTop * _debug_symbol_Near;
_debug_symbol_Corners[1] = _debug_symbol_RightBottom * _debug_symbol_Near;
_debug_symbol_Corners[2] = _debug_symbol_LeftTop * _debug_symbol_Near;
_debug_symbol_Corners[3] = _debug_symbol_LeftBottom * _debug_symbol_Near;
_debug_symbol_Corners[4] = _debug_symbol_RightTop * Far;
_debug_symbol_Corners[5] = _debug_symbol_RightBottom * Far;
_debug_symbol_Corners[6] = _debug_symbol_LeftTop * Far;
_debug_symbol_Corners[7] = _debug_symbol_LeftBottom * Far;
static const INT _debug_symbol_edges[12][2] =
{
{ 0, 1 }, { 2, 3 }, { 0, 2 }, { 1, 3 },
{ 4, 5 }, { 6, 7 }, { 4, 6 }, { 5, 7 },
{ 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 },
};
_debug_symbol_XMVECTOR _debug_symbol_RadiusSq = _debug_symbol_Radius * _debug_symbol_Radius;
for( INT i = 0; i < 12; i++ )
{
INT _debug_symbol_ei0 = _debug_symbol_edges[i][0];
INT _debug_symbol_ei1 = _debug_symbol_edges[i][1];
_debug_symbol_XMVECTOR Point = _debug_symbol_PointOnLineSegmentNearestPoint( _debug_symbol_Corners[_debug_symbol_ei0], _debug_symbol_Corners[_debug_symbol_ei1], Center );
_debug_symbol_XMVECTOR Delta = Center - Point;
_debug_symbol_XMVECTOR _debug_symbol_DistSq = _debug_symbol_XMVector3Dot( Delta, Delta );
_debug_symbol_Intersects = _debug_symbol_XMVectorOrInt( _debug_symbol_Intersects, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_DistSq, _debug_symbol_RadiusSq ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Intersects, _debug_symbol_XMVectorTrueInt() ) )
return 1;
return 0;
}
INT _debug_symbol_IntersectAxisAlignedBoxFrustum( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_OrientedBox _debug_symbol_BoxA;
_debug_symbol_BoxA.Center = _debug_symbol_pVolumeA->Center;
_debug_symbol_BoxA.Extents = _debug_symbol_pVolumeA->Extents;
_debug_symbol_BoxA._debug_symbol_Orientation.x = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation.y = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation._debug_symbol_z = 0.0f;
_debug_symbol_BoxA._debug_symbol_Orientation.w = 1.0f;
return _debug_symbol_IntersectOrientedBoxFrustum( &_debug_symbol_BoxA, _debug_symbol_pVolumeB );
}
INT _debug_symbol_IntersectOrientedBoxFrustum( const _debug_symbol_OrientedBox* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectY =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0
};
static const _debug_symbol_XMVECTORI32 _debug_symbol_SelectZ =
{
_debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_0, _debug_symbol_XM_SELECT_1, _debug_symbol_XM_SELECT_0
};
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR Planes[6];
Planes[0] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, _debug_symbol_pVolumeB->_debug_symbol_Near );
Planes[1] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, -_debug_symbol_pVolumeB->Far );
Planes[2] = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolumeB->_debug_symbol_RightSlope, 0.0f );
Planes[3] = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, 0.0f );
Planes[4] = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolumeB->_debug_symbol_TopSlope, 0.0f );
Planes[5] = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_FrustumOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_FrustumOrientation ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeA->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_BoxOrientation ) );
Center = _debug_symbol_XMVector3InverseRotate( Center - _debug_symbol_Origin, _debug_symbol_FrustumOrientation );
_debug_symbol_BoxOrientation = _debug_symbol_XMQuaternionMultiply( _debug_symbol_BoxOrientation, _debug_symbol_XMQuaternionConjugate( _debug_symbol_FrustumOrientation ) );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMMATRIX _debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( _debug_symbol_BoxOrientation );
_debug_symbol_XMVECTOR _debug_symbol_Outside = _debug_symbol_XMVectorFalseInt();
_debug_symbol_XMVECTOR _debug_symbol_InsideAll = _debug_symbol_XMVectorTrueInt();
_debug_symbol_XMVECTOR _debug_symbol_CenterInsideAll = _debug_symbol_XMVectorTrueInt();
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector4Dot( Center, Planes[i] );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVector3Dot( Planes[i], _debug_symbol_R._debug_symbol_r[0] );
_debug_symbol_Radius = _debug_symbol_XMVectorSelect( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( Planes[i], _debug_symbol_R._debug_symbol_r[1] ), _debug_symbol_SelectY );
_debug_symbol_Radius = _debug_symbol_XMVectorSelect( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( Planes[i], _debug_symbol_R._debug_symbol_r[2] ), _debug_symbol_SelectZ );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( _debug_symbol_Radius ) );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_Radius ) );
_debug_symbol_InsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_Dist, -_debug_symbol_Radius ) );
_debug_symbol_CenterInsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_CenterInsideAll, _debug_symbol_XMVectorLessOrEqual( _debug_symbol_Dist, Zero ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 2;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_CenterInsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 1;
_debug_symbol_XMVECTOR _debug_symbol_RightTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Near = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->_debug_symbol_Near );
_debug_symbol_XMVECTOR Far = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->Far );
_debug_symbol_XMVECTOR _debug_symbol_Corners[8];
_debug_symbol_Corners[0] = _debug_symbol_RightTop * _debug_symbol_Near;
_debug_symbol_Corners[1] = _debug_symbol_RightBottom * _debug_symbol_Near;
_debug_symbol_Corners[2] = _debug_symbol_LeftTop * _debug_symbol_Near;
_debug_symbol_Corners[3] = _debug_symbol_LeftBottom * _debug_symbol_Near;
_debug_symbol_Corners[4] = _debug_symbol_RightTop * Far;
_debug_symbol_Corners[5] = _debug_symbol_RightBottom * Far;
_debug_symbol_Corners[6] = _debug_symbol_LeftTop * Far;
_debug_symbol_Corners[7] = _debug_symbol_LeftBottom * Far;
{
_debug_symbol_XMVECTOR _debug_symbol_FrustumMin, _debug_symbol_FrustumMax;
_debug_symbol_FrustumMin = _debug_symbol_XMVector3Dot( _debug_symbol_Corners[0], _debug_symbol_R._debug_symbol_r[0] );
_debug_symbol_FrustumMin = _debug_symbol_XMVectorSelect( _debug_symbol_FrustumMin, _debug_symbol_XMVector3Dot( _debug_symbol_Corners[0], _debug_symbol_R._debug_symbol_r[1] ), _debug_symbol_SelectY );
_debug_symbol_FrustumMin = _debug_symbol_XMVectorSelect( _debug_symbol_FrustumMin, _debug_symbol_XMVector3Dot( _debug_symbol_Corners[0], _debug_symbol_R._debug_symbol_r[2] ), _debug_symbol_SelectZ );
_debug_symbol_FrustumMax = _debug_symbol_FrustumMin;
for( INT i = 1; i < 8; i++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( _debug_symbol_Corners[i], _debug_symbol_R._debug_symbol_r[0] );
_debug_symbol_Temp = _debug_symbol_XMVectorSelect( _debug_symbol_Temp, _debug_symbol_XMVector3Dot( _debug_symbol_Corners[i], _debug_symbol_R._debug_symbol_r[1] ), _debug_symbol_SelectY );
_debug_symbol_Temp = _debug_symbol_XMVectorSelect( _debug_symbol_Temp, _debug_symbol_XMVector3Dot( _debug_symbol_Corners[i], _debug_symbol_R._debug_symbol_r[2] ), _debug_symbol_SelectZ );
_debug_symbol_FrustumMin = _debug_symbol_XMVectorMin( _debug_symbol_FrustumMin, _debug_symbol_Temp );
_debug_symbol_FrustumMax = _debug_symbol_XMVectorMax( _debug_symbol_FrustumMax, _debug_symbol_Temp );
}
_debug_symbol_XMVECTOR _debug_symbol_BoxDist = _debug_symbol_XMVector3Dot( Center, _debug_symbol_R._debug_symbol_r[0] );
_debug_symbol_BoxDist = _debug_symbol_XMVectorSelect( _debug_symbol_BoxDist, _debug_symbol_XMVector3Dot( Center, _debug_symbol_R._debug_symbol_r[1] ), _debug_symbol_SelectY );
_debug_symbol_BoxDist = _debug_symbol_XMVectorSelect( _debug_symbol_BoxDist, _debug_symbol_XMVector3Dot( Center, _debug_symbol_R._debug_symbol_r[2] ), _debug_symbol_SelectZ );
_debug_symbol_XMVECTOR Result = _debug_symbol_XMVectorOrInt( _debug_symbol_XMVectorGreater( _debug_symbol_FrustumMin, _debug_symbol_BoxDist + Extents ),
_debug_symbol_XMVectorLess( _debug_symbol_FrustumMax, _debug_symbol_BoxDist - Extents ) );
if( _debug_symbol_XMVector3AnyTrue( Result ) )
return 0;
}
_debug_symbol_XMVECTOR _debug_symbol_FrustumEdgeAxis[6];
_debug_symbol_FrustumEdgeAxis[0] = _debug_symbol_RightTop;
_debug_symbol_FrustumEdgeAxis[1] = _debug_symbol_RightBottom;
_debug_symbol_FrustumEdgeAxis[2] = _debug_symbol_LeftTop;
_debug_symbol_FrustumEdgeAxis[3] = _debug_symbol_LeftBottom;
_debug_symbol_FrustumEdgeAxis[4] = _debug_symbol_RightTop - _debug_symbol_LeftTop;
_debug_symbol_FrustumEdgeAxis[5] = _debug_symbol_LeftBottom - _debug_symbol_LeftTop;
for( INT i = 0; i < 3; i++ )
{
for( INT j = 0; j < 6; j++ )
{
_debug_symbol_XMVECTOR Axis = _debug_symbol_XMVector3Cross( _debug_symbol_R._debug_symbol_r[i], _debug_symbol_FrustumEdgeAxis[j] );
_debug_symbol_XMVECTOR _debug_symbol_FrustumMin, _debug_symbol_FrustumMax;
_debug_symbol_FrustumMin = _debug_symbol_FrustumMax = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_Corners[0] );
for( INT _debug_symbol_k = 1; _debug_symbol_k < 8; _debug_symbol_k++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_Corners[_debug_symbol_k] );
_debug_symbol_FrustumMin = _debug_symbol_XMVectorMin( _debug_symbol_FrustumMin, _debug_symbol_Temp );
_debug_symbol_FrustumMax = _debug_symbol_XMVectorMax( _debug_symbol_FrustumMax, _debug_symbol_Temp );
}
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector3Dot( Center, Axis );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_R._debug_symbol_r[0] );
_debug_symbol_Radius = _debug_symbol_XMVectorSelect( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( Axis, _debug_symbol_R._debug_symbol_r[1] ), _debug_symbol_SelectY );
_debug_symbol_Radius = _debug_symbol_XMVectorSelect( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( Axis, _debug_symbol_R._debug_symbol_r[2] ), _debug_symbol_SelectZ );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( _debug_symbol_Radius ) );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_FrustumMax + _debug_symbol_Radius ) );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorLess( _debug_symbol_Dist, _debug_symbol_FrustumMin - _debug_symbol_Radius ) );
}
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
return 1;
}
INT _debug_symbol_IntersectFrustumFrustum( const _debug_symbol_Frustum* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolumeA );
_debug_symbol_XMASSERT( _debug_symbol_pVolumeB );
_debug_symbol_XMVECTOR _debug_symbol_OriginB = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeB->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_OrientationB = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeB->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_OrientationB ) );
_debug_symbol_XMVECTOR _debug_symbol_AxisB[6];
_debug_symbol_AxisB[0] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, 0.0f );
_debug_symbol_AxisB[1] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, 0.0f );
_debug_symbol_AxisB[2] = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolumeB->_debug_symbol_RightSlope, 0.0f );
_debug_symbol_AxisB[3] = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, 0.0f );
_debug_symbol_AxisB[4] = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolumeB->_debug_symbol_TopSlope, 0.0f );
_debug_symbol_AxisB[5] = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_PlaneDistB[6];
_debug_symbol_PlaneDistB[0] = -_debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->_debug_symbol_Near );
_debug_symbol_PlaneDistB[1] = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->Far );
_debug_symbol_PlaneDistB[2] = _debug_symbol_XMVectorZero();
_debug_symbol_PlaneDistB[3] = _debug_symbol_XMVectorZero();
_debug_symbol_PlaneDistB[4] = _debug_symbol_XMVectorZero();
_debug_symbol_PlaneDistB[5] = _debug_symbol_XMVectorZero();
_debug_symbol_XMVECTOR _debug_symbol_OriginA = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolumeA->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_OrientationA = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolumeA->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_OrientationA ) );
_debug_symbol_OriginA = _debug_symbol_XMVector3InverseRotate( _debug_symbol_OriginA - _debug_symbol_OriginB, _debug_symbol_OrientationB );
_debug_symbol_OrientationA = _debug_symbol_XMQuaternionMultiply( _debug_symbol_OrientationA, _debug_symbol_XMQuaternionConjugate( _debug_symbol_OrientationB ) );
_debug_symbol_XMVECTOR _debug_symbol_RightTopA = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeA->_debug_symbol_RightSlope, _debug_symbol_pVolumeA->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottomA = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeA->_debug_symbol_RightSlope, _debug_symbol_pVolumeA->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTopA = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeA->_debug_symbol_LeftSlope, _debug_symbol_pVolumeA->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottomA = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeA->_debug_symbol_LeftSlope, _debug_symbol_pVolumeA->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_NearA = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->_debug_symbol_Near );
_debug_symbol_XMVECTOR _debug_symbol_FarA = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeA->Far );
_debug_symbol_RightTopA = _debug_symbol_XMVector3Rotate( _debug_symbol_RightTopA, _debug_symbol_OrientationA );
_debug_symbol_RightBottomA = _debug_symbol_XMVector3Rotate( _debug_symbol_RightBottomA, _debug_symbol_OrientationA );
_debug_symbol_LeftTopA = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftTopA, _debug_symbol_OrientationA );
_debug_symbol_LeftBottomA = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftBottomA, _debug_symbol_OrientationA );
_debug_symbol_XMVECTOR _debug_symbol_CornersA[8];
_debug_symbol_CornersA[0] = _debug_symbol_OriginA + _debug_symbol_RightTopA * _debug_symbol_NearA;
_debug_symbol_CornersA[1] = _debug_symbol_OriginA + _debug_symbol_RightBottomA * _debug_symbol_NearA;
_debug_symbol_CornersA[2] = _debug_symbol_OriginA + _debug_symbol_LeftTopA * _debug_symbol_NearA;
_debug_symbol_CornersA[3] = _debug_symbol_OriginA + _debug_symbol_LeftBottomA * _debug_symbol_NearA;
_debug_symbol_CornersA[4] = _debug_symbol_OriginA + _debug_symbol_RightTopA * _debug_symbol_FarA;
_debug_symbol_CornersA[5] = _debug_symbol_OriginA + _debug_symbol_RightBottomA * _debug_symbol_FarA;
_debug_symbol_CornersA[6] = _debug_symbol_OriginA + _debug_symbol_LeftTopA * _debug_symbol_FarA;
_debug_symbol_CornersA[7] = _debug_symbol_OriginA + _debug_symbol_LeftBottomA * _debug_symbol_FarA;
_debug_symbol_XMVECTOR _debug_symbol_Outside = _debug_symbol_XMVectorFalseInt();
_debug_symbol_XMVECTOR _debug_symbol_InsideAll = _debug_symbol_XMVectorTrueInt();
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR Min, Max;
Min = Max = _debug_symbol_XMVector3Dot( _debug_symbol_AxisB[i], _debug_symbol_CornersA[0] );
for( INT j = 1; j < 8; j++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( _debug_symbol_AxisB[i], _debug_symbol_CornersA[j] );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Temp );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Temp );
}
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( Min, _debug_symbol_PlaneDistB[i] ) );
_debug_symbol_InsideAll = _debug_symbol_XMVectorAndInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorLessOrEqual( Max, _debug_symbol_PlaneDistB[i] ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_InsideAll, _debug_symbol_XMVectorTrueInt() ) )
return 2;
_debug_symbol_XMVECTOR _debug_symbol_RightTopB = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottomB = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_RightSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTopB = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottomB = _debug_symbol_XMVectorSet( _debug_symbol_pVolumeB->_debug_symbol_LeftSlope, _debug_symbol_pVolumeB->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_NearB = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->_debug_symbol_Near );
_debug_symbol_XMVECTOR _debug_symbol_FarB = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolumeB->Far );
_debug_symbol_XMVECTOR _debug_symbol_CornersB[8];
_debug_symbol_CornersB[0] = _debug_symbol_RightTopB * _debug_symbol_NearB;
_debug_symbol_CornersB[1] = _debug_symbol_RightBottomB * _debug_symbol_NearB;
_debug_symbol_CornersB[2] = _debug_symbol_LeftTopB * _debug_symbol_NearB;
_debug_symbol_CornersB[3] = _debug_symbol_LeftBottomB * _debug_symbol_NearB;
_debug_symbol_CornersB[4] = _debug_symbol_RightTopB * _debug_symbol_FarB;
_debug_symbol_CornersB[5] = _debug_symbol_RightBottomB * _debug_symbol_FarB;
_debug_symbol_CornersB[6] = _debug_symbol_LeftTopB * _debug_symbol_FarB;
_debug_symbol_CornersB[7] = _debug_symbol_LeftBottomB * _debug_symbol_FarB;
_debug_symbol_XMVECTOR _debug_symbol_AxisA[6];
_debug_symbol_XMVECTOR _debug_symbol_PlaneDistA[6];
_debug_symbol_AxisA[0] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, -1.0f, 0.0f );
_debug_symbol_AxisA[1] = _debug_symbol_XMVectorSet( 0.0f, 0.0f, 1.0f, 0.0f );
_debug_symbol_AxisA[2] = _debug_symbol_XMVectorSet( 1.0f, 0.0f, -_debug_symbol_pVolumeA->_debug_symbol_RightSlope, 0.0f );
_debug_symbol_AxisA[3] = _debug_symbol_XMVectorSet( -1.0f, 0.0f, _debug_symbol_pVolumeA->_debug_symbol_LeftSlope, 0.0f );
_debug_symbol_AxisA[4] = _debug_symbol_XMVectorSet( 0.0f, 1.0f, -_debug_symbol_pVolumeA->_debug_symbol_TopSlope, 0.0f );
_debug_symbol_AxisA[5] = _debug_symbol_XMVectorSet( 0.0f, -1.0f, _debug_symbol_pVolumeA->_debug_symbol_BottomSlope, 0.0f );
_debug_symbol_AxisA[0] = _debug_symbol_XMVector3Rotate( _debug_symbol_AxisA[0], _debug_symbol_OrientationA );
_debug_symbol_AxisA[1] = -_debug_symbol_AxisA[0];
_debug_symbol_AxisA[2] = _debug_symbol_XMVector3Rotate( _debug_symbol_AxisA[2], _debug_symbol_OrientationA );
_debug_symbol_AxisA[3] = _debug_symbol_XMVector3Rotate( _debug_symbol_AxisA[3], _debug_symbol_OrientationA );
_debug_symbol_AxisA[4] = _debug_symbol_XMVector3Rotate( _debug_symbol_AxisA[4], _debug_symbol_OrientationA );
_debug_symbol_AxisA[5] = _debug_symbol_XMVector3Rotate( _debug_symbol_AxisA[5], _debug_symbol_OrientationA );
_debug_symbol_PlaneDistA[0] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[0], _debug_symbol_CornersA[0] );
_debug_symbol_PlaneDistA[1] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[1], _debug_symbol_CornersA[4] );
_debug_symbol_PlaneDistA[2] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[2], _debug_symbol_OriginA );
_debug_symbol_PlaneDistA[3] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[3], _debug_symbol_OriginA );
_debug_symbol_PlaneDistA[4] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[4], _debug_symbol_OriginA );
_debug_symbol_PlaneDistA[5] = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[5], _debug_symbol_OriginA );
for( INT i = 0; i < 6; i++ )
{
_debug_symbol_XMVECTOR Min;
Min = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[i], _debug_symbol_CornersB[0] );
for( INT j = 1; j < 8; j++ )
{
_debug_symbol_XMVECTOR _debug_symbol_Temp = _debug_symbol_XMVector3Dot( _debug_symbol_AxisA[i], _debug_symbol_CornersB[j] );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Temp );
}
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( Min, _debug_symbol_PlaneDistA[i] ) );
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
_debug_symbol_XMVECTOR _debug_symbol_FrustumEdgeAxisA[6];
_debug_symbol_FrustumEdgeAxisA[0] = _debug_symbol_RightTopA;
_debug_symbol_FrustumEdgeAxisA[1] = _debug_symbol_RightBottomA;
_debug_symbol_FrustumEdgeAxisA[2] = _debug_symbol_LeftTopA;
_debug_symbol_FrustumEdgeAxisA[3] = _debug_symbol_LeftBottomA;
_debug_symbol_FrustumEdgeAxisA[4] = _debug_symbol_RightTopA - _debug_symbol_LeftTopA;
_debug_symbol_FrustumEdgeAxisA[5] = _debug_symbol_LeftBottomA - _debug_symbol_LeftTopA;
_debug_symbol_XMVECTOR _debug_symbol_FrustumEdgeAxisB[6];
_debug_symbol_FrustumEdgeAxisB[0] = _debug_symbol_RightTopB;
_debug_symbol_FrustumEdgeAxisB[1] = _debug_symbol_RightBottomB;
_debug_symbol_FrustumEdgeAxisB[2] = _debug_symbol_LeftTopB;
_debug_symbol_FrustumEdgeAxisB[3] = _debug_symbol_LeftBottomB;
_debug_symbol_FrustumEdgeAxisB[4] = _debug_symbol_RightTopB - _debug_symbol_LeftTopB;
_debug_symbol_FrustumEdgeAxisB[5] = _debug_symbol_LeftBottomB - _debug_symbol_LeftTopB;
for( INT i = 0; i < 6; i++ )
{
for( INT j = 0; j < 6; j++ )
{
_debug_symbol_XMVECTOR Axis = _debug_symbol_XMVector3Cross( _debug_symbol_FrustumEdgeAxisA[i], _debug_symbol_FrustumEdgeAxisB[j] );
_debug_symbol_XMVECTOR _debug_symbol_MinA, _debug_symbol_MaxA;
_debug_symbol_XMVECTOR _debug_symbol_MinB, _debug_symbol_MaxB;
_debug_symbol_MinA = _debug_symbol_MaxA = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_CornersA[0] );
_debug_symbol_MinB = _debug_symbol_MaxB = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_CornersB[0] );
for( INT _debug_symbol_k = 1; _debug_symbol_k < 8; _debug_symbol_k++ )
{
_debug_symbol_XMVECTOR _debug_symbol_TempA = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_CornersA[_debug_symbol_k] );
_debug_symbol_MinA = _debug_symbol_XMVectorMin( _debug_symbol_MinA, _debug_symbol_TempA );
_debug_symbol_MaxA = _debug_symbol_XMVectorMax( _debug_symbol_MaxA, _debug_symbol_TempA );
_debug_symbol_XMVECTOR _debug_symbol_TempB = _debug_symbol_XMVector3Dot( Axis, _debug_symbol_CornersB[_debug_symbol_k] );
_debug_symbol_MinB = _debug_symbol_XMVectorMin( _debug_symbol_MinB, _debug_symbol_TempB );
_debug_symbol_MaxB = _debug_symbol_XMVectorMax( _debug_symbol_MaxB, _debug_symbol_TempB );
}
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_MinA, _debug_symbol_MaxB ) );
_debug_symbol_Outside = _debug_symbol_XMVectorOrInt( _debug_symbol_Outside, _debug_symbol_XMVectorGreater( _debug_symbol_MinB, _debug_symbol_MaxA ) );
}
}
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
return 1;
}
static inline void _debug_symbol_FastIntersectTrianglePlane( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, _debug_symbol_CXMVECTOR _debug_symbol_Plane,
_debug_symbol_XMVECTOR& _debug_symbol_Outside, _debug_symbol_XMVECTOR& _debug_symbol_Inside )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist0 = _debug_symbol_XMVector4Dot( _debug_symbol_V0, _debug_symbol_Plane );
_debug_symbol_XMVECTOR _debug_symbol_Dist1 = _debug_symbol_XMVector4Dot( _debug_symbol_V1, _debug_symbol_Plane );
_debug_symbol_XMVECTOR _debug_symbol_Dist2 = _debug_symbol_XMVector4Dot( _debug_symbol_V2, _debug_symbol_Plane );
_debug_symbol_XMVECTOR _debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MinDist = _debug_symbol_XMVectorMin( _debug_symbol_MinDist, _debug_symbol_Dist2 );
_debug_symbol_XMVECTOR _debug_symbol_MaxDist = _debug_symbol_XMVectorMax( _debug_symbol_Dist0, _debug_symbol_Dist1 );
_debug_symbol_MaxDist = _debug_symbol_XMVectorMax( _debug_symbol_MaxDist, _debug_symbol_Dist2 );
_debug_symbol_XMVECTOR Zero = _debug_symbol_XMVectorZero();
_debug_symbol_Outside = _debug_symbol_XMVectorGreater( _debug_symbol_MinDist, Zero );
_debug_symbol_Inside = _debug_symbol_XMVectorLess( _debug_symbol_MaxDist, Zero );
}
INT _debug_symbol_IntersectTriangle6Planes( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, _debug_symbol_CXMVECTOR _debug_symbol_Plane0, _debug_symbol_CXMVECTOR _debug_symbol_Plane1,
_debug_symbol_CXMVECTOR _debug_symbol_Plane2, _debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 )
{
_debug_symbol_XMVECTOR _debug_symbol_One = _debug_symbol_XMVectorSplatOne();
_debug_symbol_XMVECTOR _debug_symbol_TV0 = _debug_symbol_XMVectorInsert(_debug_symbol_V0, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_TV1 = _debug_symbol_XMVectorInsert(_debug_symbol_V1, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_TV2 = _debug_symbol_XMVectorInsert(_debug_symbol_V2, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane0, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_XMVECTOR _debug_symbol_AnyOutside = _debug_symbol_Outside;
_debug_symbol_XMVECTOR _debug_symbol_AllInside = _debug_symbol_Inside;
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane1, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane2, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane3, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane4, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane5, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AnyOutside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AllInside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
static inline void _debug_symbol_FastIntersectSpherePlane( _debug_symbol_FXMVECTOR Center, _debug_symbol_FXMVECTOR _debug_symbol_Radius, _debug_symbol_FXMVECTOR _debug_symbol_Plane,
_debug_symbol_XMVECTOR& _debug_symbol_Outside, _debug_symbol_XMVECTOR& _debug_symbol_Inside )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector4Dot( Center, _debug_symbol_Plane );
_debug_symbol_Outside = _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_Radius );
_debug_symbol_Inside = _debug_symbol_XMVectorLess( _debug_symbol_Dist, -_debug_symbol_Radius );
}
INT _debug_symbol_IntersectSphere6Planes( const _debug_symbol_Sphere* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Radius );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane0, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_XMVECTOR _debug_symbol_AnyOutside = _debug_symbol_Outside;
_debug_symbol_XMVECTOR _debug_symbol_AllInside = _debug_symbol_Inside;
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane1, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane2, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane3, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane4, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane5, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AnyOutside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AllInside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
static inline void _debug_symbol_FastIntersectAxisAlignedBoxPlane( _debug_symbol_FXMVECTOR Center, _debug_symbol_FXMVECTOR Extents, _debug_symbol_FXMVECTOR _debug_symbol_Plane,
_debug_symbol_XMVECTOR& _debug_symbol_Outside, _debug_symbol_XMVECTOR& _debug_symbol_Inside )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector4Dot( Center, _debug_symbol_Plane );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( _debug_symbol_Plane ) );
_debug_symbol_Outside = _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_Radius );
_debug_symbol_Inside = _debug_symbol_XMVectorLess( _debug_symbol_Dist, -_debug_symbol_Radius );
}
INT _debug_symbol_IntersectAxisAlignedBox6Planes( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1,
_debug_symbol_FXMVECTOR _debug_symbol_Plane2, _debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1 );
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane0, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_XMVECTOR _debug_symbol_AnyOutside = _debug_symbol_Outside;
_debug_symbol_XMVECTOR _debug_symbol_AllInside = _debug_symbol_Inside;
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane1, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane2, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane3, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane4, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane5, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AnyOutside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AllInside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
static inline void _debug_symbol_FastIntersectOrientedBoxPlane( _debug_symbol_FXMVECTOR Center, _debug_symbol_FXMVECTOR Extents, _debug_symbol_FXMVECTOR _debug_symbol_Axis0, _debug_symbol_CXMVECTOR _debug_symbol_Axis1,
_debug_symbol_CXMVECTOR _debug_symbol_Axis2, _debug_symbol_CXMVECTOR _debug_symbol_Plane, _debug_symbol_XMVECTOR& _debug_symbol_Outside, _debug_symbol_XMVECTOR& _debug_symbol_Inside )
{
_debug_symbol_XMVECTOR _debug_symbol_Dist = _debug_symbol_XMVector4Dot( Center, _debug_symbol_Plane );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Axis0 );
_debug_symbol_Radius = _debug_symbol_XMVectorInsert( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Axis1 ), 0, 0, 1, 0, 0 );
_debug_symbol_Radius = _debug_symbol_XMVectorInsert( _debug_symbol_Radius, _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Axis2 ), 0, 0, 0, 1, 0 );
_debug_symbol_Radius = _debug_symbol_XMVector3Dot( Extents, _debug_symbol_XMVectorAbs( _debug_symbol_Radius ) );
_debug_symbol_Outside = _debug_symbol_XMVectorGreater( _debug_symbol_Dist, _debug_symbol_Radius );
_debug_symbol_Inside = _debug_symbol_XMVectorLess( _debug_symbol_Dist, -_debug_symbol_Radius );
}
INT _debug_symbol_IntersectOrientedBox6Planes( const _debug_symbol_OrientedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_BoxOrientation ) );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1 );
_debug_symbol_XMMATRIX _debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( _debug_symbol_BoxOrientation );
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane0, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_XMVECTOR _debug_symbol_AnyOutside = _debug_symbol_Outside;
_debug_symbol_XMVECTOR _debug_symbol_AllInside = _debug_symbol_Inside;
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane1, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane2, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane3, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane4, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane5, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AnyOutside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AllInside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
static inline void _debug_symbol_FastIntersectFrustumPlane( _debug_symbol_FXMVECTOR _debug_symbol_Point0, _debug_symbol_FXMVECTOR _debug_symbol_Point1, _debug_symbol_FXMVECTOR _debug_symbol_Point2, _debug_symbol_CXMVECTOR _debug_symbol_Point3,
_debug_symbol_CXMVECTOR _debug_symbol_Point4, _debug_symbol_CXMVECTOR _debug_symbol_Point5, _debug_symbol_CXMVECTOR _debug_symbol_Point6, _debug_symbol_CXMVECTOR _debug_symbol_Point7,
_debug_symbol_CXMVECTOR _debug_symbol_Plane, _debug_symbol_XMVECTOR& _debug_symbol_Outside, _debug_symbol_XMVECTOR& _debug_symbol_Inside )
{
_debug_symbol_XMVECTOR Min, Max, _debug_symbol_Dist;
Min = Max = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point0 );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point1 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point2 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point3 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point4 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point5 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point6 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_Dist = _debug_symbol_XMVector3Dot( _debug_symbol_Plane, _debug_symbol_Point7 );
Min = _debug_symbol_XMVectorMin( Min, _debug_symbol_Dist );
Max = _debug_symbol_XMVectorMax( Max, _debug_symbol_Dist );
_debug_symbol_XMVECTOR _debug_symbol_PlaneDist = -_debug_symbol_XMVectorSplatW( _debug_symbol_Plane );
_debug_symbol_Outside = _debug_symbol_XMVectorGreater( Min, _debug_symbol_PlaneDist );
_debug_symbol_Inside = _debug_symbol_XMVectorLess( Max, _debug_symbol_PlaneDist );
}
INT _debug_symbol_IntersectFrustum6Planes( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_Origin = _debug_symbol_XMVectorInsert( _debug_symbol_Origin, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1 );
_debug_symbol_XMVECTOR _debug_symbol_RightTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Near = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_Near, _debug_symbol_pVolume->_debug_symbol_Near, _debug_symbol_pVolume->_debug_symbol_Near, 0.0f );
_debug_symbol_XMVECTOR Far = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->Far, _debug_symbol_pVolume->Far, _debug_symbol_pVolume->Far, 0.0f );
_debug_symbol_RightTop = _debug_symbol_XMVector3Rotate( _debug_symbol_RightTop, _debug_symbol_Orientation );
_debug_symbol_RightBottom = _debug_symbol_XMVector3Rotate( _debug_symbol_RightBottom, _debug_symbol_Orientation );
_debug_symbol_LeftTop = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftTop, _debug_symbol_Orientation );
_debug_symbol_LeftBottom = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftBottom, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_Corners0 = _debug_symbol_Origin + _debug_symbol_RightTop * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners1 = _debug_symbol_Origin + _debug_symbol_RightBottom * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners2 = _debug_symbol_Origin + _debug_symbol_LeftTop * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners3 = _debug_symbol_Origin + _debug_symbol_LeftBottom * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners4 = _debug_symbol_Origin + _debug_symbol_RightTop * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners5 = _debug_symbol_Origin + _debug_symbol_RightBottom * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners6 = _debug_symbol_Origin + _debug_symbol_LeftTop * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners7 = _debug_symbol_Origin + _debug_symbol_LeftBottom * Far;
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane0, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_XMVECTOR _debug_symbol_AnyOutside = _debug_symbol_Outside;
_debug_symbol_XMVECTOR _debug_symbol_AllInside = _debug_symbol_Inside;
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane1, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane2, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane3, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane4, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane5, _debug_symbol_Outside, _debug_symbol_Inside );
_debug_symbol_AnyOutside = _debug_symbol_XMVectorOrInt( _debug_symbol_AnyOutside, _debug_symbol_Outside );
_debug_symbol_AllInside = _debug_symbol_XMVectorAndInt( _debug_symbol_AllInside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AnyOutside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_AllInside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
INT _debug_symbol_IntersectTrianglePlane( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, _debug_symbol_CXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMVECTOR _debug_symbol_One = _debug_symbol_XMVectorSplatOne();
_debug_symbol_XMASSERT( _debug_symbol_XMPlaneIsUnit( _debug_symbol_Plane ) );
_debug_symbol_XMVECTOR _debug_symbol_TV0 = _debug_symbol_XMVectorInsert(_debug_symbol_V0, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_TV1 = _debug_symbol_XMVectorInsert(_debug_symbol_V1, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_TV2 = _debug_symbol_XMVectorInsert(_debug_symbol_V2, _debug_symbol_One, 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectTrianglePlane( _debug_symbol_TV0, _debug_symbol_TV1, _debug_symbol_TV2, _debug_symbol_Plane, _debug_symbol_Outside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Inside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
INT _debug_symbol_IntersectSpherePlane( const _debug_symbol_Sphere* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_XMPlaneIsUnit( _debug_symbol_Plane ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR _debug_symbol_Radius = _debug_symbol_XMVectorReplicatePtr( &_debug_symbol_pVolume->_debug_symbol_Radius );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1 );
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectSpherePlane( Center, _debug_symbol_Radius, _debug_symbol_Plane, _debug_symbol_Outside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Inside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
INT _debug_symbol_IntersectAxisAlignedBoxPlane( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_XMPlaneIsUnit( _debug_symbol_Plane ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectAxisAlignedBoxPlane( Center, Extents, _debug_symbol_Plane, _debug_symbol_Outside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Inside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
INT _debug_symbol_IntersectOrientedBoxPlane( const _debug_symbol_OrientedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_XMPlaneIsUnit( _debug_symbol_Plane ) );
_debug_symbol_XMVECTOR Center = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Center );
_debug_symbol_XMVECTOR Extents = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->Extents );
_debug_symbol_XMVECTOR _debug_symbol_BoxOrientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_BoxOrientation ) );
Center = _debug_symbol_XMVectorInsert( Center, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMMATRIX _debug_symbol_R = _debug_symbol_XMMatrixRotationQuaternion( _debug_symbol_BoxOrientation );
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectOrientedBoxPlane( Center, Extents, _debug_symbol_R._debug_symbol_r[0], _debug_symbol_R._debug_symbol_r[1], _debug_symbol_R._debug_symbol_r[2], _debug_symbol_Plane, _debug_symbol_Outside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Inside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
INT _debug_symbol_IntersectFrustumPlane( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane )
{
_debug_symbol_XMASSERT( _debug_symbol_pVolume );
_debug_symbol_XMASSERT( _debug_symbol_XMPlaneIsUnit( _debug_symbol_Plane ) );
_debug_symbol_XMVECTOR _debug_symbol_Origin = _debug_symbol_XMLoadFloat3( &_debug_symbol_pVolume->_debug_symbol_Origin );
_debug_symbol_XMVECTOR _debug_symbol_Orientation = _debug_symbol_XMLoadFloat4( &_debug_symbol_pVolume->_debug_symbol_Orientation );
_debug_symbol_XMASSERT( _debug_symbol_XMQuaternionIsUnit( _debug_symbol_Orientation ) );
_debug_symbol_Origin = _debug_symbol_XMVectorInsert( _debug_symbol_Origin, _debug_symbol_XMVectorSplatOne(), 0, 0, 0, 0, 1);
_debug_symbol_XMVECTOR _debug_symbol_RightTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_RightBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_RightSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftTop = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_TopSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_LeftBottom = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_LeftSlope, _debug_symbol_pVolume->_debug_symbol_BottomSlope, 1.0f, 0.0f );
_debug_symbol_XMVECTOR _debug_symbol_Near = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->_debug_symbol_Near, _debug_symbol_pVolume->_debug_symbol_Near, _debug_symbol_pVolume->_debug_symbol_Near, 0.0f );
_debug_symbol_XMVECTOR Far = _debug_symbol_XMVectorSet( _debug_symbol_pVolume->Far, _debug_symbol_pVolume->Far, _debug_symbol_pVolume->Far, 0.0f );
_debug_symbol_RightTop = _debug_symbol_XMVector3Rotate( _debug_symbol_RightTop, _debug_symbol_Orientation );
_debug_symbol_RightBottom = _debug_symbol_XMVector3Rotate( _debug_symbol_RightBottom, _debug_symbol_Orientation );
_debug_symbol_LeftTop = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftTop, _debug_symbol_Orientation );
_debug_symbol_LeftBottom = _debug_symbol_XMVector3Rotate( _debug_symbol_LeftBottom, _debug_symbol_Orientation );
_debug_symbol_XMVECTOR _debug_symbol_Corners0 = _debug_symbol_Origin + _debug_symbol_RightTop * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners1 = _debug_symbol_Origin + _debug_symbol_RightBottom * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners2 = _debug_symbol_Origin + _debug_symbol_LeftTop * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners3 = _debug_symbol_Origin + _debug_symbol_LeftBottom * _debug_symbol_Near;
_debug_symbol_XMVECTOR _debug_symbol_Corners4 = _debug_symbol_Origin + _debug_symbol_RightTop * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners5 = _debug_symbol_Origin + _debug_symbol_RightBottom * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners6 = _debug_symbol_Origin + _debug_symbol_LeftTop * Far;
_debug_symbol_XMVECTOR _debug_symbol_Corners7 = _debug_symbol_Origin + _debug_symbol_LeftBottom * Far;
_debug_symbol_XMVECTOR _debug_symbol_Outside, _debug_symbol_Inside;
_debug_symbol_FastIntersectFrustumPlane( _debug_symbol_Corners0, _debug_symbol_Corners1, _debug_symbol_Corners2, _debug_symbol_Corners3,
_debug_symbol_Corners4, _debug_symbol_Corners5, _debug_symbol_Corners6, _debug_symbol_Corners7,
_debug_symbol_Plane, _debug_symbol_Outside, _debug_symbol_Inside );
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Outside, _debug_symbol_XMVectorTrueInt() ) )
return 0;
if ( _debug_symbol_XMVector4EqualInt( _debug_symbol_Inside, _debug_symbol_XMVectorTrueInt() ) )
return 2;
return 1;
}
};

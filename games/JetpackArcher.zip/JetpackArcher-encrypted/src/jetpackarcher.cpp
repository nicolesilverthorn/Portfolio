#include "jetpackarcher.h"
#include "game.h"
#include "splash.h"
#include "mainmenu.h"
#include "credits.h"
#include "gameover.h"
#include "gamewon.h"
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE _debug_symbol_prevInstance, PSTR _debug_symbol_cmdLine, int showCmd)
{
#if defined(DEBUG) | defined(_DEBUG)
_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
_debug_symbol_JetpackArcher _debug_symbol_theApp(hInstance);
if (!_debug_symbol_theApp.Init())
return 0;
return _debug_symbol_theApp.Run();
}
_debug_symbol_JetpackArcher::_debug_symbol_JetpackArcher(HINSTANCE hInstance) :
_debug_symbol_D3DApp(hInstance), _debug_symbol_mLitTexEffect(0), _debug_symbol_mMouseReleased(true), _debug_symbol_mCurrState(_debug_symbol_SPLASH)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_XMVectorSet(1.0f, 1.0f, 5.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
_debug_symbol_mMainWndCaption =  decrypt::_debug_symbol_dec_debug(_T( "_debug_Jetpack Archer"));
_debug_symbol_mLastMousePos.x = 0;
_debug_symbol_mLastMousePos.y = 0;
_debug_symbol_XMMATRIX _debug_symbol_I = _debug_symbol_XMMatrixIdentity();
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mView, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mProj, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_I);
srand((UINT)time(NULL));
_debug_symbol_mainMenu = 0;
_debug_symbol_game = 0;
_debug_symbol_credits = 0;
_debug_symbol_splash = 0;
_debug_symbol_gameOver = 0;
_debug_symbol_gameWon = 0;
}
_debug_symbol_JetpackArcher::~_debug_symbol_JetpackArcher()
{
Vertex::_debug_symbol_CleanLayouts();
if(_debug_symbol_mLitTexEffect)
delete _debug_symbol_mLitTexEffect;
}
_debug_symbol_FMOD_RESULT result;
_debug_symbol_FMOD::System     *_debug_symbol_sys;
_debug_symbol_FMOD::_debug_symbol_Sound      *_debug_symbol_sound1, *_debug_symbol_sound2, *_debug_symbol_sound3;
_debug_symbol_FMOD::Channel    *channel = 0;
_debug_symbol_FMOD::Channel  *_debug_symbol_channel2 = 0;
unsigned int      version;
void             *_debug_symbol_extradriverdata = 0;
void _debug_symbol_JetpackArcher::_debug_symbol_BuildSceneLights()
{
_debug_symbol_mPointLight.pos = _debug_symbol_XMFLOAT3(50.0f, 50.0f, 50.0f);
_debug_symbol_mPointLight._debug_symbol_lightColour = _debug_symbol_XMFLOAT4(0.75f, 0.75f, 0.75f, 1.0f);
_debug_symbol_mPointLight.range = 1000.0f;
_debug_symbol_mPointLight._debug_symbol_att = _debug_symbol_XMFLOAT3(0.0f, 0.02f, 0.0f);
_debug_symbol_mPointLight.pad = 0.0f;
_debug_symbol_mSpotLight.pos = _debug_symbol_XMFLOAT3(_debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[2]);
_debug_symbol_mSpotLight._debug_symbol_lightColour = _debug_symbol_XMFLOAT4(0.75f, 0.75f, 0.75f, 1.0f);
_debug_symbol_mSpotLight.range = 100.0f;
_debug_symbol_mSpotLight._debug_symbol_att = _debug_symbol_XMFLOAT3(0.0f, 0.25f, 0.0f);
_debug_symbol_XMVECTOR temp = _debug_symbol_XMVectorSet(-_debug_symbol_mSpotLight.pos.x, -_debug_symbol_mSpotLight.pos.y, -_debug_symbol_mSpotLight.pos._debug_symbol_z, 0.0f);
temp = _debug_symbol_XMVector3Normalize(temp);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mSpotLight._debug_symbol_direction, temp);
_debug_symbol_mSpotLight._debug_symbol_spot = 128.0f;
_debug_symbol_mAmbientColour = _debug_symbol_XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
}
bool _debug_symbol_JetpackArcher::Init()
{
if (!_debug_symbol_D3DApp::Init())
return false;
result = _debug_symbol_FMOD::_debug_symbol_System_Create(&_debug_symbol_sys);
result = _debug_symbol_sys->_debug_symbol_getVersion(&version);
if (version < _debug_symbol_FMOD_VERSION)
{
OutputDebugString( decrypt::_debug_symbol_dec_debug(_T( "_debug_FMOD lib version doesn't match header version")));
}
result = _debug_symbol_sys->init(32, _debug_symbol_FMOD_INIT_NORMAL, _debug_symbol_extradriverdata);
result = _debug_symbol_sys->_debug_symbol_createSound( decrypt::_debug_symbol_dec_debug(_T( "_debug_Sounds/choo.ogg")), _debug_symbol_FMOD_DEFAULT, 0, &_debug_symbol_sound1);
result = _debug_symbol_sound1->_debug_symbol_setMode(_debug_symbol_FMOD_LOOP_OFF);
result = result = _debug_symbol_sys->init(32, _debug_symbol_FMOD_INIT_NORMAL, _debug_symbol_extradriverdata);
result = _debug_symbol_sys->_debug_symbol_createSound( decrypt::_debug_symbol_dec_debug(_T( "_debug_Sounds/TFADenofThieves.mp3")), _debug_symbol_FMOD_DEFAULT, 0, &_debug_symbol_sound2);
result = _debug_symbol_sound2->_debug_symbol_setMode(_debug_symbol_FMOD_LOOP_NORMAL);
_debug_symbol_mLitTexEffect = new _debug_symbol_LitTexEffect();
_debug_symbol_mLitTexEffect->_debug_symbol_LoadEffect( decrypt::_debug_symbol_dec_debug(_T( "_debug_FX/lighting.fx")), _debug_symbol_md3dDevice);
_debug_symbol_m2DCam = new _debug_symbol_BaseCamera();
Vertex::_debug_symbol_InitLitTexLayout(_debug_symbol_md3dDevice, _debug_symbol_mLitTexEffect->_debug_symbol_GetTech());
_debug_symbol_BuildSceneLights();
_debug_symbol_BuildBlendStates();
_debug_symbol_BuildDSStates();
_debug_symbol_splash = new _debug_symbol_Splash();
_debug_symbol_splash->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
return true;
}
void _debug_symbol_JetpackArcher::OnResize()
{
_debug_symbol_D3DApp::OnResize();
_debug_symbol_XMMATRIX _debug_symbol_P = _debug_symbol_XMMatrixPerspectiveFovLH(0.25f*_debug_symbol_MathHelper::_debug_symbol_Pi, _debug_symbol_AspectRatio(), 1.0f, 1000.0f);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mProj, _debug_symbol_P);
_debug_symbol_P = _debug_symbol_XMMatrixOrthographicOffCenterLH(0.0f, _debug_symbol_mClientWidth, 0.0f, _debug_symbol_mClientHeight, 0.0001f, 1000.0f);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_P);
}
void _debug_symbol_JetpackArcher::_debug_symbol_UpdateScene(float dt)
{
_debug_symbol_ID3D11RasterizerState* rs;
_debug_symbol_D3D11_RASTERIZER_DESC _debug_symbol_rsd;
_debug_symbol_rsd._debug_symbol_CullMode = _debug_symbol_D3D11_CULL_NONE;
_debug_symbol_rsd._debug_symbol_AntialiasedLineEnable = false;
_debug_symbol_rsd._debug_symbol_DepthBias = 0.0f;
_debug_symbol_rsd._debug_symbol_DepthBiasClamp = 0.0f;
_debug_symbol_rsd._debug_symbol_DepthClipEnable = true;
_debug_symbol_rsd.FillMode = _debug_symbol_D3D11_FILL_SOLID;
_debug_symbol_rsd._debug_symbol_FrontCounterClockwise = true;
_debug_symbol_rsd._debug_symbol_MultisampleEnable = true;
_debug_symbol_rsd._debug_symbol_ScissorEnable = false;
_debug_symbol_rsd._debug_symbol_SlopeScaledDepthBias = 0.0f;
_debug_symbol_md3dDevice->_debug_symbol_CreateRasterizerState(&_debug_symbol_rsd, &rs);
_debug_symbol_md3dImmediateContext->_debug_symbol_RSSetState(rs);
_debug_symbol_UpdateKeyboardInput(dt);
switch (GetState())
{
case _debug_symbol_SPLASH:
if (!_debug_symbol_splash)
{
Destroy();
_debug_symbol_splash = new _debug_symbol_Splash();
_debug_symbol_splash->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_SPLASH);
}
_debug_symbol_splashTimer += dt;
if (_debug_symbol_splashTimer >= 1.5f)
{
_debug_symbol_mainMenu = new _debug_symbol_MainMenu();
_debug_symbol_mainMenu->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_MAIN_MENU);
break;
}
_debug_symbol_splash->_debug_symbol_UpdateScene(dt);
break;
case _debug_symbol_MAIN_MENU:
if (!_debug_symbol_mainMenu)
{
Destroy();
_debug_symbol_mainMenu = new _debug_symbol_MainMenu();
_debug_symbol_mainMenu->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_MAIN_MENU);
}
_debug_symbol_mainMenu->_debug_symbol_UpdateScene(dt);
break;
case _debug_symbol_CREDITS:
if (!_debug_symbol_credits)
{
Destroy();
_debug_symbol_credits = new _debug_symbol_Credits();
_debug_symbol_credits->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_CREDITS);
}
_debug_symbol_credits->_debug_symbol_UpdateScene(dt);
break;
case _debug_symbol_GAME:
if (!_debug_symbol_game)
{
Destroy();
_debug_symbol_game = new _debug_symbol_Game();
_debug_symbol_game->Init(_debug_symbol_md3dDevice);
SetState(_debug_symbol_GAME);
}
_debug_symbol_game->_debug_symbol_UpdateScene(_debug_symbol_md3dImmediateContext, _debug_symbol_md3dDevice, dt, this);
break;
case _debug_symbol_GAME_WON:
if (!_debug_symbol_gameWon)
{
Destroy();
_debug_symbol_gameWon = new _debug_symbol_GameWon();
_debug_symbol_gameWon->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_GAME_WON);
}
_debug_symbol_gameWon->_debug_symbol_UpdateScene(dt);
break;
case _debug_symbol_GAME_OVER:
if (!_debug_symbol_gameOver)
{
Destroy();
_debug_symbol_gameOver = new _debug_symbol_GameOver();
_debug_symbol_gameOver->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
SetState(_debug_symbol_GAME_OVER);
}
_debug_symbol_gameOver->_debug_symbol_UpdateScene(dt);
break;
}
_debug_symbol_sys->_debug_symbol_update();
}
void _debug_symbol_JetpackArcher::_debug_symbol_DrawScene()
{
_debug_symbol_m2DCam->Update();
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearRenderTargetView(_debug_symbol_mRenderTargetView, reinterpret_cast<const float*>(&_debug_symbol_Colors::White));
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearDepthStencilView(_debug_symbol_mDepthStencilView, _debug_symbol_D3D11_CLEAR_DEPTH | _debug_symbol_D3D11_CLEAR_STENCIL, 1.0f, 0);
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_XMVECTOR _debug_symbol_ambient = _debug_symbol_XMLoadFloat4(&_debug_symbol_mAmbientColour);
_debug_symbol_XMVECTOR _debug_symbol_eyePos = _debug_symbol_XMVectorSet(_debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[2], 0.0f);
_debug_symbol_XMMATRIX _debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_mProj);
_debug_symbol_XMMATRIX _debug_symbol_view = _debug_symbol_m2DCam->GetView();
_debug_symbol_mLitTexEffect->_debug_symbol_SetPerFrameParams(_debug_symbol_ambient, _debug_symbol_eyePos, _debug_symbol_mPointLight, _debug_symbol_mSpotLight);
_debug_symbol_XMMATRIX vp = _debug_symbol_view * _debug_symbol_proj;
vp = _debug_symbol_XMMatrixIdentity();
_debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj);
_debug_symbol_view = _debug_symbol_m2DCam->GetView();
vp = vp * _debug_symbol_view * _debug_symbol_proj;
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
float _debug_symbol_blendFactor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetBlendState(_debug_symbol_mTransparentBS, _debug_symbol_blendFactor, 0xffffffff);
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetDepthStencilState(_debug_symbol_mFontDS, 0);
vp = _debug_symbol_XMMatrixIdentity();
_debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_m2DProj);
_debug_symbol_view = _debug_symbol_m2DCam->GetView();
vp = vp * _debug_symbol_view * _debug_symbol_proj;
switch (GetState())
{
case _debug_symbol_SPLASH:
_debug_symbol_splash->_debug_symbol_DrawScene(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
break;
case _debug_symbol_CREDITS:
_debug_symbol_credits->_debug_symbol_DrawScene(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
break;
case _debug_symbol_MAIN_MENU:
_debug_symbol_mainMenu->_debug_symbol_DrawScene(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
break;
case _debug_symbol_GAME:
_debug_symbol_game->_debug_symbol_DrawScene(_debug_symbol_md3dImmediateContext, vp, _debug_symbol_mSwapChain, _debug_symbol_mRenderTargetView, _debug_symbol_mDepthStencilView, _debug_symbol_mPointLight, _debug_symbol_mSpotLight, _debug_symbol_mAmbientColour);
break;
case _debug_symbol_GAME_OVER:
_debug_symbol_gameOver->_debug_symbol_DrawScene(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
break;
case _debug_symbol_GAME_WON:
_debug_symbol_gameWon->_debug_symbol_DrawScene(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
break;
}
_debug_symbol_HR(_debug_symbol_mSwapChain->_debug_symbol_Present(1, 0));
}
void _debug_symbol_JetpackArcher::_debug_symbol_OnMouseDown(WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
SetCapture(_debug_symbol_mhMainWnd);
if (_debug_symbol_mainMenu)
{
_debug_symbol_mainMenu->_debug_symbol_CheckClick(_debug_symbol_mLastMousePos, this);
result = _debug_symbol_sys->_debug_symbol_playSound(_debug_symbol_sound2, 0, false, &channel);
}
else if (_debug_symbol_credits)
{
_debug_symbol_credits->_debug_symbol_CheckClick(_debug_symbol_mLastMousePos, this);
}
else if (_debug_symbol_gameOver)
{
_debug_symbol_gameOver->_debug_symbol_CheckClick(_debug_symbol_mLastMousePos, this);
}
else if (_debug_symbol_gameWon)
{
_debug_symbol_gameWon->_debug_symbol_CheckClick(_debug_symbol_mLastMousePos, this);
}
}
void _debug_symbol_JetpackArcher::_debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mMouseReleased = false;
ReleaseCapture();
}
void _debug_symbol_JetpackArcher::OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y)
{
float dx = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(x - _debug_symbol_mLastMousePos.x));
float dy = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(y - _debug_symbol_mLastMousePos.y));
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
}
void _debug_symbol_JetpackArcher::_debug_symbol_UpdateKeyboardInput(float dt)
{
if (GetAsyncKeyState(VK_SPACE) & 0x8000)
{
bool _debug_symbol_isPlaying = false;
_debug_symbol_channel2->_debug_symbol_isPlaying(&_debug_symbol_isPlaying);
if (!_debug_symbol_isPlaying)
{
result = _debug_symbol_sys->_debug_symbol_playSound(_debug_symbol_sound1, 0, false, &_debug_symbol_channel2);
}
}
}
void _debug_symbol_JetpackArcher::_debug_symbol_BuildBlendStates()
{
_debug_symbol_D3D11_BLEND_DESC _debug_symbol_bsDesc = { 0 };
_debug_symbol_bsDesc._debug_symbol_AlphaToCoverageEnable = false;
_debug_symbol_bsDesc._debug_symbol_IndependentBlendEnable = false;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0].BlendOp = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlendAlpha = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlendAlpha = _debug_symbol_D3D11_BLEND_ZERO;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendOpAlpha = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_RenderTargetWriteMask = _debug_symbol_D3D11_COLOR_WRITE_ENABLE_ALL;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mAdditiveBS));
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_SRC_ALPHA;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_INV_SRC_ALPHA;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mTransparentBS));
}
void _debug_symbol_JetpackArcher::_debug_symbol_BuildDSStates()
{
_debug_symbol_D3D11_DEPTH_STENCIL_DESC _debug_symbol_dsDesc;
_debug_symbol_dsDesc._debug_symbol_DepthEnable = true;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mNoDepthDS));
_debug_symbol_dsDesc._debug_symbol_DepthEnable = false;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mFontDS));
}
void _debug_symbol_JetpackArcher::SetState(_debug_symbol_States state)
{
_debug_symbol_mCurrState = state;
}
_debug_symbol_JetpackArcher::_debug_symbol_States _debug_symbol_JetpackArcher::GetState()
{
if (_debug_symbol_mCurrState == _debug_symbol_GAME_OVER)
{
if (!_debug_symbol_gameOver)
{
Destroy();
_debug_symbol_gameOver = new _debug_symbol_GameOver();
_debug_symbol_gameOver->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
}
}
else if (_debug_symbol_mCurrState == _debug_symbol_GAME_WON)
{
if (!_debug_symbol_gameWon)
{
Destroy();
_debug_symbol_gameWon = new _debug_symbol_GameWon();
_debug_symbol_gameWon->Init(_debug_symbol_md3dDevice, _debug_symbol_mClientWidth, _debug_symbol_mClientHeight);
}
}
return _debug_symbol_mCurrState;
}
void _debug_symbol_JetpackArcher::Destroy()
{
if (_debug_symbol_mainMenu)
{
delete _debug_symbol_mainMenu;
_debug_symbol_mainMenu = 0;
}
if (_debug_symbol_game)
{
delete _debug_symbol_game;
_debug_symbol_game = 0;
}
if (_debug_symbol_credits)
{
delete _debug_symbol_credits;
_debug_symbol_credits = 0;
}
if (_debug_symbol_gameOver)
{
delete _debug_symbol_gameOver;
_debug_symbol_gameOver = 0;
}
if (_debug_symbol_gameWon)
{
delete _debug_symbol_gameWon;
_debug_symbol_gameWon = 0;
}
if (_debug_symbol_splash)
{
delete _debug_symbol_splash;
_debug_symbol_splash = 0;
}
}

#include "d3dApp.h"
#include "d3dx11Effect.h"
#include "MathHelper.h"
#include "LightHelper.h"
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "vertex.h"
#include "graphicalobject.h"
#include "player.h"
#include "enemy.h"
#include "projectile.h"
#include "effect.h"
#include "basecamera.h"
#include "sprite.h"
#include "xnacollision.h"
#include "fmod.hpp"
#include "boundingboxes.h"
class _debug_symbol_MainMenu;
class _debug_symbol_Splash;
class _debug_symbol_Credits;
class _debug_symbol_Game;
class _debug_symbol_GameOver;
class _debug_symbol_GameWon;
class _debug_symbol_JetpackArcher : public _debug_symbol_D3DApp
{
public:
enum _debug_symbol_States
{
_debug_symbol_SPLASH,
_debug_symbol_MAIN_MENU,
_debug_symbol_GAME,
_debug_symbol_CREDITS,
_debug_symbol_GAME_WON,
_debug_symbol_GAME_OVER
};
_debug_symbol_JetpackArcher(HINSTANCE hInstance);
~_debug_symbol_JetpackArcher();
bool Init();
void OnResize();
void _debug_symbol_UpdateScene(float dt);
void _debug_symbol_DrawScene();
void _debug_symbol_OnMouseDown(WPARAM _debug_symbol_btnState, int x, int y);
void _debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y);
void OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y);
private:
void _debug_symbol_BuildBlendStates();
void _debug_symbol_BuildDSStates();
void _debug_symbol_BuildSceneLights();
_debug_symbol_PointLightOptimized _debug_symbol_mPointLight;
_debug_symbol_SpotLightOptimized _debug_symbol_mSpotLight;
_debug_symbol_XMFLOAT4 _debug_symbol_mAmbientColour;
_debug_symbol_BaseCamera* _debug_symbol_m2DCam;
_debug_symbol_ID3D11BlendState* _debug_symbol_mAdditiveBS;
_debug_symbol_ID3D11BlendState* _debug_symbol_mTransparentBS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mFontDS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mNoDepthDS;
void _debug_symbol_UpdateKeyboardInput(float dt);
bool _debug_symbol_mMouseReleased;
POINT _debug_symbol_mLastMousePos;
_debug_symbol_LitTexEffect* _debug_symbol_mLitTexEffect;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mView;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mProj;
_debug_symbol_XMFLOAT4X4 _debug_symbol_m2DProj;
_debug_symbol_MainMenu* _debug_symbol_mainMenu;
_debug_symbol_Game* _debug_symbol_game;
_debug_symbol_Credits* _debug_symbol_credits;
_debug_symbol_Splash* _debug_symbol_splash;
_debug_symbol_GameOver* _debug_symbol_gameOver;
_debug_symbol_GameWon* _debug_symbol_gameWon;
public:
_debug_symbol_States GetState();
void SetState(_debug_symbol_States state);
_debug_symbol_States _debug_symbol_mCurrState;
float _debug_symbol_splashTimer = 0.0f;
void Destroy();
};

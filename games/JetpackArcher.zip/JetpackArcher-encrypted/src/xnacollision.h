#pragma once
#ifndef _XNA_COLLISION_H_
#define _XNA_COLLISION_H_
#include "d3dUtil.h"
namespace _debug_symbol_XNA
{
#pragma warning(push)
#pragma warning(disable: 4324)
_debug_symbol__DECLSPEC_ALIGN_16_ struct _debug_symbol_Sphere
{
_debug_symbol_XMFLOAT3 Center;
FLOAT _debug_symbol_Radius;
};
_debug_symbol__DECLSPEC_ALIGN_16_ struct _debug_symbol_AxisAlignedBox
{
_debug_symbol_XMFLOAT3 Center;
_debug_symbol_XMFLOAT3 Extents;
};
_debug_symbol__DECLSPEC_ALIGN_16_ struct _debug_symbol_OrientedBox
{
_debug_symbol_XMFLOAT3 Center;
_debug_symbol_XMFLOAT3 Extents;
_debug_symbol_XMFLOAT4 _debug_symbol_Orientation;
};
_debug_symbol__DECLSPEC_ALIGN_16_ struct _debug_symbol_Frustum
{
_debug_symbol_XMFLOAT3 _debug_symbol_Origin;
_debug_symbol_XMFLOAT4 _debug_symbol_Orientation;
FLOAT _debug_symbol_RightSlope;
FLOAT _debug_symbol_LeftSlope;
FLOAT _debug_symbol_TopSlope;
FLOAT _debug_symbol_BottomSlope;
FLOAT _debug_symbol_Near, Far;
};
#pragma warning(pop)
VOID _debug_symbol_ComputeBoundingSphereFromPoints( _debug_symbol_Sphere* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride );
VOID _debug_symbol_ComputeBoundingAxisAlignedBoxFromPoints( _debug_symbol_AxisAlignedBox* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride );
VOID _debug_symbol_ComputeBoundingOrientedBoxFromPoints( _debug_symbol_OrientedBox* pOut, UINT Count, const _debug_symbol_XMFLOAT3* pPoints, UINT Stride );
VOID _debug_symbol_ComputeFrustumFromProjection( _debug_symbol_Frustum* pOut, _debug_symbol_XMMATRIX* _debug_symbol_pProjection );
VOID _debug_symbol_ComputePlanesFromFrustum( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_XMVECTOR* _debug_symbol_pPlane0, _debug_symbol_XMVECTOR* _debug_symbol_pPlane1, _debug_symbol_XMVECTOR* _debug_symbol_pPlane2,
_debug_symbol_XMVECTOR* _debug_symbol_pPlane3, _debug_symbol_XMVECTOR* _debug_symbol_pPlane4, _debug_symbol_XMVECTOR* _debug_symbol_pPlane5 );
VOID _debug_symbol_TransformSphere( _debug_symbol_Sphere* pOut, const _debug_symbol_Sphere* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation, _debug_symbol_FXMVECTOR _debug_symbol_Translation );
VOID _debug_symbol_TransformAxisAlignedBox( _debug_symbol_AxisAlignedBox* pOut, const _debug_symbol_AxisAlignedBox* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation,
_debug_symbol_FXMVECTOR _debug_symbol_Translation );
VOID _debug_symbol_TransformOrientedBox( _debug_symbol_OrientedBox* pOut, const _debug_symbol_OrientedBox* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation,
_debug_symbol_FXMVECTOR _debug_symbol_Translation );
VOID _debug_symbol_TransformFrustum( _debug_symbol_Frustum* pOut, const _debug_symbol_Frustum* pIn, FLOAT Scale, _debug_symbol_FXMVECTOR _debug_symbol_Rotation, _debug_symbol_FXMVECTOR _debug_symbol_Translation );
BOOL _debug_symbol_IntersectPointSphere( _debug_symbol_FXMVECTOR Point, const _debug_symbol_Sphere* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectPointAxisAlignedBox( _debug_symbol_FXMVECTOR Point, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectPointOrientedBox( _debug_symbol_FXMVECTOR Point, const _debug_symbol_OrientedBox* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectPointFrustum( _debug_symbol_FXMVECTOR Point, const _debug_symbol_Frustum* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectRayTriangle( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_CXMVECTOR _debug_symbol_V1, _debug_symbol_CXMVECTOR _debug_symbol_V2,
FLOAT* _debug_symbol_pDist );
BOOL _debug_symbol_IntersectRaySphere( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_Sphere* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist );
BOOL _debug_symbol_IntersectRayAxisAlignedBox( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist );
BOOL _debug_symbol_IntersectRayOrientedBox( _debug_symbol_FXMVECTOR _debug_symbol_Origin, _debug_symbol_FXMVECTOR Direction, const _debug_symbol_OrientedBox* _debug_symbol_pVolume, FLOAT* _debug_symbol_pDist );
BOOL _debug_symbol_IntersectTriangleTriangle( _debug_symbol_FXMVECTOR _debug_symbol_A0, _debug_symbol_FXMVECTOR _debug_symbol_A1, _debug_symbol_FXMVECTOR _debug_symbol_A2, _debug_symbol_CXMVECTOR _debug_symbol_B0, _debug_symbol_CXMVECTOR _debug_symbol_B1, _debug_symbol_CXMVECTOR _debug_symbol_B2 );
BOOL _debug_symbol_IntersectTriangleSphere( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_Sphere* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectTriangleAxisAlignedBox( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectTriangleOrientedBox( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_OrientedBox* _debug_symbol_pVolume );
BOOL _debug_symbol_IntersectSphereSphere( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_Sphere* _debug_symbol_pVolumeB );
BOOL _debug_symbol_IntersectSphereAxisAlignedBox( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeB );
BOOL _debug_symbol_IntersectSphereOrientedBox( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB );
BOOL _debug_symbol_IntersectAxisAlignedBoxAxisAlignedBox( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeB );
BOOL _debug_symbol_IntersectAxisAlignedBoxOrientedBox( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB );
BOOL _debug_symbol_IntersectOrientedBoxOrientedBox( const _debug_symbol_OrientedBox* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB );
float _debug_symbol_OverlapSphereOrientedBox(const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_OrientedBox* _debug_symbol_pVolumeB, _debug_symbol_XMFLOAT3& dir);
INT _debug_symbol_IntersectTriangleFrustum( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, const _debug_symbol_Frustum* _debug_symbol_pVolume );
INT _debug_symbol_IntersectSphereFrustum( const _debug_symbol_Sphere* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB );
INT _debug_symbol_IntersectAxisAlignedBoxFrustum( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB );
INT _debug_symbol_IntersectOrientedBoxFrustum( const _debug_symbol_OrientedBox* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB );
INT _debug_symbol_IntersectFrustumFrustum( const _debug_symbol_Frustum* _debug_symbol_pVolumeA, const _debug_symbol_Frustum* _debug_symbol_pVolumeB );
INT _debug_symbol_IntersectTriangle6Planes( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, _debug_symbol_CXMVECTOR _debug_symbol_Plane0, _debug_symbol_CXMVECTOR _debug_symbol_Plane1,
_debug_symbol_CXMVECTOR _debug_symbol_Plane2, _debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 );
INT _debug_symbol_IntersectSphere6Planes( const _debug_symbol_Sphere* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 );
INT _debug_symbol_IntersectAxisAlignedBox6Planes( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1,
_debug_symbol_FXMVECTOR _debug_symbol_Plane2, _debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 );
INT _debug_symbol_IntersectOrientedBox6Planes( const _debug_symbol_OrientedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 );
INT _debug_symbol_IntersectFrustum6Planes( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane0, _debug_symbol_FXMVECTOR _debug_symbol_Plane1, _debug_symbol_FXMVECTOR _debug_symbol_Plane2,
_debug_symbol_CXMVECTOR _debug_symbol_Plane3, _debug_symbol_CXMVECTOR _debug_symbol_Plane4, _debug_symbol_CXMVECTOR _debug_symbol_Plane5 );
INT _debug_symbol_IntersectTrianglePlane( _debug_symbol_FXMVECTOR _debug_symbol_V0, _debug_symbol_FXMVECTOR _debug_symbol_V1, _debug_symbol_FXMVECTOR _debug_symbol_V2, _debug_symbol_CXMVECTOR _debug_symbol_Plane );
INT _debug_symbol_IntersectSpherePlane( const _debug_symbol_Sphere* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane );
INT _debug_symbol_IntersectAxisAlignedBoxPlane( const _debug_symbol_AxisAlignedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane );
INT _debug_symbol_IntersectOrientedBoxPlane( const _debug_symbol_OrientedBox* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane );
INT _debug_symbol_IntersectFrustumPlane( const _debug_symbol_Frustum* _debug_symbol_pVolume, _debug_symbol_FXMVECTOR _debug_symbol_Plane );
};
#endif

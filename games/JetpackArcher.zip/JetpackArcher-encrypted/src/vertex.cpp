#include "vertex.h"
_debug_symbol_ID3D11InputLayout* Vertex::_debug_symbol_mBasicVertLayout = 0;
_debug_symbol_ID3D11InputLayout* Vertex::_debug_symbol_mNormalTexVertLayout = 0;
_debug_symbol_ID3D11InputLayout* Vertex::_debug_symbol_mTerrainVertLayout = 0;
_debug_symbol_ID3D11InputLayout* Vertex::_debug_symbol_mParticleVertLayout = 0;
void Vertex::_debug_symbol_InitBasicLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech)
{
_debug_symbol_D3D11_INPUT_ELEMENT_DESC _debug_symbol_vertexDesc[] =
{
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_POSITION")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0}
};
_debug_symbol_D3DX11_PASS_DESC _debug_symbol_passDesc;
_debug_symbol_tech->_debug_symbol_GetPassByIndex(0)->_debug_symbol_GetDesc(&_debug_symbol_passDesc);
_debug_symbol_HR(device->_debug_symbol_CreateInputLayout(_debug_symbol_vertexDesc, 1, _debug_symbol_passDesc._debug_symbol_pIAInputSignature, _debug_symbol_passDesc._debug_symbol_IAInputSignatureSize, &_debug_symbol_mBasicVertLayout));
}
void Vertex::_debug_symbol_InitLitTexLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech)
{
_debug_symbol_D3D11_INPUT_ELEMENT_DESC _debug_symbol_vertexDesc[] =
{
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_POSITION")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0},
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_NORMAL")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0},
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_TEXCOORD")), 0, _debug_symbol_DXGI_FORMAT_R32G32_FLOAT, 0, 24, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0}
};
_debug_symbol_D3DX11_PASS_DESC _debug_symbol_passDesc;
_debug_symbol_tech->_debug_symbol_GetPassByIndex(0)->_debug_symbol_GetDesc(&_debug_symbol_passDesc);
_debug_symbol_HR(device->_debug_symbol_CreateInputLayout(_debug_symbol_vertexDesc, 3, _debug_symbol_passDesc._debug_symbol_pIAInputSignature, _debug_symbol_passDesc._debug_symbol_IAInputSignatureSize, &_debug_symbol_mNormalTexVertLayout));
}
void Vertex::_debug_symbol_InitTerrainVertLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech)
{
_debug_symbol_D3D11_INPUT_ELEMENT_DESC _debug_symbol_vertexDesc[] =
{
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_POSITION")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0},
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_NORMAL")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0},
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_TEXCOORD")), 0, _debug_symbol_DXGI_FORMAT_R32G32_FLOAT, 0, 24, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0},
{ decrypt::_debug_symbol_dec_debug(_T( "_debug_TEXCOORD")), 1, _debug_symbol_DXGI_FORMAT_R32G32_FLOAT, 0, 32, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0}
};
_debug_symbol_D3DX11_PASS_DESC _debug_symbol_passDesc;
_debug_symbol_tech->_debug_symbol_GetPassByIndex(0)->_debug_symbol_GetDesc(&_debug_symbol_passDesc);
_debug_symbol_HR(device->_debug_symbol_CreateInputLayout(_debug_symbol_vertexDesc, 4, _debug_symbol_passDesc._debug_symbol_pIAInputSignature, _debug_symbol_passDesc._debug_symbol_IAInputSignatureSize, &_debug_symbol_mTerrainVertLayout));
}
void Vertex::_debug_symbol_InitParticleVertLayout(_debug_symbol_ID3D11Device* device, _debug_symbol_ID3DX11EffectTechnique* _debug_symbol_tech)
{
_debug_symbol_D3D11_INPUT_ELEMENT_DESC _debug_symbol_vertexDesc[] =
{
{  decrypt::_debug_symbol_dec_debug(_T( "_debug_POSITION")), 0, _debug_symbol_DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0 },
{  decrypt::_debug_symbol_dec_debug(_T( "_debug_SIZE")), 0, _debug_symbol_DXGI_FORMAT_R32G32_FLOAT, 0, 12, _debug_symbol_D3D11_INPUT_PER_VERTEX_DATA, 0 }
};
_debug_symbol_D3DX11_PASS_DESC _debug_symbol_passDesc;
_debug_symbol_tech->_debug_symbol_GetPassByIndex(0)->_debug_symbol_GetDesc(&_debug_symbol_passDesc);
_debug_symbol_HR(device->_debug_symbol_CreateInputLayout(_debug_symbol_vertexDesc, 2 , _debug_symbol_passDesc._debug_symbol_pIAInputSignature, _debug_symbol_passDesc._debug_symbol_IAInputSignatureSize, &_debug_symbol_mParticleVertLayout));
}
void Vertex::_debug_symbol_CleanLayouts()
{
_debug_symbol_ReleaseCOM(_debug_symbol_mTerrainVertLayout);
_debug_symbol_ReleaseCOM(_debug_symbol_mNormalTexVertLayout);
_debug_symbol_ReleaseCOM(_debug_symbol_mBasicVertLayout);
_debug_symbol_ReleaseCOM(_debug_symbol_mParticleVertLayout);
}

#pragma once
#include "sprite.h"
class _debug_symbol_JetpackArcher;
class _debug_symbol_Credits
{
public:
_debug_symbol_Credits();
~_debug_symbol_Credits();
void Init(_debug_symbol_ID3D11Device* device, UINT16 _debug_symbol_clientW, UINT16 _debug_symbol_clientH);
void _debug_symbol_DrawScene(_debug_symbol_CXMMATRIX vp, _debug_symbol_ID3D11DeviceContext* context, _debug_symbol_LitTexEffect* _debug_symbol_texEffect);
void _debug_symbol_UpdateScene(float dt);
void _debug_symbol_CheckClick(POINT _debug_symbol_mousePos, _debug_symbol_JetpackArcher* _debug_symbol_instance);
private:
_debug_symbol_Sprite* _debug_symbol_mBG;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_backBB;
};

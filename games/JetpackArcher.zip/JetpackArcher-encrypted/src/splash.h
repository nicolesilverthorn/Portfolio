#pragma once
#include "sprite.h"
class _debug_symbol_JetpackArcher;
class _debug_symbol_Splash
{
public:
_debug_symbol_Splash();
~_debug_symbol_Splash();
void Init(_debug_symbol_ID3D11Device* device, UINT16 _debug_symbol_clientW, UINT16 _debug_symbol_clientH);
void _debug_symbol_DrawScene(_debug_symbol_CXMMATRIX vp, _debug_symbol_ID3D11DeviceContext* context, _debug_symbol_LitTexEffect* _debug_symbol_texEffect);
void _debug_symbol_UpdateScene(float dt);
private:
_debug_symbol_Sprite* _debug_symbol_mBG;
};

#pragma once
#include "graphicalgeometry.h"
#include "effect.h"
#include "boundingboxes.h"
class _debug_symbol_Sprite : public _debug_symbol_GraphicalGeometry
{
public:
struct Frame
{
_debug_symbol_ID3D11ShaderResourceView* image;
_debug_symbol_uint16_t x;
_debug_symbol_uint16_t y;
_debug_symbol_uint16_t _debug_symbol_imageWidth;
_debug_symbol_uint16_t _debug_symbol_imageHeight;
};
public:
_debug_symbol_Sprite(_debug_symbol_FXMVECTOR _debug_symbol_pos2D, _debug_symbol_FXMVECTOR _debug_symbol_scale2D, _debug_symbol_uint16_t _debug_symbol_frameWidth, _debug_symbol_uint16_t _debug_symbol_frameHeight, float depth,
const std::vector<Frame*>& _debug_symbol_frames, float _debug_symbol_frameRate, _debug_symbol_ID3D11Device* device, float _debug_symbol_health);
_debug_symbol_Sprite::_debug_symbol_Sprite();
virtual ~_debug_symbol_Sprite();
_debug_symbol_XMVECTOR GetPos() const
{
return _debug_symbol_XMLoadFloat2(&_debug_symbol_mPos);
}
void SetPos(_debug_symbol_FXMVECTOR pos)
{
_debug_symbol_XMStoreFloat2(&_debug_symbol_mPos, pos);
}
_debug_symbol_XMVECTOR _debug_symbol_GetScale() const
{
return _debug_symbol_XMLoadFloat2(&_debug_symbol_mScale);
}
void _debug_symbol_SetScale(_debug_symbol_FXMVECTOR scale)
{
_debug_symbol_XMStoreFloat2(&_debug_symbol_mScale, scale);
}
float GetDepth() const
{
return _debug_symbol_mDepth;
}
void SetDepth(float depth)
{
_debug_symbol_mDepth = depth;
}
float _debug_symbol_GetFrameRate() const
{
return _debug_symbol_mFrameRate;
}
void _debug_symbol_SetFrameRate(float _debug_symbol_frameRate)
{
_debug_symbol_mFrameRate = _debug_symbol_frameRate;
}
void Play(bool _debug_symbol_loop)
{
_debug_symbol_mLoop = _debug_symbol_loop;
_debug_symbol_mPlaying = true;
}
void Pause()
{
_debug_symbol_mPlaying = false;
}
void Stop()
{
_debug_symbol_mPlaying = false;
_debug_symbol_mFrameIndex = 0;
}
void _debug_symbol_SetFrame(_debug_symbol_uint16_t frame)
{
_debug_symbol_mFrameIndex = frame;
}
float _debug_symbol_GetAngle() const
{
return _debug_symbol_mAngle;
}
void _debug_symbol_SetAngle(float angle)
{
_debug_symbol_mAngle = angle;
}
void Rotate(float angle)
{
_debug_symbol_mAngle += angle;
}
float _debug_symbol_GetSpeed() const
{
return _debug_symbol_mSpeed;
}
virtual void _debug_symbol_HitGround();
virtual void _debug_symbol_LeaveGround()
{
_debug_symbol_mGrounded = false;
}
float GetWidth()
{
return _debug_symbol_mWidth;
}
float GetHeight()
{
return _debug_symbol_mHeight;
}
void _debug_symbol_SetHealth(float _debug_symbol_health)
{
_debug_symbol_mHealth = _debug_symbol_health;
}
float _debug_symbol_GetHealth()
{
return _debug_symbol_mHealth;
}
void _debug_symbol_SetDamage(float _debug_symbol_damage)
{
_debug_symbol_mDamage = _debug_symbol_damage;
}
float _debug_symbol_GetDamage()
{
return _debug_symbol_mDamage;
}
void _debug_symbol_ApplyDamage(_debug_symbol_Sprite* _debug_symbol_spriteHit);
virtual void _debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force);
void Draw(_debug_symbol_CXMMATRIX vp, _debug_symbol_ID3D11DeviceContext* context, _debug_symbol_LitTexEffect* _debug_symbol_litTexEffect);
virtual void Update(float dt);
protected:
_debug_symbol_XMFLOAT2 _debug_symbol_mPos;
_debug_symbol_XMFLOAT2 _debug_symbol_mScale;
_debug_symbol_uint16_t _debug_symbol_mFrameWidth;
_debug_symbol_uint16_t _debug_symbol_mFrameHeight;
float _debug_symbol_mDepth;
std::vector<Frame*> _debug_symbol_mFrames;
float _debug_symbol_mFrameRate;
bool _debug_symbol_mLoop;
bool _debug_symbol_mPlaying;
_debug_symbol_uint16_t _debug_symbol_mFrameIndex;
float _debug_symbol_mAngle;
float _debug_symbol_mCurrFrameTime;
virtual void _debug_symbol_InitVB(_debug_symbol_ID3D11Device* device);
virtual void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device);
_debug_symbol_XMMATRIX _debug_symbol_GetWorld();
float _debug_symbol_mHealth;
float _debug_symbol_mSpeed;
_debug_symbol_XMFLOAT3 _debug_symbol_mVelocity;
bool _debug_symbol_mGrounded;
float _debug_symbol_mWidth;
float _debug_symbol_mHeight;
float _debug_symbol_mDamage;
};

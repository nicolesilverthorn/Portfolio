#pragma once
#include "d3dUtil.h"
#include <map>
#include "vertex.h"
#include "meshgeometry.h"
class _debug_symbol_OBJLoader
{
struct _debug_symbol_HashEntry
{
_debug_symbol_HashEntry* pNext;
int index;
};
public:
static const UINT _debug_symbol_MAX_VERTICES;
public:
_debug_symbol_OBJLoader(void);
~_debug_symbol_OBJLoader(void);
static bool _debug_symbol_LoadOBJ(_debug_symbol_ID3D11Device* device, std::string filename, std::vector<Vertex::_debug_symbol_NormalTexVertex>& _debug_symbol_verices, std::vector<UINT>& indices,
std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets, bool _debug_symbol_isRHS, bool _debug_symbol_uvFlipped);
private:
static void _debug_symbol_LoadMTL(_debug_symbol_ID3D11Device* device, std::wstring filename, std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets);
static UINT _debug_symbol_AddVertex(Vertex::_debug_symbol_NormalTexVertex, std::vector<Vertex::_debug_symbol_NormalTexVertex>& _debug_symbol_vertBuf, std::map<UINT, _debug_symbol_HashEntry*>& _debug_symbol_hashTable, UINT _debug_symbol_hashvalue);
static UINT _debug_symbol_GetSubset(std::wstring name, const std::vector<_debug_symbol_MeshGeometry::_debug_symbol_Subset>& _debug_symbol_subsets);
};

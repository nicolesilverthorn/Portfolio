#pragma once
#include "sprite.h"
class _debug_symbol_Player : public _debug_symbol_Sprite
{
private:
const float _debug_symbol_JUMP_FORCE;
const float _debug_symbol_JETPACK_FORCE;
const float _debug_symbol_JP_GRAVITY;
public:
_debug_symbol_Player(void) : _debug_symbol_JUMP_FORCE(405.0f), _debug_symbol_JETPACK_FORCE(12.0f), _debug_symbol_JP_GRAVITY(1000.0f)
{}
_debug_symbol_Player(_debug_symbol_FXMVECTOR _debug_symbol_pos2D, _debug_symbol_FXMVECTOR _debug_symbol_scale2D, _debug_symbol_uint16_t _debug_symbol_frameWidth, _debug_symbol_uint16_t _debug_symbol_frameHeight, float depth, const std::vector<Frame*>& _debug_symbol_frames,
float _debug_symbol_frameRate, _debug_symbol_ID3D11Device* device, float _debug_symbol_health) :
_debug_symbol_Sprite(_debug_symbol_pos2D, _debug_symbol_scale2D, _debug_symbol_frameWidth, _debug_symbol_frameHeight, depth, _debug_symbol_frames, _debug_symbol_frameRate, device, _debug_symbol_health),
_debug_symbol_JUMP_FORCE(405.0f),
_debug_symbol_JETPACK_FORCE(12.0f),
_debug_symbol_JP_GRAVITY(1000.0f)
{
}
~_debug_symbol_Player(void);
void _debug_symbol_Jump();
void _debug_symbol_UseJetpack(float dt);
};

#include "basecamera.h"
_debug_symbol_BaseCamera::_debug_symbol_BaseCamera(void) :
_debug_symbol_mPos(0.0f, 0.0f, 0.0f),
_debug_symbol_mLook(0.0f, 0.0f, 1.0f),
_debug_symbol_mUp(0.0f, 1.0f, 0.0f),
_debug_symbol_mRight(1.0f, 0.0f, 0.0f),
_debug_symbol_mViewUpdated(true)
{
}
_debug_symbol_BaseCamera::_debug_symbol_BaseCamera(_debug_symbol_FXMVECTOR pos, _debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up) :
_debug_symbol_mViewUpdated(true)
{
_debug_symbol_XMVECTOR right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
}
_debug_symbol_BaseCamera::~_debug_symbol_BaseCamera(void)
{
}
void _debug_symbol_BaseCamera::SetPos(_debug_symbol_FXMVECTOR pos)
{
_debug_symbol_XMStoreFloat3(&_debug_symbol_mPos, pos);
_debug_symbol_mViewUpdated = true;
}
void _debug_symbol_BaseCamera::_debug_symbol_SetFacing(_debug_symbol_FXMVECTOR _debug_symbol_look, _debug_symbol_FXMVECTOR _debug_symbol_up)
{
_debug_symbol_XMStoreFloat3(&_debug_symbol_mLook, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mUp, _debug_symbol_up);
_debug_symbol_XMVECTOR right = _debug_symbol_XMVector3Cross(_debug_symbol_up, _debug_symbol_look);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mRight, right);
_debug_symbol_mViewUpdated = true;
}
_debug_symbol_FXMVECTOR _debug_symbol_BaseCamera::GetPos() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
}
_debug_symbol_FXMVECTOR _debug_symbol_BaseCamera::_debug_symbol_GetLook() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
}
_debug_symbol_FXMVECTOR _debug_symbol_BaseCamera::_debug_symbol_GetUp() const
{
return _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
}
_debug_symbol_XMMATRIX _debug_symbol_BaseCamera::GetView() const
{
return _debug_symbol_XMLoadFloat4x4(&_debug_symbol_mView);
}
void _debug_symbol_BaseCamera::Update()
{
if(_debug_symbol_mViewUpdated)
{
_debug_symbol_mViewUpdated = false;
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMLoadFloat3(&_debug_symbol_mLook);
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat3(&_debug_symbol_mPos);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMLoadFloat3(&_debug_symbol_mUp);
_debug_symbol_XMMATRIX _debug_symbol_V = _debug_symbol_XMMatrixLookAtLH(pos, pos + _debug_symbol_look, _debug_symbol_up);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mView, _debug_symbol_V);
}
}

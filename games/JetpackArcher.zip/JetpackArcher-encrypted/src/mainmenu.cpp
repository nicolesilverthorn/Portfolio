#include "mainmenu.h"
#include "vertex.h"
#include "jetpackarcher.h"
_debug_symbol_MainMenu::_debug_symbol_MainMenu() : _debug_symbol_mBG(0)
{
}
_debug_symbol_MainMenu::~_debug_symbol_MainMenu()
{
if (_debug_symbol_mBG)
{
delete _debug_symbol_mBG;
_debug_symbol_mBG = 0;
}
}
void _debug_symbol_MainMenu::Init(_debug_symbol_ID3D11Device* device, UINT16 _debug_symbol_clientW, UINT16 _debug_symbol_clientH)
{
_debug_symbol_Sprite::Frame* _debug_symbol_BGFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_BGimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(device,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/MenuScreen.png")), 0, 0, &_debug_symbol_BGimage, 0);
_debug_symbol_BGFrame->_debug_symbol_imageWidth = 1024;
_debug_symbol_BGFrame->_debug_symbol_imageHeight = 768;
_debug_symbol_BGFrame->x = 0;
_debug_symbol_BGFrame->y = 0;
_debug_symbol_BGFrame->image = _debug_symbol_BGimage;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_bgFrame;
_debug_symbol_bgFrame.push_back(_debug_symbol_BGFrame);
_debug_symbol_mBG = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_clientW / 2.0f, _debug_symbol_clientH / 2.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
1024.0f, 768.0f, 1.0f, _debug_symbol_bgFrame, 0.25f, device, 0.0f);
_debug_symbol_playBB.pos = _debug_symbol_XMFLOAT2(335.0f, 420.0f);
_debug_symbol_playBB.height = 90.0f;
_debug_symbol_playBB.width = 320.0f;
_debug_symbol_creditsBB.pos = _debug_symbol_XMFLOAT2(320.0f, 516.0f);
_debug_symbol_creditsBB.height = 90.0f;
_debug_symbol_creditsBB.width = 384.0f;
_debug_symbol_quitBB.pos = _debug_symbol_XMFLOAT2(430.0f, 668.0f);
_debug_symbol_quitBB.height = 70.0f;
_debug_symbol_quitBB.width = 168.0f;
}
void _debug_symbol_MainMenu::_debug_symbol_DrawScene(_debug_symbol_CXMMATRIX vp, _debug_symbol_ID3D11DeviceContext* context, _debug_symbol_LitTexEffect* _debug_symbol_texEffect)
{
_debug_symbol_mBG->Draw(vp, context, _debug_symbol_texEffect);
}
void _debug_symbol_MainMenu::_debug_symbol_UpdateScene(float dt)
{
_debug_symbol_mBG->Update(dt);
}
void _debug_symbol_MainMenu::_debug_symbol_CheckClick(POINT _debug_symbol_mousePos, _debug_symbol_JetpackArcher* _debug_symbol_instance)
{
if (_debug_symbol_mousePos.x > _debug_symbol_playBB.pos.x && _debug_symbol_mousePos.x < _debug_symbol_playBB.pos.x + _debug_symbol_playBB.width &&
_debug_symbol_mousePos.y > _debug_symbol_playBB.pos.y && _debug_symbol_mousePos.y < _debug_symbol_playBB.pos.y + _debug_symbol_playBB.height)
{
_debug_symbol_instance->SetState(_debug_symbol_JetpackArcher::_debug_symbol_States::_debug_symbol_GAME);
}
else if (_debug_symbol_mousePos.x > _debug_symbol_creditsBB.pos.x && _debug_symbol_mousePos.x < _debug_symbol_creditsBB.pos.x + _debug_symbol_creditsBB.width &&
_debug_symbol_mousePos.y > _debug_symbol_creditsBB.pos.y && _debug_symbol_mousePos.y < _debug_symbol_creditsBB.pos.y + _debug_symbol_creditsBB.height)
{
_debug_symbol_instance->SetState(_debug_symbol_JetpackArcher::_debug_symbol_States::_debug_symbol_CREDITS);
}
else if (_debug_symbol_mousePos.x > _debug_symbol_quitBB.pos.x && _debug_symbol_mousePos.x < _debug_symbol_quitBB.pos.x + _debug_symbol_quitBB.width &&
_debug_symbol_mousePos.y > _debug_symbol_quitBB.pos.y && _debug_symbol_mousePos.y < _debug_symbol_quitBB.pos.y + _debug_symbol_quitBB.height)
{
exit(0);
}
}

#include "enemy.h"
void _debug_symbol_Enemy::_debug_symbol_Chase(std::vector<_debug_symbol_Enemy*>& _debug_symbol_chaser, _debug_symbol_Sprite* target, float dt)
{
for (int i = 0; i < _debug_symbol_chaser.size(); ++i)
{
_debug_symbol_XMVECTOR _debug_symbol_toPlayer = _debug_symbol_XMVectorSet(target->GetPos()._debug_symbol_m128_f32[0] - _debug_symbol_chaser[i]->GetPos()._debug_symbol_m128_f32[0],
target->GetPos()._debug_symbol_m128_f32[1] - _debug_symbol_chaser[i]->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f);
_debug_symbol_velocity = _debug_symbol_XMVector2Normalize(_debug_symbol_toPlayer) * _debug_symbol_maxVelocity;
_debug_symbol_XMVECTOR pos = _debug_symbol_XMVectorSet(_debug_symbol_chaser[i]->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_velocity._debug_symbol_m128_f32[0] * dt, _debug_symbol_chaser[i]->GetPos()._debug_symbol_m128_f32[1] +
_debug_symbol_velocity._debug_symbol_m128_f32[1] * dt, 0.0f, 0.0f);
_debug_symbol_chaser[i]->SetPos(pos);
}
}
void _debug_symbol_Enemy::Update(float dt)
{
_debug_symbol_bbox.pos.x = _debug_symbol_mPos.x;
_debug_symbol_bbox.pos.y = _debug_symbol_mPos.y;
_debug_symbol_bbox.height = _debug_symbol_mWidth;
_debug_symbol_bbox.width = _debug_symbol_mHeight;
_debug_symbol_Sprite::Update(dt);
}

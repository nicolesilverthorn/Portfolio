#include "game.h"
#include "jetpackarcher.h"
_debug_symbol_Game::_debug_symbol_Game() : _debug_symbol_mLitTexEffect(0), _debug_symbol_m2DCam(0), _debug_symbol_mPlayer(0), _debug_symbol_mBG(0), _debug_symbol_mControlsFont(0), _debug_symbol_mEnemy1(0), _debug_symbol_mEnemy2(0), _debug_symbol_mEnemy3(0),
_debug_symbol_mEnemy4(0), _debug_symbol_mEnemy5(0), _debug_symbol_mEnemy6(0), _debug_symbol_mGreenHBar(0), _debug_symbol_mRedHBar(0), _debug_symbol_mGreenHBarP(0), _debug_symbol_mRedHBarP(0),
_debug_symbol_mRedFuel(0), _debug_symbol_mGreenFuel(0), _debug_symbol_EOLobj(0)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_XMVectorSet(1.0f, 1.0f, 5.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_look = _debug_symbol_XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f);
_debug_symbol_XMVECTOR _debug_symbol_up = _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
_debug_symbol_mLastMousePos.x = 0;
_debug_symbol_mLastMousePos.y = 0;
_debug_symbol_XMMATRIX _debug_symbol_I = _debug_symbol_XMMatrixIdentity();
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mView, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_mProj, _debug_symbol_I);
_debug_symbol_XMStoreFloat4x4(&_debug_symbol_m2DProj, _debug_symbol_I);
}
_debug_symbol_Game::~_debug_symbol_Game()
{
if (_debug_symbol_mLitTexEffect)
{
delete _debug_symbol_mLitTexEffect;
_debug_symbol_mLitTexEffect = 0;
}
if (_debug_symbol_m2DCam)
{
delete _debug_symbol_m2DCam;
_debug_symbol_m2DCam = 0;
}
if (_debug_symbol_mPlayer)
{
delete _debug_symbol_mPlayer;
_debug_symbol_mPlayer = 0;
}
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
if (_debug_symbol_enemies[i])
{
delete _debug_symbol_enemies[i];
_debug_symbol_enemies[i] = 0;
}
if (_debug_symbol_redBarVec[i])
{
delete _debug_symbol_redBarVec[i];
_debug_symbol_redBarVec[i] = 0;
}
if (_debug_symbol_greenBarVec[i])
{
delete _debug_symbol_greenBarVec[i];
_debug_symbol_greenBarVec[i] = 0;
}
}
if (_debug_symbol_EOLobj)
{
delete _debug_symbol_EOLobj;
_debug_symbol_EOLobj = 0;
}
if (_debug_symbol_mControlsFont)
{
delete _debug_symbol_mControlsFont;
_debug_symbol_mControlsFont = 0;
}
if (_debug_symbol_mBG)
{
delete _debug_symbol_mBG;
_debug_symbol_mBG = 0;
}
if (_debug_symbol_mAdditiveBS)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mAdditiveBS);
_debug_symbol_mAdditiveBS = 0;
}
if (_debug_symbol_mTransparentBS)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mTransparentBS);
_debug_symbol_mTransparentBS = 0;
}
if (_debug_symbol_mNoDepthDS)
{
_debug_symbol_ReleaseCOM(_debug_symbol_mNoDepthDS);
_debug_symbol_mNoDepthDS = 0;
}
}
bool _debug_symbol_Game::Init(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice)
{
_debug_symbol_mLitTexEffect = new _debug_symbol_LitTexEffect();
_debug_symbol_mLitTexEffect->_debug_symbol_LoadEffect( decrypt::_debug_symbol_dec_debug(_T( "_debug_FX/lighting.fx")), _debug_symbol_md3dDevice);
_debug_symbol_m2DCam = new _debug_symbol_BaseCamera(_debug_symbol_XMVectorSet(0.0f, 0.0f, -0.5f, 0.0f), _debug_symbol_XMVectorSet(0.0f, 0.0f, 1.0f, 0.0f), _debug_symbol_XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f));
_debug_symbol_m2DCam->Update();
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/TestAdditive.png")), 0, 0, &_debug_symbol_mParticleTexture, 0);
_debug_symbol_BuildBlendStates(_debug_symbol_md3dDevice);
_debug_symbol_BuildDSStates(_debug_symbol_md3dDevice);
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_projImage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/arrow.png")), 0, 0, &_debug_symbol_projImage, 0);
_debug_symbol_projectileFrame->_debug_symbol_imageWidth = 22;
_debug_symbol_projectileFrame->_debug_symbol_imageHeight = 9;
_debug_symbol_projectileFrame->x = 0;
_debug_symbol_projectileFrame->y = 0;
_debug_symbol_projectileFrame->image = _debug_symbol_projImage;
_debug_symbol_projFrame.push_back(_debug_symbol_projectileFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_BGFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_BGimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/TFAbgTiled.png")), 0, 0, &_debug_symbol_BGimage, 0);
_debug_symbol_BGFrame->_debug_symbol_imageWidth = 1024;
_debug_symbol_BGFrame->_debug_symbol_imageHeight = 768;
_debug_symbol_BGFrame->x = 0;
_debug_symbol_BGFrame->y = 0;
_debug_symbol_BGFrame->image = _debug_symbol_BGimage;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_bgFrame;
_debug_symbol_bgFrame.push_back(_debug_symbol_BGFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_CFFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_CFimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/controlsFont.png")), 0, 0, &_debug_symbol_CFimage, 0);
_debug_symbol_CFFrame->_debug_symbol_imageWidth = 411;
_debug_symbol_CFFrame->_debug_symbol_imageHeight = 203;
_debug_symbol_CFFrame->x = 0;
_debug_symbol_CFFrame->y = 0;
_debug_symbol_CFFrame->image = _debug_symbol_CFimage;
_debug_symbol_cfFrame.push_back(_debug_symbol_CFFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_flameFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_flameImage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/flame.png")), 0, 0, &_debug_symbol_flameImage, 0);
_debug_symbol_flameFrame->_debug_symbol_imageWidth = 16;
_debug_symbol_flameFrame->_debug_symbol_imageHeight = 16;
_debug_symbol_flameFrame->x = 0;
_debug_symbol_flameFrame->y = 0;
_debug_symbol_flameFrame->image = _debug_symbol_flameImage;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_flameFrames;
_debug_symbol_flameFrames.push_back(_debug_symbol_flameFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_newFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* image;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/player.png")), 0, 0, &image, 0);
_debug_symbol_newFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_newFrame->_debug_symbol_imageHeight = 96;
_debug_symbol_newFrame->x = 0;
_debug_symbol_newFrame->y = 0;
_debug_symbol_newFrame->image = image;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_frames;
_debug_symbol_frames.push_back(_debug_symbol_newFrame);
_debug_symbol_newFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_newFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_newFrame->_debug_symbol_imageHeight = 96;
_debug_symbol_newFrame->x = 32;
_debug_symbol_newFrame->y = 0;
_debug_symbol_newFrame->image = image;
_debug_symbol_frames.push_back(_debug_symbol_newFrame);
_debug_symbol_newFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_newFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_newFrame->_debug_symbol_imageHeight = 96;
_debug_symbol_newFrame->x = 64;
_debug_symbol_newFrame->y = 0;
_debug_symbol_newFrame->image = image;
_debug_symbol_frames.push_back(_debug_symbol_newFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame1 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage1;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemyStrip1.png")), 0, 0, &_debug_symbol_enemyImage1, 0);
_debug_symbol_enemyFrame1->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame1->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame1->x = 0;
_debug_symbol_enemyFrame1->y = 0;
_debug_symbol_enemyFrame1->image = _debug_symbol_enemyImage1;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames1;
_debug_symbol_enemyFrames1.push_back(_debug_symbol_enemyFrame1);
_debug_symbol_enemyFrame1 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame1->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame1->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame1->x = 32;
_debug_symbol_enemyFrame1->y = 0;
_debug_symbol_enemyFrame1->image = _debug_symbol_enemyImage1;
_debug_symbol_enemyFrames1.push_back(_debug_symbol_enemyFrame1);
_debug_symbol_enemyFrame1 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame1->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame1->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame1->x = 64;
_debug_symbol_enemyFrame1->y = 0;
_debug_symbol_enemyFrame1->image = _debug_symbol_enemyImage1;
_debug_symbol_enemyFrames1.push_back(_debug_symbol_enemyFrame1);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame2 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage2;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemyStrip2.png")), 0, 0, &_debug_symbol_enemyImage2, 0);
_debug_symbol_enemyFrame2->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame2->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame2->x = 0;
_debug_symbol_enemyFrame2->y = 0;
_debug_symbol_enemyFrame2->image = _debug_symbol_enemyImage2;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames2;
_debug_symbol_enemyFrames2.push_back(_debug_symbol_enemyFrame2);
_debug_symbol_enemyFrame2 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame2->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame2->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame2->x = 32;
_debug_symbol_enemyFrame2->y = 0;
_debug_symbol_enemyFrame2->image = _debug_symbol_enemyImage2;
_debug_symbol_enemyFrames2.push_back(_debug_symbol_enemyFrame2);
_debug_symbol_enemyFrame2 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame2->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame2->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame2->x = 64;
_debug_symbol_enemyFrame2->y = 0;
_debug_symbol_enemyFrame2->image = _debug_symbol_enemyImage2;
_debug_symbol_enemyFrames2.push_back(_debug_symbol_enemyFrame2);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame3 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage3;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemyStrip3.png")), 0, 0, &_debug_symbol_enemyImage3, 0);
_debug_symbol_enemyFrame3->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame3->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame3->x = 0;
_debug_symbol_enemyFrame3->y = 0;
_debug_symbol_enemyFrame3->image = _debug_symbol_enemyImage3;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames3;
_debug_symbol_enemyFrames3.push_back(_debug_symbol_enemyFrame3);
_debug_symbol_enemyFrame3 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame3->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame3->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame3->x = 32;
_debug_symbol_enemyFrame3->y = 0;
_debug_symbol_enemyFrame3->image = _debug_symbol_enemyImage3;
_debug_symbol_enemyFrames3.push_back(_debug_symbol_enemyFrame3);
_debug_symbol_enemyFrame3 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame3->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame3->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame3->x = 64;
_debug_symbol_enemyFrame3->y = 0;
_debug_symbol_enemyFrame3->image = _debug_symbol_enemyImage3;
_debug_symbol_enemyFrames3.push_back(_debug_symbol_enemyFrame3);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame4 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage4;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemy4.png")), 0, 0, &_debug_symbol_enemyImage4, 0);
_debug_symbol_enemyFrame4->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame4->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame4->x = 0;
_debug_symbol_enemyFrame4->y = 0;
_debug_symbol_enemyFrame4->image = _debug_symbol_enemyImage4;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames4;
_debug_symbol_enemyFrames4.push_back(_debug_symbol_enemyFrame4);
_debug_symbol_enemyFrame4 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame4->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame4->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame4->x = 32;
_debug_symbol_enemyFrame4->y = 0;
_debug_symbol_enemyFrame4->image = _debug_symbol_enemyImage4;
_debug_symbol_enemyFrames4.push_back(_debug_symbol_enemyFrame4);
_debug_symbol_enemyFrame4 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame4->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame4->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame4->x = 64;
_debug_symbol_enemyFrame4->y = 0;
_debug_symbol_enemyFrame4->image = _debug_symbol_enemyImage4;
_debug_symbol_enemyFrames4.push_back(_debug_symbol_enemyFrame4);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame5 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage5;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemy5.png")), 0, 0, &_debug_symbol_enemyImage5, 0);
_debug_symbol_enemyFrame5->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame5->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame5->x = 0;
_debug_symbol_enemyFrame5->y = 0;
_debug_symbol_enemyFrame5->image = _debug_symbol_enemyImage5;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames5;
_debug_symbol_enemyFrames5.push_back(_debug_symbol_enemyFrame5);
_debug_symbol_enemyFrame5 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame5->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame5->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame5->x = 32;
_debug_symbol_enemyFrame5->y = 0;
_debug_symbol_enemyFrame5->image = _debug_symbol_enemyImage5;
_debug_symbol_enemyFrames5.push_back(_debug_symbol_enemyFrame5);
_debug_symbol_enemyFrame5 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame5->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame5->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame5->x = 64;
_debug_symbol_enemyFrame5->y = 0;
_debug_symbol_enemyFrame5->image = _debug_symbol_enemyImage5;
_debug_symbol_enemyFrames5.push_back(_debug_symbol_enemyFrame5);
_debug_symbol_Sprite::Frame* _debug_symbol_enemyFrame6 = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_enemyImage6;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/enemy6.png")), 0, 0, &_debug_symbol_enemyImage6, 0);
_debug_symbol_enemyFrame6->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame6->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame6->x = 0;
_debug_symbol_enemyFrame6->y = 0;
_debug_symbol_enemyFrame6->image = _debug_symbol_enemyImage6;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_enemyFrames6;
_debug_symbol_enemyFrames6.push_back(_debug_symbol_enemyFrame6);
_debug_symbol_enemyFrame6 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame6->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame6->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame6->x = 32;
_debug_symbol_enemyFrame6->y = 0;
_debug_symbol_enemyFrame6->image = _debug_symbol_enemyImage6;
_debug_symbol_enemyFrames6.push_back(_debug_symbol_enemyFrame6);
_debug_symbol_enemyFrame6 = new _debug_symbol_Sprite::Frame();
_debug_symbol_enemyFrame6->_debug_symbol_imageWidth = 96;
_debug_symbol_enemyFrame6->_debug_symbol_imageHeight = 32;
_debug_symbol_enemyFrame6->x = 64;
_debug_symbol_enemyFrame6->y = 0;
_debug_symbol_enemyFrame6->image = _debug_symbol_enemyImage6;
_debug_symbol_enemyFrames6.push_back(_debug_symbol_enemyFrame6);
_debug_symbol_Sprite::Frame* _debug_symbol_greenHBFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_greenHBimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/greenHealth.png")), 0, 0, &_debug_symbol_greenHBimage, 0);
_debug_symbol_greenHBFrame->_debug_symbol_imageWidth = 32;
_debug_symbol_greenHBFrame->_debug_symbol_imageHeight = 8;
_debug_symbol_greenHBFrame->x = 0;
_debug_symbol_greenHBFrame->y = 0;
_debug_symbol_greenHBFrame->image = _debug_symbol_greenHBimage;
_debug_symbol_hbFrameG.push_back(_debug_symbol_greenHBFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_redHBFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_redHBimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/redHealth.png")), 0, 0, &_debug_symbol_redHBimage, 0);
_debug_symbol_redHBFrame->_debug_symbol_imageWidth = 32;
_debug_symbol_redHBFrame->_debug_symbol_imageHeight = 8;
_debug_symbol_redHBFrame->x = 0;
_debug_symbol_redHBFrame->y = 0;
_debug_symbol_redHBFrame->image = _debug_symbol_redHBimage;
_debug_symbol_hbFrameR.push_back(_debug_symbol_redHBFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_greenFBFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_greenFBimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/greenFuel.png")), 0, 0, &_debug_symbol_greenFBimage, 0);
_debug_symbol_greenFBFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_greenFBFrame->_debug_symbol_imageHeight = 16;
_debug_symbol_greenFBFrame->x = 0;
_debug_symbol_greenFBFrame->y = 0;
_debug_symbol_greenFBFrame->image = _debug_symbol_greenFBimage;
_debug_symbol_fbFrameG.push_back(_debug_symbol_greenFBFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_redFBFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_redFBimage;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/redFuel.png")), 0, 0, &_debug_symbol_redFBimage, 0);
_debug_symbol_redFBFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_redFBFrame->_debug_symbol_imageHeight = 16;
_debug_symbol_redFBFrame->x = 0;
_debug_symbol_redFBFrame->y = 0;
_debug_symbol_redFBFrame->image = _debug_symbol_redFBimage;
_debug_symbol_fbFrameR.push_back(_debug_symbol_redFBFrame);
_debug_symbol_Sprite::Frame* _debug_symbol_EOLobjFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_EOLobjImg;
_debug_symbol_D3DX11CreateShaderResourceViewFromFile(_debug_symbol_md3dDevice,  decrypt::_debug_symbol_dec_debug(_T( "_debug_Textures/EOLobj.png")), 0, 0, &_debug_symbol_EOLobjImg, 0);
_debug_symbol_EOLobjFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_EOLobjFrame->_debug_symbol_imageHeight = 32;
_debug_symbol_EOLobjFrame->x = 0;
_debug_symbol_EOLobjFrame->y = 0;
_debug_symbol_EOLobjFrame->image = _debug_symbol_EOLobjImg;
_debug_symbol_EOLobjFrames.push_back(_debug_symbol_EOLobjFrame);
_debug_symbol_EOLobjFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_EOLobjFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_EOLobjFrame->_debug_symbol_imageHeight = 32;
_debug_symbol_EOLobjFrame->x = 32;
_debug_symbol_EOLobjFrame->y = 0;
_debug_symbol_EOLobjFrame->image = _debug_symbol_EOLobjImg;
_debug_symbol_EOLobjFrames.push_back(_debug_symbol_EOLobjFrame);
_debug_symbol_EOLobjFrame = new _debug_symbol_Sprite::Frame();
_debug_symbol_EOLobjFrame->_debug_symbol_imageWidth = 96;
_debug_symbol_EOLobjFrame->_debug_symbol_imageHeight = 32;
_debug_symbol_EOLobjFrame->x = 64;
_debug_symbol_EOLobjFrame->y = 0;
_debug_symbol_EOLobjFrame->image = _debug_symbol_EOLobjImg;
_debug_symbol_EOLobjFrames.push_back(_debug_symbol_EOLobjFrame);
_debug_symbol_mBG = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(512.0f, 384.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
1024.0f, 768.0f, 1.0f, _debug_symbol_bgFrame, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mControlsFont = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(800.0f, 100.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
411.0f, 203.0f, 1.0f, _debug_symbol_cfFrame, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mPlayer = new _debug_symbol_Player(_debug_symbol_XMVectorSet(512.0f, 384.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32, 32, 0.1f, _debug_symbol_frames, 0.25f, _debug_symbol_md3dDevice, 3.0f);
_debug_symbol_mFlame = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1] - 16, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
16.0f, 16.0f, 0.1f, _debug_symbol_flameFrames, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mEnemy1 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(800.0f, 500.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames1, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy1);
_debug_symbol_mEnemy2 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(600.0f, 700.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames2, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy2);
_debug_symbol_mEnemy3 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(800, 200.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames3, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy3);
_debug_symbol_mEnemy4 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(200.0f, 500.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames4, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy4);
_debug_symbol_mEnemy5 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(200.0f, 700.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames5, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy5);
_debug_symbol_mEnemy6 = new _debug_symbol_Enemy(_debug_symbol_XMVectorSet(200.0f, 200.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 0.1f, _debug_symbol_enemyFrames6, 0.25f, _debug_symbol_md3dDevice, 5.0f);
_debug_symbol_enemies.push_back(_debug_symbol_mEnemy6);
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
_debug_symbol_mGreenHBar = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[1] + 32, 0.0f, 0.0f),
_debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f), 32.0f, 8.0f, 1.0f, _debug_symbol_hbFrameG, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_greenBarVec.push_back(_debug_symbol_mGreenHBar);
_debug_symbol_mRedHBar = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_redXPos, _debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[1] + 32, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 8.0f, 1.0f, _debug_symbol_hbFrameR, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_redBarVec.push_back(_debug_symbol_mRedHBar);
}
_debug_symbol_mGreenHBarP = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(60.0f, 736.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
96.0f, 16.0f, 1.0f, _debug_symbol_hbFrameG, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mRedHBarP = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_redXPosP, 736.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
96.0f, 16.0f, 1.0f, _debug_symbol_hbFrameR, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mGreenFuel = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(60.0f, 698.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
96.0f, 16.0f, 1.0f, _debug_symbol_fbFrameG, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mRedFuel = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(_debug_symbol_redXPosF, 698.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
96.0f, 16.0f, 1.0f, _debug_symbol_fbFrameR, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_EOLobj = new _debug_symbol_Sprite(_debug_symbol_XMVectorSet(512.0f, 720.0f, 0.0f, 0.0f), _debug_symbol_XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f),
32.0f, 32.0f, 1.0f, _debug_symbol_EOLobjFrames, 0.25f, _debug_symbol_md3dDevice, 0.0f);
_debug_symbol_mPlayer->Play(true);
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
_debug_symbol_enemies[i]->Play(true);
}
_debug_symbol_InitBoundingBoxes();
return true;
}
void _debug_symbol_Game::_debug_symbol_InitBoundingBoxes()
{
_debug_symbol_playerBB.pos.x = _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_playerBB.pos.y = _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1];
_debug_symbol_playerBB.height = 12.0f;
_debug_symbol_playerBB.width = 12.0f;
_debug_symbol_bb1.pos = _debug_symbol_XMFLOAT2(0.0f, 736.0f);
_debug_symbol_bb1.height = 32.0f;
_debug_symbol_bb1.width = 1024.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb1);
_debug_symbol_bb2.pos = _debug_symbol_XMFLOAT2(0.0f, 32.0f);
_debug_symbol_bb2.height = 704.0f;
_debug_symbol_bb2.width = 40.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb2);
_debug_symbol_bb3.pos = _debug_symbol_XMFLOAT2(0.0f, 0.0f);
_debug_symbol_bb3.height = 48.0f;
_debug_symbol_bb3.width = 1024.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb3);
_debug_symbol_bb4.pos = _debug_symbol_XMFLOAT2(995.0f, 32.0f);
_debug_symbol_bb4.height = 704.0f;
_debug_symbol_bb4.width = 32.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb4);
_debug_symbol_bb5.pos = _debug_symbol_XMFLOAT2(32.0f, 672.0f);
_debug_symbol_bb5.height = 64.0f;
_debug_symbol_bb5.width = 40.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb5);
_debug_symbol_bb6.pos = _debug_symbol_XMFLOAT2(64.0f, 704.0f);
_debug_symbol_bb6.height = 32.0f;
_debug_symbol_bb6.width = 72.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb6);
_debug_symbol_bb7.pos = _debug_symbol_XMFLOAT2(899.0f, 704.0f);
_debug_symbol_bb7.height = 32.0f;
_debug_symbol_bb7.width = 64.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb7);
_debug_symbol_bb8.pos = _debug_symbol_XMFLOAT2(963.0f, 672.0f);
_debug_symbol_bb8.height = 64.0f;
_debug_symbol_bb8.width = 32.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb8);
_debug_symbol_bb9.pos = _debug_symbol_XMFLOAT2(227.0f, 608.0f);
_debug_symbol_bb9.height = 48.0f;
_debug_symbol_bb9.width = 70.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb9);
_debug_symbol_bb10.pos = _debug_symbol_XMFLOAT2(419.0f, 576.0f);
_debug_symbol_bb10.height = 48.0f;
_debug_symbol_bb10.width = 198.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb10);
_debug_symbol_bb11.pos = _debug_symbol_XMFLOAT2(451.0f, 544.0f);
_debug_symbol_bb11.height = 48.0f;
_debug_symbol_bb11.width = 134.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb11);
_debug_symbol_bb12.pos = _debug_symbol_XMFLOAT2(739.0f, 608.0f);
_debug_symbol_bb12.height = 48.0f;
_debug_symbol_bb12.width = 70.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb12);
_debug_symbol_bb13.pos = _debug_symbol_XMFLOAT2(32.0f, 479.0f);
_debug_symbol_bb13.height = 81.0f;
_debug_symbol_bb13.width = 105.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb13);
_debug_symbol_bb14.pos = _debug_symbol_XMFLOAT2(128.0f, 512.0f);
_debug_symbol_bb14.height = 48.0f;
_debug_symbol_bb14.width = 73.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb14);
_debug_symbol_bb15.pos = _debug_symbol_XMFLOAT2(835.0f, 512.0f);
_debug_symbol_bb15.height = 48.0f;
_debug_symbol_bb15.width = 73.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb15);
_debug_symbol_bb16.pos = _debug_symbol_XMFLOAT2(899.0f, 479.0f);
_debug_symbol_bb16.height = 81.0f;
_debug_symbol_bb16.width = 105.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb16);
_debug_symbol_bb17.pos = _debug_symbol_XMFLOAT2(259.0f, 351.0f);
_debug_symbol_bb17.height = 113.0f;
_debug_symbol_bb17.width = 102.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb17);
_debug_symbol_bb18.pos = _debug_symbol_XMFLOAT2(675.0f, 351.0f);
_debug_symbol_bb18.height = 113.0f;
_debug_symbol_bb18.width = 102.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb18);
_debug_symbol_bb19.pos = _debug_symbol_XMFLOAT2(32.0f, 224.0f);
_debug_symbol_bb19.height = 112.0f;
_debug_symbol_bb19.width = 72.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb19);
_debug_symbol_bb20.pos = _debug_symbol_XMFLOAT2(487.0f, 256.0f);
_debug_symbol_bb20.height = 78.0f;
_debug_symbol_bb20.width = 64.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb20);
_debug_symbol_bb21.pos = _debug_symbol_XMFLOAT2(932.0f, 224.0f);
_debug_symbol_bb21.height = 112.0f;
_debug_symbol_bb21.width = 72.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb21);
_debug_symbol_bb22.pos = _debug_symbol_XMFLOAT2(32.0f, 160.0f);
_debug_symbol_bb22.height = 79.0f;
_debug_symbol_bb22.width = 104.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb22);
_debug_symbol_bb23.pos = _debug_symbol_XMFLOAT2(453.0f, 192.0f);
_debug_symbol_bb23.height = 78.0f;
_debug_symbol_bb23.width = 130.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb23);
_debug_symbol_bb24.pos = _debug_symbol_XMFLOAT2(900.0f, 160.0f);
_debug_symbol_bb24.height = 80.0f;
_debug_symbol_bb24.width = 104.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb24);
_debug_symbol_bb25.pos = _debug_symbol_XMFLOAT2(32.0f, 32.0f);
_debug_symbol_bb25.height = 144.0f;
_debug_symbol_bb25.width = 264.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb25);
_debug_symbol_bb26.pos = _debug_symbol_XMFLOAT2(288.0f, 128.0f);
_debug_symbol_bb26.height = 48.0f;
_debug_symbol_bb26.width = 41.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb26);
_debug_symbol_bb27.pos = _debug_symbol_XMFLOAT2(484.0f, 159.0f);
_debug_symbol_bb27.height = 48.0f;
_debug_symbol_bb27.width = 70.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb27);
_debug_symbol_bb28.pos = _debug_symbol_XMFLOAT2(707.0f, 128.0f);
_debug_symbol_bb28.height = 48.0f;
_debug_symbol_bb28.width = 41.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb28);
_debug_symbol_bb29.pos = _debug_symbol_XMFLOAT2(740.0f, 32.0f);
_debug_symbol_bb29.height = 144.0f;
_debug_symbol_bb29.width = 264.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb29);
_debug_symbol_bb30.pos = _debug_symbol_XMFLOAT2(227.0f, 350.0f);
_debug_symbol_bb30.height = 45.0f;
_debug_symbol_bb30.width = 40.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb30);
_debug_symbol_bb31.pos = _debug_symbol_XMFLOAT2(771.0f, 350.0f);
_debug_symbol_bb31.height = 45.0f;
_debug_symbol_bb31.width = 40.0f;
_debug_symbol_boxes.push_back(_debug_symbol_bb31);
}
void _debug_symbol_Game::_debug_symbol_BuildBlendStates(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice)
{
_debug_symbol_D3D11_BLEND_DESC _debug_symbol_bsDesc = { 0 };
_debug_symbol_bsDesc._debug_symbol_AlphaToCoverageEnable = false;
_debug_symbol_bsDesc._debug_symbol_IndependentBlendEnable = false;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0].BlendOp = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlendAlpha = _debug_symbol_D3D11_BLEND_ONE;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlendAlpha = _debug_symbol_D3D11_BLEND_ZERO;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendOpAlpha = _debug_symbol_D3D11_BLEND_OP_ADD;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_RenderTargetWriteMask = _debug_symbol_D3D11_COLOR_WRITE_ENABLE_ALL;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mAdditiveBS));
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_BlendEnable = true;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_SrcBlend = _debug_symbol_D3D11_BLEND_SRC_ALPHA;
_debug_symbol_bsDesc._debug_symbol_RenderTarget[0]._debug_symbol_DestBlend = _debug_symbol_D3D11_BLEND_INV_SRC_ALPHA;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateBlendState(&_debug_symbol_bsDesc, &_debug_symbol_mTransparentBS));
}
void _debug_symbol_Game::_debug_symbol_BuildDSStates(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice)
{
_debug_symbol_D3D11_DEPTH_STENCIL_DESC _debug_symbol_dsDesc;
_debug_symbol_dsDesc._debug_symbol_DepthEnable = true;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mNoDepthDS));
_debug_symbol_dsDesc._debug_symbol_DepthEnable = false;
_debug_symbol_dsDesc._debug_symbol_DepthWriteMask = _debug_symbol_D3D11_DEPTH_WRITE_MASK_ZERO;
_debug_symbol_dsDesc._debug_symbol_DepthFunc = _debug_symbol_D3D11_COMPARISON_LESS;
_debug_symbol_dsDesc._debug_symbol_StencilEnable = false;
_debug_symbol_dsDesc._debug_symbol_StencilReadMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_StencilWriteMask = 0xff;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_FrontFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilDepthFailOp = _debug_symbol_D3D11_STENCIL_OP_KEEP;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilPassOp = _debug_symbol_D3D11_STENCIL_OP_REPLACE;
_debug_symbol_dsDesc._debug_symbol_BackFace._debug_symbol_StencilFunc = _debug_symbol_D3D11_COMPARISON_ALWAYS;
_debug_symbol_HR(_debug_symbol_md3dDevice->_debug_symbol_CreateDepthStencilState(&_debug_symbol_dsDesc, &_debug_symbol_mFontDS));
}
void _debug_symbol_Game::_debug_symbol_SpriteRectCollision(_debug_symbol_Sprite* _debug_symbol_sprite, _debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb)
{
float _debug_symbol_r1CentreX = _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_sprite->GetWidth() / 2;
float _debug_symbol_r1CentreY = _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] + (30 / 2);
float _debug_symbol_r2CentreX = _debug_symbol_bb.pos.x + _debug_symbol_bb.width / 2;
float _debug_symbol_r2CentreY = _debug_symbol_bb.pos.y + _debug_symbol_bb.height / 2;
float _debug_symbol_diffX = _debug_symbol_r1CentreX - _debug_symbol_r2CentreX;
float _debug_symbol_diffY = _debug_symbol_r1CentreY - _debug_symbol_r2CentreY;
float _debug_symbol_halfWidths = (_debug_symbol_sprite->GetWidth() + _debug_symbol_bb.width) / 2;
float _debug_symbol_halfHeights = (30 + _debug_symbol_bb.height) / 2;
float _debug_symbol_overlapX = _debug_symbol_halfWidths - abs(_debug_symbol_diffX);
float _debug_symbol_overlapY = _debug_symbol_halfHeights - abs(_debug_symbol_diffY);
if (_debug_symbol_overlapX > 0 && _debug_symbol_overlapY > 0)
{
if (_debug_symbol_overlapX >= _debug_symbol_overlapY)
{
if (_debug_symbol_r1CentreY < _debug_symbol_r2CentreY)
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] - _debug_symbol_overlapY, 0.0f, 0.0f));
}
else
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] + _debug_symbol_overlapY, 0.0f, 0.0f));
}
}
else
{
if (_debug_symbol_r1CentreX < _debug_symbol_r2CentreX)
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] - _debug_symbol_overlapX, _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
}
else
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_overlapX, _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
}
}
}
}
_debug_symbol_Game::_debug_symbol_CollisionSide _debug_symbol_Game::_debug_symbol_RectRectCollision(_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_r1, _debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_r2, _debug_symbol_Sprite* _debug_symbol_sprite)
{
float _debug_symbol_r1CentreX = _debug_symbol_r1.pos.x + _debug_symbol_r1.width / 2;
float _debug_symbol_r1CentreY = _debug_symbol_r1.pos.y + _debug_symbol_r1.height / 2;
float _debug_symbol_r2CentreX = _debug_symbol_r2.pos.x + _debug_symbol_r2.width / 2;
float _debug_symbol_r2CentreY = _debug_symbol_r2.pos.y + _debug_symbol_r2.height / 2;
float _debug_symbol_diffX = _debug_symbol_r1CentreX - _debug_symbol_r2CentreX;
float _debug_symbol_diffY = _debug_symbol_r1CentreY - _debug_symbol_r2CentreY;
float _debug_symbol_halfWidths = (_debug_symbol_r1.width + _debug_symbol_r2.width) / 2;
float _debug_symbol_halfHeights = (_debug_symbol_r1.height + _debug_symbol_r2.height) / 2;
float _debug_symbol_overlapX = _debug_symbol_halfWidths - abs(_debug_symbol_diffX);
float _debug_symbol_overlapY = _debug_symbol_halfHeights - abs(_debug_symbol_diffY);
if (_debug_symbol_overlapX > 0 && _debug_symbol_overlapY > 0)
{
if (_debug_symbol_overlapX >= _debug_symbol_overlapY)
{
if (_debug_symbol_r1CentreY < _debug_symbol_r2CentreY)
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] - _debug_symbol_overlapY, 0.0f, 0.0f));
return _debug_symbol_CollisionSide::top;
}
else
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] + _debug_symbol_overlapY, 0.0f, 0.0f));
return _debug_symbol_CollisionSide::_debug_symbol_bot;
}
}
else
{
if (_debug_symbol_r1CentreX < _debug_symbol_r2CentreX)
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] - _debug_symbol_overlapX, _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
return _debug_symbol_CollisionSide::right;
}
else
{
_debug_symbol_sprite->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_overlapX, _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
return _debug_symbol_CollisionSide::left;
}
}
}
}
bool _debug_symbol_Game::_debug_symbol_EnemyProjCollision(_debug_symbol_Sprite* _debug_symbol_sprite, _debug_symbol_Projectile* _debug_symbol_arrow)
{
float _debug_symbol_r1CentreX = _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_sprite->GetWidth() / 2;
float _debug_symbol_r1CentreY = _debug_symbol_sprite->GetPos()._debug_symbol_m128_f32[1] +  (30 / 2);
float _debug_symbol_p1CentreX = _debug_symbol_arrow->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_arrow->_debug_symbol_GetProjWidth() / 2;
float _debug_symbol_p1CentreY = _debug_symbol_arrow->GetPos()._debug_symbol_m128_f32[1] + _debug_symbol_arrow->_debug_symbol_GetProjHeight() / 2;
float _debug_symbol_diffX = _debug_symbol_r1CentreX - _debug_symbol_p1CentreX;
float _debug_symbol_diffY = _debug_symbol_r1CentreY - _debug_symbol_p1CentreY;
float _debug_symbol_halfWidths = (_debug_symbol_sprite->GetWidth() + _debug_symbol_arrow->_debug_symbol_GetProjWidth()) / 2;
float _debug_symbol_halfHeights = (30 + _debug_symbol_arrow->_debug_symbol_GetProjHeight()) / 2;
float _debug_symbol_overlapX = _debug_symbol_halfWidths - abs(_debug_symbol_diffX);
float _debug_symbol_overlapY = _debug_symbol_halfHeights - abs(_debug_symbol_diffY);
if (_debug_symbol_overlapX > 0 && _debug_symbol_overlapY > 0)
{
return true;
}
else
{
return false;
}
}
bool _debug_symbol_Game::_debug_symbol_PlayerEnemyCollision(_debug_symbol_Sprite* _debug_symbol_player, _debug_symbol_Sprite* _debug_symbol_enemy)
{
float _debug_symbol_r1CentreX = _debug_symbol_player->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_player->GetWidth() / 2;
float _debug_symbol_r1CentreY = _debug_symbol_player->GetPos()._debug_symbol_m128_f32[1] + _debug_symbol_player->GetHeight() / 2;
float _debug_symbol_p1CentreX = _debug_symbol_enemy->GetPos()._debug_symbol_m128_f32[0] + _debug_symbol_enemy->GetWidth() / 2;
float _debug_symbol_p1CentreY = _debug_symbol_enemy->GetPos()._debug_symbol_m128_f32[1] + _debug_symbol_enemy->GetHeight() / 2;
float _debug_symbol_diffX = _debug_symbol_r1CentreX - _debug_symbol_p1CentreX;
float _debug_symbol_diffY = _debug_symbol_r1CentreY - _debug_symbol_p1CentreY;
float _debug_symbol_halfWidths = (_debug_symbol_player->GetWidth() + _debug_symbol_enemy->GetWidth()) / 2;
float _debug_symbol_halfHeights = (_debug_symbol_player->GetHeight() + _debug_symbol_enemy->GetHeight()) / 2;
float _debug_symbol_overlapX = _debug_symbol_halfWidths - abs(_debug_symbol_diffX);
float _debug_symbol_overlapY = _debug_symbol_halfHeights - abs(_debug_symbol_diffY);
if (_debug_symbol_overlapX > 0 && _debug_symbol_overlapY > 0)
{
return true;
}
else
{
return false;
}
}
void _debug_symbol_Game::_debug_symbol_UpdateScene(_debug_symbol_ID3D11DeviceContext* _debug_symbol_md3dImmediateContext, _debug_symbol_ID3D11Device* _debug_symbol_md3dDevice, float dt, _debug_symbol_JetpackArcher* _debug_symbol_instance)
{
_debug_symbol_controlsTimer += dt;
_debug_symbol_ID3D11RasterizerState* rs;
_debug_symbol_D3D11_RASTERIZER_DESC _debug_symbol_rsd;
_debug_symbol_rsd._debug_symbol_CullMode = _debug_symbol_D3D11_CULL_NONE;
_debug_symbol_rsd._debug_symbol_AntialiasedLineEnable = false;
_debug_symbol_rsd._debug_symbol_DepthBias = 0.0f;
_debug_symbol_rsd._debug_symbol_DepthBiasClamp = 0.0f;
_debug_symbol_rsd._debug_symbol_DepthClipEnable = true;
_debug_symbol_rsd.FillMode = _debug_symbol_D3D11_FILL_SOLID;
_debug_symbol_rsd._debug_symbol_FrontCounterClockwise = true;
_debug_symbol_rsd._debug_symbol_MultisampleEnable = true;
_debug_symbol_rsd._debug_symbol_ScissorEnable = false;
_debug_symbol_rsd._debug_symbol_SlopeScaledDepthBias = 0.0f;
_debug_symbol_md3dDevice->_debug_symbol_CreateRasterizerState(&_debug_symbol_rsd, &rs);
_debug_symbol_md3dImmediateContext->_debug_symbol_RSSetState(rs);
if (_debug_symbol_recoverTime > 0.0f)
{
_debug_symbol_recoverTime = _debug_symbol_recoverTime - dt;
}
else
{
_debug_symbol_recoverTime = 0.0f;
}
_debug_symbol_playerBB.pos.x = _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_playerBB.pos.y = _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1];
_debug_symbol_UpdateKeyboardInput(_debug_symbol_md3dDevice, dt);
_debug_symbol_m2DCam->Update();
_debug_symbol_mPlayer->Update(dt);
_debug_symbol_mPlayer->_debug_symbol_AddForce(_debug_symbol_XMVectorSet(0.0f, -9.8f, 0.0f, 0.0f));
if (_debug_symbol_isFacingRight)
{
_debug_symbol_mFlame->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0] - 5, _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1] - 16, 0.0f, 0.0f));
}
else if (!_debug_symbol_isFacingRight)
{
_debug_symbol_mFlame->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0] + 5, _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1] - 16, 0.0f, 0.0f));
}
_debug_symbol_mFlame->Update(dt);
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
if (_debug_symbol_PlayerEnemyCollision(_debug_symbol_mPlayer, _debug_symbol_enemies[i]) && _debug_symbol_recoverTime == 0.0f)
{
_debug_symbol_enemies[i]->_debug_symbol_ApplyDamage(_debug_symbol_mPlayer);
_debug_symbol_recoverTime = 3.0f;
}
}
_debug_symbol_redXPosP = 60.0f;
_debug_symbol_currHealthP = _debug_symbol_mPlayer->_debug_symbol_GetHealth();
_debug_symbol_maxHealthP = 3.0f;
_debug_symbol_ratioP = 1.0f - (_debug_symbol_currHealthP / _debug_symbol_maxHealthP);
_debug_symbol_redXPosP += ((1.0f - _debug_symbol_ratioP) / 2.0f) * 96.0f;
_debug_symbol_redXScaleP = _debug_symbol_ratioP;
_debug_symbol_mGreenHBarP->SetPos(_debug_symbol_XMVectorSet(60.0f, 736.0f, 0.0f, 0.0f));
_debug_symbol_mRedHBarP->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_redXPosP, 736.0f, 0.0f, 0.0f));
_debug_symbol_mRedHBarP->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(_debug_symbol_redXScaleP, 1.0f, 0.0f, 0.0f));
if (_debug_symbol_mPlayer->_debug_symbol_GetHealth() == 0)
{
_debug_symbol_instance->SetState(_debug_symbol_JetpackArcher::_debug_symbol_States::_debug_symbol_GAME_OVER);
}
if (_debug_symbol_RectRectCollision(_debug_symbol_playerBB, _debug_symbol_EOLobjBB, _debug_symbol_mPlayer) == _debug_symbol_CollisionSide::top ||
_debug_symbol_RectRectCollision(_debug_symbol_playerBB, _debug_symbol_EOLobjBB, _debug_symbol_mPlayer) == _debug_symbol_CollisionSide::left ||
_debug_symbol_RectRectCollision(_debug_symbol_playerBB, _debug_symbol_EOLobjBB, _debug_symbol_mPlayer) == _debug_symbol_CollisionSide::right)
{
_debug_symbol_instance->SetState(_debug_symbol_JetpackArcher::_debug_symbol_States::_debug_symbol_GAME_WON);
}
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
_debug_symbol_enemies[i]->Update(dt);
_debug_symbol_enemies[i]->_debug_symbol_Chase(_debug_symbol_enemies, _debug_symbol_mPlayer, dt);
_debug_symbol_redXPos = _debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[0];
_debug_symbol_currHealth = _debug_symbol_enemies[i]->_debug_symbol_GetHealth();
_debug_symbol_maxHealth = 5.0f;
_debug_symbol_ratio = 1.0f - (_debug_symbol_currHealth / _debug_symbol_maxHealth);
_debug_symbol_redXPos += ((1.0f - _debug_symbol_ratio) / 2.0f) * 32.0f;
_debug_symbol_redXScale = _debug_symbol_ratio;
_debug_symbol_greenBarVec[i]->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[1] + 32, 0.0f, 0.0f));
_debug_symbol_redBarVec[i]->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_redXPos, _debug_symbol_enemies[i]->GetPos()._debug_symbol_m128_f32[1] + 32, 0.0f, 0.0f));
_debug_symbol_redBarVec[i]->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(_debug_symbol_redXScale, 1.0f, 0.0f, 0.0f));
_debug_symbol_SpriteRectCollision(_debug_symbol_enemies[i], _debug_symbol_playerBB);
for (int j = 0; j < _debug_symbol_boxes.size(); ++j)
{
_debug_symbol_SpriteRectCollision(_debug_symbol_enemies[i], _debug_symbol_boxes[j]);
}
if (_debug_symbol_enemies[i]->_debug_symbol_GetHealth() == 0)
{
delete _debug_symbol_enemies[i];
_debug_symbol_enemies.erase(_debug_symbol_enemies.begin() + i);
i--;
break;
}
}
if (_debug_symbol_enemies.size() == 0)
{
_debug_symbol_EOLobjActive = true;
_debug_symbol_EOLobjBB.pos = _debug_symbol_XMFLOAT2(_debug_symbol_EOLobj->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_EOLobj->GetPos()._debug_symbol_m128_f32[1]);
_debug_symbol_EOLobjBB.height = 32.0f;
_debug_symbol_EOLobjBB.width = 32.0f;
}
for (int i = 0; i < _debug_symbol_boxes.size(); ++i)
{
_debug_symbol_RectRectCollision(_debug_symbol_playerBB, _debug_symbol_boxes[i], _debug_symbol_mPlayer);
if (_debug_symbol_RectRectCollision(_debug_symbol_playerBB, _debug_symbol_boxes[i], _debug_symbol_mPlayer) == _debug_symbol_CollisionSide::_debug_symbol_bot)
{
_debug_symbol_mPlayer->_debug_symbol_HitGround();
}
}
for (int i = 0; i < _debug_symbol_mProjectiles.size(); ++i)
{
_debug_symbol_mProjectiles[i]->Update(dt);
for (int j = 0; j < _debug_symbol_enemies.size(); ++j)
{
if (_debug_symbol_mProjectiles[i]->_debug_symbol_GetDistanceTravelled() > _debug_symbol_mProjectiles[i]->_debug_symbol_MAX_DISTANCE ||
_debug_symbol_mProjectiles[i]->_debug_symbol_GetDistanceTravelled() < _debug_symbol_mProjectiles[i]->_debug_symbol_MIN_DISTANCE)
{
delete _debug_symbol_mProjectiles[i];
_debug_symbol_mProjectiles.erase(_debug_symbol_mProjectiles.begin() + i);
i--;
break;
}
if (_debug_symbol_EnemyProjCollision(_debug_symbol_enemies[j], _debug_symbol_mProjectiles[i]))
{
_debug_symbol_mProjectiles[i]->_debug_symbol_ApplyDamage(_debug_symbol_enemies[j]);
delete _debug_symbol_mProjectiles[i];
_debug_symbol_mProjectiles.erase(_debug_symbol_mProjectiles.begin() + i);
i--;
break;
}
}
}
_debug_symbol_mGreenFuel->Update(dt);
_debug_symbol_mRedFuel->Update(dt);
_debug_symbol_EOLobj->Update(dt);
}
void _debug_symbol_Game::_debug_symbol_DrawScene(_debug_symbol_ID3D11DeviceContext* _debug_symbol_md3dImmediateContext, _debug_symbol_CXMMATRIX vp, _debug_symbol_IDXGISwapChain* _debug_symbol_mSwapChain, _debug_symbol_ID3D11RenderTargetView* _debug_symbol_mRenderTargetView,
_debug_symbol_ID3D11DepthStencilView* _debug_symbol_mDepthStencilView, _debug_symbol_PointLightOptimized _debug_symbol_mPointLight, _debug_symbol_SpotLightOptimized _debug_symbol_mSpotLight, _debug_symbol_XMFLOAT4 _debug_symbol_mAmbientColour)
{
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearRenderTargetView(_debug_symbol_mRenderTargetView, reinterpret_cast<const float*>(&_debug_symbol_Colors::White));
_debug_symbol_md3dImmediateContext->_debug_symbol_ClearDepthStencilView(_debug_symbol_mDepthStencilView, _debug_symbol_D3D11_CLEAR_DEPTH | _debug_symbol_D3D11_CLEAR_STENCIL, 1.0f, 0);
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
_debug_symbol_XMVECTOR _debug_symbol_ambient = _debug_symbol_XMLoadFloat4(&_debug_symbol_mAmbientColour);
_debug_symbol_XMVECTOR _debug_symbol_eyePos = _debug_symbol_XMVectorSet(_debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[1], _debug_symbol_m2DCam->GetPos()._debug_symbol_m128_f32[2], 0.0f);
_debug_symbol_XMMATRIX _debug_symbol_proj = _debug_symbol_XMLoadFloat4x4(&_debug_symbol_mProj);
_debug_symbol_XMMATRIX _debug_symbol_view = _debug_symbol_m2DCam->GetView();
_debug_symbol_mLitTexEffect->_debug_symbol_SetPerFrameParams(_debug_symbol_ambient, _debug_symbol_eyePos, _debug_symbol_mPointLight, _debug_symbol_mSpotLight);
_debug_symbol_XMMATRIX _debug_symbol_tempVP = vp;
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetInputLayout(Vertex::_debug_symbol_GetNormalTexVertLayout());
_debug_symbol_md3dImmediateContext->_debug_symbol_IASetPrimitiveTopology(_debug_symbol_D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
float _debug_symbol_blendFactor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetBlendState(_debug_symbol_mTransparentBS, _debug_symbol_blendFactor, 0xffffffff);
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetDepthStencilState(_debug_symbol_mFontDS, 0);
_debug_symbol_mBG->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
if (_debug_symbol_EOLobjActive)
{
_debug_symbol_EOLobj->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
}
if (_debug_symbol_isFacingRight)
{
_debug_symbol_mPlayer->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(1.0f, 1.0f, 0.0f, 0.0f));
}
else if (!_debug_symbol_isFacingRight)
{
_debug_symbol_mPlayer->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(-1.0f, 1.0f, 0.0f, 0.0f));
}
_debug_symbol_mPlayer->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
if (_debug_symbol_drawFlame)
{
_debug_symbol_mFlame->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_drawFlame = false;
}
_debug_symbol_mGreenHBarP->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_mRedHBarP->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_mGreenFuel->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_mRedFuel->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
for (int i = 0; i < _debug_symbol_enemies.size(); ++i)
{
_debug_symbol_enemies[i]->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_greenBarVec[i]->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
_debug_symbol_redBarVec[i]->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
}
for (int i = 0; i < _debug_symbol_mProjectiles.size(); ++i)
{
if (_debug_symbol_isFacingRight)
{
_debug_symbol_mProjectiles[i]->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(1.0f, 1.0f, 0.0f, 0.0f));
}
else if (!_debug_symbol_isFacingRight)
{
_debug_symbol_mProjectiles[i]->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(-1.0f, 1.0f, 0.0f, 0.0f));
}
_debug_symbol_mProjectiles[i]->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
}
if (_debug_symbol_controlsTimer <= 7.0f)
{
_debug_symbol_mControlsFont->Draw(vp, _debug_symbol_md3dImmediateContext, _debug_symbol_mLitTexEffect);
}
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetDepthStencilState(0, 0);
_debug_symbol_md3dImmediateContext->_debug_symbol_OMSetBlendState(0, _debug_symbol_blendFactor, 0xffffffff);
}
void _debug_symbol_Game::_debug_symbol_OnMouseDown(HWND _debug_symbol_mhMainWnd, WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
SetCapture(_debug_symbol_mhMainWnd);
}
void _debug_symbol_Game::_debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y)
{
_debug_symbol_mMouseReleased = false;
ReleaseCapture();
}
void _debug_symbol_Game::OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y)
{
float dx = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(x - _debug_symbol_mLastMousePos.x));
float dy = _debug_symbol_XMConvertToRadians(0.25f*static_cast<float>(y - _debug_symbol_mLastMousePos.y));
_debug_symbol_mLastMousePos.x = x;
_debug_symbol_mLastMousePos.y = y;
}
void _debug_symbol_Game::_debug_symbol_UpdateKeyboardInput(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice, float dt)
{
float move = 0.0f;
move = dt * 100;
if (GetAsyncKeyState(VK_LEFT) & 0x8000)
{
if (_debug_symbol_isFacingRight)
{
_debug_symbol_isFacingRight = false;
}
_debug_symbol_mPlayer->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0] - move, _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
}
if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
{
if (!_debug_symbol_isFacingRight)
{
_debug_symbol_isFacingRight = true;
}
_debug_symbol_mPlayer->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0] + move, _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1], 0.0f, 0.0f));
}
if (GetAsyncKeyState(VK_UP) & 0x8000)
{
if ((GetAsyncKeyState(VK_LCONTROL) & 0x8000) == 0)
{
if ((GetAsyncKeyState(VK_RCONTROL) & 0x8000) == 0)
{
_debug_symbol_mPlayer->_debug_symbol_Jump();
}
}
}
if (GetAsyncKeyState(VK_LCONTROL) & 0x8000 || GetAsyncKeyState(VK_RCONTROL) & 0x8000)
{
_debug_symbol_fuelRecoverTime += dt;
if (_debug_symbol_canUseJetpack)
{
if (_debug_symbol_fuelRecoverTime > 3.0f)
{
_debug_symbol_mFuel--;
_debug_symbol_fuelRecoverTime = 0.0f;
}
_debug_symbol_redXPosF = 60.0f;
_debug_symbol_currHealthF = _debug_symbol_mFuel;
_debug_symbol_maxHealthF = 5.0f;
_debug_symbol_ratioF = 1.0f - (_debug_symbol_currHealthF / _debug_symbol_maxHealthF);
_debug_symbol_redXPosF += ((1.0f - _debug_symbol_ratioF) / 2.0f) * 96.0f;
_debug_symbol_redXScaleF = _debug_symbol_ratioF;
_debug_symbol_mGreenFuel->SetPos(_debug_symbol_XMVectorSet(60.0f, 698.0f, 0.0f, 0.0f));
_debug_symbol_mRedFuel->SetPos(_debug_symbol_XMVectorSet(_debug_symbol_redXPosF, 698.0f, 0.0f, 0.0f));
_debug_symbol_mRedFuel->_debug_symbol_SetScale(_debug_symbol_XMVectorSet(_debug_symbol_redXScaleF, 1.0f, 0.0f, 0.0f));
_debug_symbol_mPlayer->_debug_symbol_UseJetpack(dt);
}
if (_debug_symbol_mFuel == 0)
{
_debug_symbol_canUseJetpack = false;
}
_debug_symbol_drawFlame = true;
}
if (GetAsyncKeyState(VK_SPACE) & 0x8000)
{
if (_debug_symbol_canShoot)
{
if (_debug_symbol_isFacingRight)
{
_debug_symbol_Projectile* _debug_symbol_arrowProjectile = new _debug_symbol_Projectile(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1] - 8, 0.0f, 0.0f),
_debug_symbol_XMVectorSet(1.0f, 1.0f, 0.0f, 0.0f), 22, 9, 0.5f, _debug_symbol_projFrame, 0.25f, _debug_symbol_md3dDevice, 0.0f, _debug_symbol_XMVectorSet(250.0f, 0.0f, 0.0f, 0.0f));
_debug_symbol_mProjectiles.push_back(_debug_symbol_arrowProjectile);
_debug_symbol_canShoot = false;
}
if (!_debug_symbol_isFacingRight)
{
_debug_symbol_Projectile* _debug_symbol_arrowProjectile = new _debug_symbol_Projectile(_debug_symbol_XMVectorSet(_debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[0], _debug_symbol_mPlayer->GetPos()._debug_symbol_m128_f32[1] - 8, 0.0f, 0.0f),
_debug_symbol_XMVectorSet(-1.0f, 1.0f, 0.0f, 0.0f), 22, 9, 0.5f, _debug_symbol_projFrame, 0.25f, _debug_symbol_md3dDevice, 0.0f, _debug_symbol_XMVectorSet(-250.0f, 0.0f, 0.0f, 0.0f));
_debug_symbol_mProjectiles.push_back(_debug_symbol_arrowProjectile);
_debug_symbol_canShoot = false;
}
}
else
{
_debug_symbol_cooldownTimer++;
if (_debug_symbol_cooldownTimer >= 15)
{
_debug_symbol_canShoot = true;
_debug_symbol_cooldownTimer = 0.0f;
}
}
}
}

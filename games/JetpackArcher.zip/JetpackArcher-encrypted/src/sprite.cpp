#include "sprite.h"
#include "vertex.h"
_debug_symbol_Sprite::_debug_symbol_Sprite(_debug_symbol_FXMVECTOR _debug_symbol_pos2D, _debug_symbol_FXMVECTOR _debug_symbol_scale2D, _debug_symbol_uint16_t _debug_symbol_frameWidth, _debug_symbol_uint16_t _debug_symbol_frameHeight, float depth, const std::vector<Frame*>& _debug_symbol_frames,
float _debug_symbol_frameRate, _debug_symbol_ID3D11Device* device, float _debug_symbol_health) :
_debug_symbol_mFrameWidth(_debug_symbol_frameWidth),
_debug_symbol_mFrameHeight(_debug_symbol_frameHeight),
_debug_symbol_mDepth(depth),
_debug_symbol_mFrames(_debug_symbol_frames),
_debug_symbol_mFrameRate(_debug_symbol_frameRate),
_debug_symbol_mHealth(_debug_symbol_health),
_debug_symbol_mFrameIndex(0),
_debug_symbol_mAngle(0),
_debug_symbol_mCurrFrameTime(0.0f),
_debug_symbol_mVelocity(0.0f, 0.0f, 0.0f),
_debug_symbol_mGrounded(false),
_debug_symbol_mWidth(20.0f),
_debug_symbol_mHeight(32.0f),
_debug_symbol_mDamage(1.0f)
{
_debug_symbol_XMStoreFloat2(&_debug_symbol_mPos, _debug_symbol_pos2D);
_debug_symbol_XMStoreFloat2(&_debug_symbol_mScale, _debug_symbol_scale2D);
_debug_symbol_InitVB(device);
_debug_symbol_InitIB(device);
}
_debug_symbol_Sprite::~_debug_symbol_Sprite()
{
}
void _debug_symbol_Sprite::_debug_symbol_HitGround()
{
_debug_symbol_mGrounded = true;
_debug_symbol_mVelocity.y = 0.0f;
}
void _debug_symbol_Sprite::_debug_symbol_InitVB(_debug_symbol_ID3D11Device* device)
{
_debug_symbol_XMFLOAT3 _debug_symbol_vbPositions[4];
_debug_symbol_vbPositions[0] = _debug_symbol_XMFLOAT3(-_debug_symbol_mFrameWidth / 2.0f, _debug_symbol_mFrameHeight / 2.0f, 0.0f);
_debug_symbol_vbPositions[1] = _debug_symbol_XMFLOAT3(_debug_symbol_mFrameWidth / 2.0f, _debug_symbol_mFrameHeight / 2.0f, 0.0f);
_debug_symbol_vbPositions[2] = _debug_symbol_XMFLOAT3(_debug_symbol_mFrameWidth / 2.0f, -_debug_symbol_mFrameHeight / 2.0f, 0.0f);
_debug_symbol_vbPositions[3] = _debug_symbol_XMFLOAT3(-_debug_symbol_mFrameWidth / 2.0f, -_debug_symbol_mFrameHeight / 2.0f, 0.0f);
_debug_symbol_XMFLOAT3 normal = _debug_symbol_XMFLOAT3(0.0f, 0.0f, 1.0f);
std::vector<Vertex::_debug_symbol_NormalTexVertex> _debug_symbol_vertices(_debug_symbol_mFrames.size() * 4);
for (int i = 0; i < _debug_symbol_mFrames.size(); ++i)
{
int _debug_symbol_vertexIndex = i * 4;
_debug_symbol_vertices[_debug_symbol_vertexIndex].pos = _debug_symbol_vbPositions[0];
_debug_symbol_vertices[_debug_symbol_vertexIndex + 1].pos = _debug_symbol_vbPositions[1];
_debug_symbol_vertices[_debug_symbol_vertexIndex + 2].pos = _debug_symbol_vbPositions[2];
_debug_symbol_vertices[_debug_symbol_vertexIndex + 3].pos = _debug_symbol_vbPositions[3];
_debug_symbol_vertices[_debug_symbol_vertexIndex].normal = normal;
_debug_symbol_vertices[_debug_symbol_vertexIndex + 1].normal = normal;
_debug_symbol_vertices[_debug_symbol_vertexIndex + 2].normal = normal;
_debug_symbol_vertices[_debug_symbol_vertexIndex + 3].normal = normal;
Frame* _debug_symbol_currFrame = _debug_symbol_mFrames[i];
float _debug_symbol_leftU = (float)_debug_symbol_currFrame->x / (float)_debug_symbol_currFrame->_debug_symbol_imageWidth;
float _debug_symbol_topV = (float)_debug_symbol_currFrame->y / (float)_debug_symbol_currFrame->_debug_symbol_imageHeight;
float _debug_symbol_rightU = _debug_symbol_leftU + ((float)_debug_symbol_mFrameWidth / (float)_debug_symbol_currFrame->_debug_symbol_imageWidth);
float _debug_symbol_bottomV =  _debug_symbol_topV + ((float)_debug_symbol_mFrameHeight / (float)_debug_symbol_currFrame->_debug_symbol_imageHeight);
_debug_symbol_vertices[_debug_symbol_vertexIndex]._debug_symbol_tex = _debug_symbol_XMFLOAT2(_debug_symbol_leftU, _debug_symbol_topV);
_debug_symbol_vertices[_debug_symbol_vertexIndex + 1]._debug_symbol_tex = _debug_symbol_XMFLOAT2(_debug_symbol_rightU, _debug_symbol_topV);
_debug_symbol_vertices[_debug_symbol_vertexIndex + 2]._debug_symbol_tex = _debug_symbol_XMFLOAT2(_debug_symbol_rightU, _debug_symbol_bottomV);
_debug_symbol_vertices[_debug_symbol_vertexIndex + 3]._debug_symbol_tex = _debug_symbol_XMFLOAT2(_debug_symbol_leftU, _debug_symbol_bottomV);
}
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_vbd;
_debug_symbol_vbd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_vbd._debug_symbol_ByteWidth = sizeof(Vertex::_debug_symbol_NormalTexVertex) * _debug_symbol_vertices.size();
_debug_symbol_vbd.BindFlags = _debug_symbol_D3D11_BIND_VERTEX_BUFFER;
_debug_symbol_vbd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_vbd._debug_symbol_MiscFlags = 0;
_debug_symbol_vbd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_vinitData;
_debug_symbol_vinitData._debug_symbol_pSysMem = &_debug_symbol_vertices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_vbd, &_debug_symbol_vinitData, &_debug_symbol_mVB));
}
void _debug_symbol_Sprite::_debug_symbol_InitIB(_debug_symbol_ID3D11Device* device)
{
std::vector<UINT> indices(_debug_symbol_mFrames.size() * 6);
for (int i = 0; i < _debug_symbol_mFrames.size(); ++i)
{
UINT _debug_symbol_vertexIndex = i * 4;
UINT _debug_symbol_indexIndex = i * 6;
indices[_debug_symbol_indexIndex] = _debug_symbol_vertexIndex;
indices[_debug_symbol_indexIndex + 1] = _debug_symbol_vertexIndex + 1;
indices[_debug_symbol_indexIndex + 2] = _debug_symbol_vertexIndex + 2;
indices[_debug_symbol_indexIndex + 3] = _debug_symbol_vertexIndex;
indices[_debug_symbol_indexIndex + 4] = _debug_symbol_vertexIndex + 2;
indices[_debug_symbol_indexIndex + 5] = _debug_symbol_vertexIndex + 3;
}
_debug_symbol_D3D11_BUFFER_DESC _debug_symbol_ibd;
_debug_symbol_ibd.Usage = _debug_symbol_D3D11_USAGE_IMMUTABLE;
_debug_symbol_ibd._debug_symbol_ByteWidth = sizeof(UINT) * indices.size();
_debug_symbol_ibd.BindFlags = _debug_symbol_D3D11_BIND_INDEX_BUFFER;
_debug_symbol_ibd._debug_symbol_CPUAccessFlags = 0;
_debug_symbol_ibd._debug_symbol_MiscFlags = 0;
_debug_symbol_ibd._debug_symbol_StructureByteStride = 0;
_debug_symbol_D3D11_SUBRESOURCE_DATA _debug_symbol_iinitData;
_debug_symbol_iinitData._debug_symbol_pSysMem = &indices[0];
_debug_symbol_HR(device->_debug_symbol_CreateBuffer(&_debug_symbol_ibd, &_debug_symbol_iinitData, &_debug_symbol_mIB));
}
_debug_symbol_XMMATRIX _debug_symbol_Sprite::_debug_symbol_GetWorld()
{
_debug_symbol_XMMATRIX scale = _debug_symbol_XMMatrixScaling(_debug_symbol_mScale.x, _debug_symbol_mScale.y, 1.0f);
_debug_symbol_XMMATRIX _debug_symbol_rot = _debug_symbol_XMMatrixRotationZ(_debug_symbol_mAngle);
_debug_symbol_XMMATRIX _debug_symbol_trans = _debug_symbol_XMMatrixTranslationFromVector(_debug_symbol_XMVectorSet(_debug_symbol_mPos.x, _debug_symbol_mPos.y, _debug_symbol_mDepth, 1.0f));
_debug_symbol_XMMATRIX _debug_symbol_world = scale * _debug_symbol_rot * _debug_symbol_trans;
return _debug_symbol_world;
}
void _debug_symbol_Sprite::Update(float dt)
{
if (_debug_symbol_mPlaying)
{
_debug_symbol_mCurrFrameTime += dt;
if (_debug_symbol_mCurrFrameTime > _debug_symbol_mFrameRate)
{
_debug_symbol_mFrameIndex++;
_debug_symbol_mCurrFrameTime -= _debug_symbol_mFrameRate;
if (_debug_symbol_mFrameIndex >= _debug_symbol_mFrames.size())
{
if (_debug_symbol_mLoop)
{
_debug_symbol_mFrameIndex = 0;
}
else
{
_debug_symbol_mFrameIndex--;
_debug_symbol_mPlaying = false;
}
}
}
}
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat2(&_debug_symbol_mPos);
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
pos = pos + (_debug_symbol_vel * dt);
_debug_symbol_XMStoreFloat2(&_debug_symbol_mPos, pos);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
void _debug_symbol_Sprite::Draw(_debug_symbol_CXMMATRIX vp, _debug_symbol_ID3D11DeviceContext* context, _debug_symbol_LitTexEffect* _debug_symbol_litTexEffect)
{
UINT offset = 0;
UINT stride = sizeof(Vertex::_debug_symbol_NormalTexVertex);
_debug_symbol_XMMATRIX _debug_symbol_world = _debug_symbol_GetWorld();
_debug_symbol_XMMATRIX _debug_symbol_wvp = vp;
_debug_symbol_wvp = _debug_symbol_world * _debug_symbol_wvp;
_debug_symbol_XMMATRIX _debug_symbol_invWorld = _debug_symbol_MathHelper::_debug_symbol_InverseTranspose(_debug_symbol_world);
context->_debug_symbol_IASetVertexBuffers(0, 1, &_debug_symbol_mVB, &stride, &offset);
context->_debug_symbol_IASetIndexBuffer(_debug_symbol_mIB, _debug_symbol_DXGI_FORMAT_R32_UINT, 0);
_debug_symbol_litTexEffect->_debug_symbol_SetPerObjectParams(_debug_symbol_world, _debug_symbol_invWorld, _debug_symbol_wvp, _debug_symbol_mFrames[_debug_symbol_mFrameIndex]->image);
_debug_symbol_litTexEffect->Draw(context, _debug_symbol_mVB, _debug_symbol_mIB, _debug_symbol_mFrameIndex * 6, 6);
}
void _debug_symbol_Sprite::_debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_vel = _debug_symbol_vel + _debug_symbol_force;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
void _debug_symbol_Sprite::_debug_symbol_ApplyDamage(_debug_symbol_Sprite* _debug_symbol_spriteHit)
{
_debug_symbol_spriteHit->_debug_symbol_SetHealth(_debug_symbol_spriteHit->_debug_symbol_GetHealth() - _debug_symbol_mDamage);
}

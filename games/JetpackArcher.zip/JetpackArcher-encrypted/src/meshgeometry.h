#pragma once
#include "graphicalgeometry.h"
#include "vertex.h"
#include "effect.h"
class _debug_symbol_MeshGeometry : public _debug_symbol_GraphicalGeometry
{
public:
struct _debug_symbol_Subset
{
UINT id;
UINT _debug_symbol_vertexStart;
UINT _debug_symbol_vertexCount;
UINT _debug_symbol_faceCount;
UINT _debug_symbol_faceStartIndex;
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_srv;
std::wstring name;
};
public:
_debug_symbol_MeshGeometry(_debug_symbol_LitTexEffect* _debug_symbol_effect);
~_debug_symbol_MeshGeometry(void);
void _debug_symbol_SetVertices(_debug_symbol_ID3D11Device* device, const Vertex::_debug_symbol_NormalTexVertex* _debug_symbol_verts, UINT count);
void _debug_symbol_SetIndices(_debug_symbol_ID3D11Device* device, const UINT* indices, UINT count);
void _debug_symbol_SetSubsetTable(std::vector<_debug_symbol_Subset>& _debug_symbol_subsetTable);
void Draw(_debug_symbol_ID3D11DeviceContext* dc, UINT _debug_symbol_subsetID);
void Draw(_debug_symbol_ID3D11DeviceContext* context, _debug_symbol_CXMMATRIX _debug_symbol_world, _debug_symbol_CXMMATRIX _debug_symbol_ITWorld, _debug_symbol_CXMMATRIX vp);
protected:
std::vector<_debug_symbol_Subset> _debug_symbol_mSubsetTable;
_debug_symbol_LitTexEffect* _debug_symbol_mEffect;
virtual void _debug_symbol_InitIB(_debug_symbol_ID3D11Device* device)
{}
};

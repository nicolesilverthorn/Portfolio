#include "player.h"
_debug_symbol_Player::~_debug_symbol_Player(void)
{
}
void _debug_symbol_Player::_debug_symbol_Jump()
{
if(_debug_symbol_mGrounded)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_vel = _debug_symbol_XMVectorSet(_debug_symbol_vel._debug_symbol_m128_f32[0], _debug_symbol_vel._debug_symbol_m128_f32[1] + _debug_symbol_JUMP_FORCE, 0.0f, 0.0f);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
_debug_symbol_mGrounded = false;
}
}
float _debug_symbol_timer = 0.0f;
void _debug_symbol_Player::_debug_symbol_UseJetpack(float dt)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_timer += dt;
if (_debug_symbol_timer < 3.0f)
{
_debug_symbol_vel = _debug_symbol_XMVectorSet(_debug_symbol_vel._debug_symbol_m128_f32[0], _debug_symbol_vel._debug_symbol_m128_f32[1] + _debug_symbol_JETPACK_FORCE, 0.0f, 0.0f);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
else
{
_debug_symbol_vel = _debug_symbol_XMVectorSet(_debug_symbol_vel._debug_symbol_m128_f32[0], _debug_symbol_vel._debug_symbol_m128_f32[1] - _debug_symbol_JP_GRAVITY, 0.0f, 0.0f);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
_debug_symbol_timer = 0.0f;
}
}

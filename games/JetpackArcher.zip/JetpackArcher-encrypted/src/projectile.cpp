#include "projectile.h"
_debug_symbol_Projectile::~_debug_symbol_Projectile()
{
}
void _debug_symbol_Projectile::_debug_symbol_AddForce(_debug_symbol_FXMVECTOR _debug_symbol_force)
{
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_vel = _debug_symbol_vel + _debug_symbol_force;
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
}
void _debug_symbol_Projectile::Update(float dt)
{
_debug_symbol_XMVECTOR pos = _debug_symbol_XMLoadFloat2(&_debug_symbol_mPos);
_debug_symbol_XMVECTOR _debug_symbol_vel = _debug_symbol_XMLoadFloat3(&_debug_symbol_mVelocity);
_debug_symbol_mDistanceTravelled += _debug_symbol_XMVector3Length(_debug_symbol_vel)._debug_symbol_m128_f32[0] * dt;
pos = pos + (_debug_symbol_vel * dt);
_debug_symbol_XMStoreFloat2(&_debug_symbol_mPos, pos);
_debug_symbol_XMStoreFloat3(&_debug_symbol_mVelocity, _debug_symbol_vel);
_debug_symbol_Sprite::Update(dt);
}

#pragma once
#include "sprite.h"
#include "boundingboxes.h"
class _debug_symbol_Enemy : public _debug_symbol_Sprite
{
public:
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bbox;
public:
_debug_symbol_Enemy(_debug_symbol_FXMVECTOR _debug_symbol_pos2D, _debug_symbol_FXMVECTOR _debug_symbol_scale2D, _debug_symbol_uint16_t _debug_symbol_frameWidth, _debug_symbol_uint16_t _debug_symbol_frameHeight, float depth, const std::vector<Frame*>& _debug_symbol_frames,
float _debug_symbol_frameRate, _debug_symbol_ID3D11Device* device, float _debug_symbol_health) :
_debug_symbol_Sprite(_debug_symbol_pos2D, _debug_symbol_scale2D, _debug_symbol_frameWidth, _debug_symbol_frameHeight, depth, _debug_symbol_frames, _debug_symbol_frameRate, device, _debug_symbol_health),
_debug_symbol_bbox()
{}
void _debug_symbol_Chase(std::vector<_debug_symbol_Enemy*>& _debug_symbol_chaser, _debug_symbol_Sprite* target, float dt);
void Update(float dt);
_debug_symbol_XMVECTOR _debug_symbol_velocity;
float _debug_symbol_maxVelocity = 12.0f;
};

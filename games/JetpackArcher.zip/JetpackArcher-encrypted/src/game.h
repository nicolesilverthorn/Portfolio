#pragma once
#include "d3dApp.h"
#include "d3dx11Effect.h"
#include "MathHelper.h"
#include "LightHelper.h"
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "vertex.h"
#include "graphicalobject.h"
#include "player.h"
#include "enemy.h"
#include "projectile.h"
#include "effect.h"
#include "basecamera.h"
#include "sprite.h"
#include "xnacollision.h"
#include "fmod.hpp"
class _debug_symbol_JetpackArcher;
struct _debug_symbol_JetpackParticle
{
_debug_symbol_XMFLOAT3 pos;
_debug_symbol_XMFLOAT3 _debug_symbol_vel;
_debug_symbol_XMFLOAT2 size;
};
const int _debug_symbol_MAX_PARTICLES = 100;
class _debug_symbol_Game
{
enum _debug_symbol_CollisionSide
{
top,
right,
_debug_symbol_bot,
left
};
public:
_debug_symbol_Game();
~_debug_symbol_Game();
bool Init(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice);
virtual void _debug_symbol_InitBoundingBoxes();
virtual void _debug_symbol_UpdateScene(_debug_symbol_ID3D11DeviceContext* _debug_symbol_md3dImmediateContext, _debug_symbol_ID3D11Device* _debug_symbol_md3dDevice, float dt, _debug_symbol_JetpackArcher* _debug_symbol_instance);
virtual void _debug_symbol_DrawScene(_debug_symbol_ID3D11DeviceContext* _debug_symbol_md3dImmediateContext, _debug_symbol_CXMMATRIX vp, _debug_symbol_IDXGISwapChain* _debug_symbol_mSwapChain, _debug_symbol_ID3D11RenderTargetView* _debug_symbol_mRenderTargetView,
_debug_symbol_ID3D11DepthStencilView* _debug_symbol_mDepthStencilView, _debug_symbol_PointLightOptimized _debug_symbol_mPointLight, _debug_symbol_SpotLightOptimized _debug_symbol_mSpotLight, _debug_symbol_XMFLOAT4 _debug_symbol_mAmbientColour);
virtual void _debug_symbol_OnMouseDown(HWND _debug_symbol_mhMainWnd, WPARAM _debug_symbol_btnState, int x, int y);
virtual void _debug_symbol_OnMouseUp(WPARAM _debug_symbol_btnState, int x, int y);
virtual void OnMouseMove(WPARAM _debug_symbol_btnState, int x, int y);
private:
void _debug_symbol_BuildBlendStates(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice);
void _debug_symbol_BuildDSStates(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice);
_debug_symbol_ID3D11BlendState* _debug_symbol_mAdditiveBS;
_debug_symbol_ID3D11BlendState* _debug_symbol_mTransparentBS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mFontDS;
_debug_symbol_ID3D11DepthStencilState* _debug_symbol_mNoDepthDS;
void _debug_symbol_BuildVertexLayout();
void _debug_symbol_UpdateKeyboardInput(_debug_symbol_ID3D11Device* _debug_symbol_md3dDevice, float dt);
_debug_symbol_CollisionSide _debug_symbol_RectRectCollision(_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_r1, _debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_r2, _debug_symbol_Sprite* _debug_symbol_sprite);
void _debug_symbol_SpriteRectCollision(_debug_symbol_Sprite* _debug_symbol_sprite, _debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb);
bool _debug_symbol_EnemyProjCollision(_debug_symbol_Sprite* _debug_symbol_sprite, _debug_symbol_Projectile* _debug_symbol_arrow);
bool _debug_symbol_PlayerEnemyCollision(_debug_symbol_Sprite* _debug_symbol_player, _debug_symbol_Sprite* _debug_symbol_enemy);
_debug_symbol_LitTexEffect* _debug_symbol_mLitTexEffect;
_debug_symbol_BaseCamera* _debug_symbol_m2DCam;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mView;
_debug_symbol_XMFLOAT4X4 _debug_symbol_mProj;
_debug_symbol_XMFLOAT4X4 _debug_symbol_m2DProj;
_debug_symbol_Sprite* _debug_symbol_mBG;
_debug_symbol_Sprite* _debug_symbol_mControlsFont;
_debug_symbol_Sprite* _debug_symbol_mGreenHBar;
std::vector<_debug_symbol_Sprite*> _debug_symbol_greenBarVec;
_debug_symbol_Sprite* _debug_symbol_mGreenHBarP;
_debug_symbol_Sprite* _debug_symbol_mRedHBar;
std::vector<_debug_symbol_Sprite*> _debug_symbol_redBarVec;
_debug_symbol_Sprite* _debug_symbol_mRedHBarP;
_debug_symbol_Sprite* _debug_symbol_mGreenFuel;
_debug_symbol_Sprite* _debug_symbol_mRedFuel;
_debug_symbol_Player* _debug_symbol_mPlayer;
_debug_symbol_Sprite* _debug_symbol_mFlame;
bool _debug_symbol_drawFlame = false;
_debug_symbol_Enemy* _debug_symbol_mEnemy1;
_debug_symbol_Enemy* _debug_symbol_mEnemy2;
_debug_symbol_Enemy* _debug_symbol_mEnemy3;
_debug_symbol_Enemy* _debug_symbol_mEnemy4;
_debug_symbol_Enemy* _debug_symbol_mEnemy5;
_debug_symbol_Enemy* _debug_symbol_mEnemy6;
std::vector<_debug_symbol_Enemy*> _debug_symbol_enemies;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_playerBB;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb1;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb2;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb3;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb4;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb5;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb6;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb7;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb8;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb9;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb10;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb11;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb12;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb13;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb14;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb15;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb16;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb17;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb18;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb19;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb20;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb21;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb22;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb23;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb24;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb25;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb26;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb27;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb28;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb29;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb30;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_bb31;
std::vector<_debug_symbol_BoundingBoxes::BoundingBox> _debug_symbol_boxes;
_debug_symbol_Sprite* _debug_symbol_EOLobj;
_debug_symbol_BoundingBoxes::BoundingBox _debug_symbol_EOLobjBB;
std::vector<_debug_symbol_Projectile*> _debug_symbol_mProjectiles;
_debug_symbol_Sprite::Frame* _debug_symbol_projectileFrame = new _debug_symbol_Sprite::Frame();
std::vector<_debug_symbol_JetpackParticle> _debug_symbol_mParticles;
_debug_symbol_ID3D11ShaderResourceView* _debug_symbol_mParticleTexture;
bool _debug_symbol_mMouseReleased;
POINT _debug_symbol_mLastMousePos;
public:
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_hbFrameG;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_hbFrameR;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_fbFrameG;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_fbFrameR;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_projFrame;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_EOLobjFrames;
std::vector<_debug_symbol_Sprite::Frame*> _debug_symbol_cfFrame;
float _debug_symbol_cooldownTimer = 0.0f;
bool _debug_symbol_canShoot = true;
bool _debug_symbol_isFacingRight = true;
float _debug_symbol_recoverTime = 0.0f;
float _debug_symbol_fuelRecoverTime = 0.0f;
float _debug_symbol_currHealth;
float _debug_symbol_maxHealth;
float _debug_symbol_ratio;
float _debug_symbol_redXPos;
float _debug_symbol_redXScale;
float _debug_symbol_currHealthP;
float _debug_symbol_maxHealthP;
float _debug_symbol_ratioP;
float _debug_symbol_redXPosP;
float _debug_symbol_redXScaleP;
float _debug_symbol_currHealthF;
float _debug_symbol_maxHealthF;
float _debug_symbol_ratioF;
float _debug_symbol_redXPosF;
float _debug_symbol_redXScaleF;
int _debug_symbol_mFuel = 5.0f;
bool _debug_symbol_canUseJetpack = true;
bool _debug_symbol_EOLobjActive = false;
float _debug_symbol_controlsTimer = 0.0f;
};

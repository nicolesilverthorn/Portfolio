#include "graphicalgeometry.h"
